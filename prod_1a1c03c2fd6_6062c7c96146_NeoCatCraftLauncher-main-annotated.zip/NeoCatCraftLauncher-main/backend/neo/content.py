"""游戏内容（资源包 / 光影包 / 数据包）管理模块。

功能:
    1. 通过 Modrinth / CurseForge 双平台搜索、查询版本；
    2. 后台线程下载安装到对应目录（支持按实例隔离、数据包按存档定位）；
    3. 扫描本地目录、启用/禁用（改 .disabled 后缀）、删除。

所有写操作完成后都会广播 content.changed 事件，前端据此刷新列表。
"""

from __future__ import annotations

import base64
import threading
import zipfile
from concurrent.futures import ThreadPoolExecutor, as_completed
from pathlib import Path
from typing import Any

from .config import Config
from .events import EventBus, make_event
from .mods.downloader import download_file
from .mods.platform import (
    CurseForgeClient,
    ModPlatformError,
    ModrinthClient,
)
from .tasks import TaskManager

CONTENT_KINDS: dict[str, dict[str, Any]] = {
    "resourcepack": {
        "label": "资源包",
        "modrinth_type": "resourcepack",
        "curseforge_class": 12,
        "directory": "resourcepacks",
        "extensions": {".zip"},
    },
    "shader": {
        "label": "光影包",
        "modrinth_type": "shader",
        "curseforge_class": 6552,
        "directory": "shaderpacks",
        "extensions": {".zip"},
    },
    "datapack": {
        "label": "数据包",
        "modrinth_type": "datapack",
        "curseforge_class": 6945,
        "directory": "datapacks",
        "extensions": {".zip"},
    },
}

# 图标上限 128KB，防止把巨型图片塞进 Data URL
ICON_LIMIT_BYTES = 128 * 1024


def _safe_child(root: Path, name: str) -> Path | None:
    """安全地把用户输入的名字解析为 root 下的路径。

    用于防御路径穿越：拒绝空名与 . / ..，并校验解析后的绝对路径仍在 root 之内；
    不合法时返回 None，由调用方拒绝该请求。
    """
    # 直接拒绝空名与相对跳转，第一道防线
    if not name or name in {".", ".."}:
        return None
    try:
        candidate = (root / name).resolve()
        # 校验解析后的路径仍位于 root 内，不合法会抛异常
        candidate.relative_to(root.resolve())
    except Exception:
        return None
    return candidate


def _archive_icon(path: Path) -> str | None:
    """从资源包/光影包 zip 中提取图标并转为 base64 Data URL。

    只读取 pack.png / thumbnail.png / icon.png 三个约定文件名，
    且限定文件大小（ICON_LIMIT_BYTES），避免解压炸弹与超大响应；
    任何异常都返回 None，图标缺失不影响主流程。
    """
    try:
        with zipfile.ZipFile(path) as archive:
            candidates = [
                entry
                for entry in archive.infolist()
                if not entry.is_dir()
                # Minecraft 资源包约定的三种图标文件名
                and entry.filename.lower() in {"pack.png", "thumbnail.png", "icon.png"}
                and entry.file_size <= ICON_LIMIT_BYTES
            ]
            if not candidates:
                return None
            data = archive.read(candidates[0])
            return "data:image/png;base64," + base64.b64encode(data).decode("ascii")
    except Exception:
        return None


class ContentService:
    """内容（资源包/光影包/数据包）业务服务。

    负责平台检索、下载安装与本地文件管理；
    与模组模块共用下载器与任务系统，但目录与平台类型各自独立配置。
    """
    def __init__(
        self,
        config: Config,
        tasks: TaskManager,
        bus: EventBus,
        instances: Any = None,
    ) -> None:
        """初始化内容服务。

        参数:
            config: 配置对象，用于读取 API Key、下载参数与目录。
            tasks: 任务管理器，用于进度上报。
            bus: 事件总线，用于广播变更与日志。
            instances: 实例管理器（可为 None，表示仅操作全局目录）。
        """
        self.config = config
        self.tasks = tasks
        self.bus = bus
        self.instances = instances
        self._lock = threading.Lock()

    def _clients(self) -> tuple[ModrinthClient, CurseForgeClient]:
        """按当前配置创建两个平台客户端（超时 20 秒）。
        CurseForge 使用配置中的 API Key，为空时由平台返回错误。
        """
        return (
            ModrinthClient(timeout=20),
            CurseForgeClient(self.config.get("curseforge_api_key") or "", timeout=20),
        )

    @staticmethod
    def _kind(kind: str) -> dict[str, Any]:
        """校验并返回内容类型的元信息（标签、平台类型、目录名、扩展名）。

        异常:
            ModPlatformError: 类型不受支持。
        """
        normalized = (kind or "").strip().lower()
        if normalized not in CONTENT_KINDS:
            raise ModPlatformError(f"不支持的内容类型: {kind}")
        return CONTENT_KINDS[normalized]

    def _instance_root(self, instance_id: str | None) -> Path:
        """确定内容所属实例的根目录。
        传入实例 ID 时校验实例存在并按实例目录隔离，否则使用全局 .minecraft。
        """
        if self.instances is not None and instance_id:
            instance = self.instances.get(instance_id)
            if instance is None:
                raise ModPlatformError("实例不存在")
            return self.instances.directory_of(instance)
        return self.config.minecraft_directory

    def directory(self, kind: str, instance_id: str | None, world: str | None = None) -> Path:
        """计算某类内容的存放目录并确保存在。

        特殊处理: 数据包需要装进具体存档，路径为 <实例>/saves/<world>/datapacks，
        且存档名必须通过 _safe_child 校验，防止越权写入其他存档。
        """
        definition = self._kind(kind)
        root = self._instance_root(instance_id)
        # 数据包必须装进具体存档，而不是游戏根目录
        if kind == "datapack" and world:
            saves = root / "saves"
            save_dir = _safe_child(saves, world)
            # 存档名非法或存档不存在时直接报错
            if save_dir is None or not save_dir.is_dir():
                raise ModPlatformError("所选存档不存在")
            target = save_dir / "datapacks"
        else:
            target = root / str(definition["directory"])
        target.mkdir(parents=True, exist_ok=True)
        return target

    def search(
        self,
        kind: str,
        platform: str,
        query: str,
        minecraft_version: str | None = None,
        limit: int = 20,
        offset: int = 0,
    ) -> dict[str, Any]:
        """按平台搜索内容。

        参数:
            kind: resourcepack / shader / datapack。
            platform: all / modrinth / curseforge。
            query: 关键词。
            minecraft_version: 限定游戏版本（可选）。
            limit / offset: 分页参数。
        """
        definition = self._kind(kind)
        normalized_platform = (platform or "all").lower()
        if normalized_platform == "all":
            return self._aggregate_search(
                definition,
                query,
                minecraft_version,
                limit,
                offset,
            )
        return self._search_platform(
            normalized_platform,
            definition,
            query,
            minecraft_version,
            limit,
            offset,
        )

    def _search_platform(
        self,
        platform: str,
        definition: dict[str, Any],
        query: str,
        minecraft_version: str | None,
        limit: int,
        offset: int,
    ) -> dict[str, Any]:
        """在单个平台搜索，并把结果补上 kind 字段便于前端路由。
        """
        modrinth, curseforge = self._clients()
        if platform == "curseforge":
            payload = curseforge.search(
                query,
                minecraft_version,
                None,
                limit,
                offset,
                class_id=int(definition["curseforge_class"]),
            )
        elif platform == "modrinth":
            payload = modrinth.search(
                query,
                minecraft_version,
                None,
                limit,
                offset,
                project_type=str(definition["modrinth_type"]),
            )
        else:
            raise ModPlatformError(f"未知平台: {platform}")
        for hit in payload.get("hits") or []:
            # 统一补上内容类型字段，前端可复用同一套渲染
            hit["kind"] = definition["modrinth_type"]
        return payload

    def _aggregate_search(
        self,
        definition: dict[str, Any],
        query: str,
        minecraft_version: str | None,
        limit: int,
        offset: int,
    ) -> dict[str, Any]:
        """双平台聚合搜索。

        并发请求 Modrinth 与 CurseForge，任一平台失败只记录 warning 不影响整体；
        结果按下载量倒序、名称升序去排序，并截断到 limit 条（上限 50）。
        """
        hits: list[dict[str, Any]] = []
        # 聚合搜索时收集各平台的失败原因，前端可提示部分来源不可用
        warnings: list[str] = []
        # 两个平台并发请求，缩短聚合搜索耗时
        with ThreadPoolExecutor(max_workers=2) as pool:
            futures = {
                pool.submit(
                    self._search_platform,
                    platform,
                    definition,
                    query,
                    minecraft_version,
                    limit,
                    offset,
                ): platform
                for platform in ("modrinth", "curseforge")
            }
            for future in as_completed(futures):
                platform = futures[future]
                try:
                    payload = future.result()
                    hits.extend(payload.get("hits") or [])
                except Exception as error:
                    warnings.append(f"{platform}: {error}")
        # 按下载量倒序，同量按名称升序，保证结果稳定
        hits.sort(
            key=lambda item: (
                -int(item.get("downloads") or 0),
                str(item.get("title") or "").lower(),
            )
        )
        return {
            "platform": "all",
            "kind": definition["modrinth_type"],
            "total": len(hits),
            "hits": hits[: max(1, min(limit, 50))],
            "offset": max(0, offset),
            "warnings": warnings,
        }

    def versions(
        self,
        kind: str,
        platform: str,
        project_id: str,
        minecraft_version: str | None = None,
    ) -> dict[str, Any]:
        """查询某个项目的可用版本列表（CurseForge 返回文件列表，Modrinth 返回版本列表）。
        """
        self._kind(kind)
        modrinth, curseforge = self._clients()
        if platform == "curseforge":
            items = curseforge.files(project_id, minecraft_version, None)
        else:
            items = modrinth.versions(project_id, minecraft_version, None)
        return {"platform": platform, "project_id": project_id, "kind": kind, "versions": items}

    def install(
        self,
        kind: str,
        platform: str,
        project_id: str,
        version_id: str | None = None,
        minecraft_version: str | None = None,
        instance_id: str | None = None,
        world: str | None = None,
    ) -> dict[str, Any]:
        """后台下载并安装一个内容包。

        参数:
            kind / platform / project_id: 内容类型、平台与项目 ID。
            version_id: 指定版本（可选，缺省取最新匹配）。
            minecraft_version: 游戏版本过滤条件。
            instance_id: 目标实例（可选）。
            world: 数据包所属存档（可选）。

        行为:
            立即返回任务快照，实际下载在守护线程中执行，
            进度通过 TaskManager 推送，完成后广播 content.changed。
        """
        definition = self._kind(kind)
        target_dir = self.directory(kind, instance_id, world)
        task = self.tasks.create("download", f"下载{definition['label']} #{project_id}")

        def worker() -> None:
            try:
                modrinth, curseforge = self._clients()
                if platform == "curseforge":
                    if version_id:
                        version = curseforge.file(project_id, version_id)
                    else:
                        versions = curseforge.files(project_id, minecraft_version, None)
                        if not versions:
                            raise ModPlatformError("没有匹配当前游戏版本的 CurseForge 文件")
                        version = versions[0]
                else:
                    if version_id:
                        version = modrinth.version(version_id)
                    else:
                        versions = modrinth.versions(project_id, minecraft_version, None)
                        if not versions:
                            raise ModPlatformError("没有匹配当前游戏版本的 Modrinth 文件")
                        version = versions[0]

                files = [item for item in version.get("files") or [] if item.get("url")]
                # 优先选平台标记的 primary 文件，否则取第一个
                primary = next((item for item in files if item.get("primary")), files[0] if files else None)
                if primary is None:
                    raise ModPlatformError("该版本没有可下载文件")
                result = download_file(
                    primary["url"],
                    target_dir,
                    primary.get("filename") or f"{project_id}.zip",
                    expected_size=primary.get("size"),
                    sha1=primary.get("sha1"),
                    retries=int(self.config.get("download_retries", 3) or 3),
                    timeout=int(self.config.get("download_timeout", 60) or 60),
                    tasks=self.tasks,
                    task_id=task.id,
                    label=f"下载{definition['label']}",
                )
                self.tasks.finish(
                    task.id,
                    {"path": result.path, "kind": kind},
                    f"{definition['label']}已保存到 {Path(result.path).name}",
                )
                self.bus.publish(
                    make_event("content.changed", content_kind=kind, instance_id=instance_id)
                )
                self.bus.log(f"{definition['label']}已保存到 {result.path}", source="content")
            except Exception as error:
                self.tasks.fail(task.id, str(error))
                self.bus.log(f"{definition['label']}下载失败: {error}", source="content", level="error")

        # 下载放到守护线程，接口立即返回任务 ID，避免阻塞请求
        threading.Thread(target=worker, daemon=True).start()
        return task.snapshot()

    def scan(self, kind: str, instance_id: str | None, world: str | None = None) -> dict[str, Any]:
        """扫描本地目录，列出已安装内容。

        跳过非文件与扩展名不匹配的项，识别 .disabled 判断启用状态，
        并尽量从压缩包中提取图标；按修改时间倒序返回。
        """
        definition = self._kind(kind)
        directory = self.directory(kind, instance_id, world)
        extensions = definition["extensions"]
        items: list[dict[str, Any]] = []
        for path in sorted(directory.iterdir(), key=lambda item: item.name.lower()):
            if not path.is_file():
                continue
            # 去掉 .disabled 后缀后再判断扩展名
            actual = path.name[: -len(".disabled")] if path.name.lower().endswith(".disabled") else path.name
            if Path(actual).suffix.lower() not in extensions:
                continue
            stat = path.stat()
            items.append(
                {
                    "file_name": path.name,
                    "name": Path(actual).stem,
                    "size": stat.st_size,
                    "modified": stat.st_mtime,
                    "enabled": not path.name.lower().endswith(".disabled"),
                    "icon": _archive_icon(path),
                    "kind": kind,
                }
            )
        items.sort(key=lambda item: (-float(item["modified"]), item["name"].lower()))
        return {
            "kind": kind,
            "label": definition["label"],
            "directory": str(directory),
            "count": len(items),
            "items": items,
            "world": world or "",
        }

    def toggle(self, kind: str, file_name: str, instance_id: str | None, world: str | None = None) -> dict[str, Any]:
        """切换内容的启用 / 禁用状态。

        通过给文件名追加或去掉 .disabled 后缀实现（Minecraft 会忽略该后缀文件）；
        目标名已存在时拒绝操作，避免覆盖。
        """
        directory = self.directory(kind, instance_id, world)
        source = _safe_child(directory, file_name)
        if source is None or not source.is_file():
            raise ModPlatformError("文件不存在")
        if source.name.lower().endswith(".disabled"):
            target = source.with_name(source.name[: -len(".disabled")])
        else:
            # 禁用 = 追加 .disabled 后缀，游戏会忽略该文件
            target = source.with_name(source.name + ".disabled")
        if target.exists():
            raise ModPlatformError(f"{target.name} 已存在，无法切换")
        # 重命名完成切换，跨盘不会发生（同目录内）
        source.replace(target)
        self.bus.publish(
            make_event("content.changed", content_kind=kind, instance_id=instance_id)
        )
        return {"file": target.name, "enabled": not target.name.lower().endswith(".disabled")}

    def delete(self, kind: str, file_name: str, instance_id: str | None, world: str | None = None) -> dict[str, Any]:
        """删除指定的内容文件。

        文件名经 _safe_child 校验，只允许删除目标目录内的文件，
        删除后广播 content.changed。
        """
        directory = self.directory(kind, instance_id, world)
        target = _safe_child(directory, file_name)
        if target is None or not target.is_file():
            raise ModPlatformError("文件不存在")
        target.unlink()
        self.bus.publish(
            make_event("content.changed", content_kind=kind, instance_id=instance_id)
        )
        return {"deleted": target.name}


__all__ = ["CONTENT_KINDS", "ContentService"]
