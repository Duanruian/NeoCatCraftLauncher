"""Java 运行时管理模块。

职责：
    1. 枚举本启动器托管的 Java（javas_directory 下的 Zulu 包）；
    2. 枚举系统已安装的 Java 与 Minecraft 自带的 runtime；
    3. 按 Minecraft 版本推断所需 Java 大版本，并在多个候选中挑出一个；
    4. 从 Azul Zulu 接口查询并下载安装包，解压到托管目录（异步 + 进度 + 校验）。

关键实现约定：
    - 每个安装器/游戏实例对 Java 大版本有硬性要求，选错会直接启动失败，
      因此 resolve 会尽量选精确匹配，实在没有才退到更高版本并标记 mismatch；
    - 下载先写 .part，校验通过后再原子改名，避免半截文件被当成完整包；
    - 依赖 minecraft_launcher_lib 的系统 Java 探测能力，但该库缺失或异常不影响其它功能。
"""

from __future__ import annotations

import hashlib
import os
import platform
import re
import shutil
import threading
import time
import uuid
import zipfile
from contextlib import contextmanager
from pathlib import Path
from typing import Any, Callable, Iterator

import httpx

from .config import Config
from .events import EventBus, make_event
from .tasks import TaskManager

USER_AGENT = "NeoCatCraftLauncher/0.2 (+https://github.com/neocatcraft)"

JAVA_MAJOR_BY_MC: list[tuple[str, int]] = [
    ("1.21", 21),
    # 1.20.5 起改用 Java 21，必须排在 1.20 之前
    ("1.20.5", 21),
    ("1.20", 17),
    ("1.19", 17),
    ("1.18", 17),
    ("1.17", 16),
    ("1.16", 8),
    ("1.15", 8),
    ("1.14", 8),
    ("1.13", 8),
    ("1.12", 8),
    ("1.11", 8),
    ("1.10", 8),
    ("1.9", 8),
    ("1.8", 8),
    ("1.7", 8),
]

JAVA_LABELS = {8: "Java 8", 11: "Java 11", 16: "Java 16", 17: "Java 17", 21: "Java 21", 22: "Java 22", 23: "Java 23", 25: "Java 25"}

# 界面允许用户选择安装的大版本
AVAILABLE_MAJORS = [8, 11, 16, 17, 21, 25]

# 进度分段：下载占 0-85，校验 90，解压 99，收尾 100
DOWNLOAD_PROGRESS_END = 85
VERIFY_PROGRESS_END = 90
EXTRACT_PROGRESS_END = 99
DOWNLOAD_CHUNK_SIZE = 256 * 1024


class JavaError(RuntimeError):
    pass


def _platform_params() -> dict[str, str]:
    """把当前平台映射为 Azul 接口要求的 os / arch 参数。

    只区分 windows / macos / linux 与 x64 / aarch64 / x86，
    未知架构统一按 x86 处理（接口可能返回空结果，由上层报错）。
    """
    system = platform.system().lower()
    machine = platform.machine().lower()
    if system == "windows":
        os_name = "windows"
    elif system == "darwin":
        os_name = "macos"
    else:
        os_name = "linux"
    if machine in ("x86_64", "amd64", "x64"):
        arch = "x64"
    elif machine in ("aarch64", "arm64"):
        arch = "aarch64"
    else:
        arch = "x86"
    return {"os": os_name, "arch": arch}


def java_major_for_minecraft(mc_version: str) -> int:
    """根据 Minecraft 版本号推断所需的 Java 大版本。

    按 JAVA_MAJOR_BY_MC 的前缀顺序匹配，注意列表顺序敏感：
    1.20.5 必须排在 1.20 之前，否则 1.20.5 会被当成 Java 17。
    无法识别时按 Java 21 处理（对现代版本更安全）。
    """
    value = (mc_version or "").strip().lower()
    for prefix, major in JAVA_MAJOR_BY_MC:
        if value.startswith(prefix):
            return major
    # 未知版本按 Java 21 处理，对现代版本更安全
    return 21


def _read_release(java_home: Path) -> dict[str, str]:
    """读取 $JAVA_HOME/release 中的键值对（形如 JAVA_VERSION="21.0.8"）。

    该文件比执行 java -version 快得多，是获取版本的首选途径。
    文件缺失或读取异常时返回空字典，由调用方回退到执行二进制。
    """
    release = java_home / "release"
    data: dict[str, str] = {}
    if not release.is_file():
        return data
    try:
        for line in release.read_text(encoding="utf-8", errors="replace").splitlines():
            if "=" not in line:
                continue
            key, _, value = line.partition("=")
            data[key.strip()] = value.strip().strip('"')
    except Exception:
        return {}
    return data


def _java_home_of(binary: Path) -> Path:
    """由 java 可执行文件路径反推 JAVA_HOME。

    若传入的就是 bin/java(.exe)，取上两级目录；
    否则认为传入的已经是目录，原样返回。
    """
    current = binary.resolve()
    if current.name.lower() in ("java.exe", "javaw.exe", "java"):
        return current.parent.parent
    return current


def _binary_of(java_home: Path) -> str:
    """在 JAVA_HOME 中查找 java 可执行文件。

    Windows 优先 java.exe，其次 javaw.exe；其它平台只找 bin/java。
    找不到时返回空字符串，调用方据此跳过该目录。
    """
    if os.name == "nt":
        candidate = java_home / "bin" / "java.exe"
        if candidate.is_file():
            return str(candidate)
        candidate = java_home / "bin" / "javaw.exe"
        if candidate.is_file():
            return str(candidate)
    candidate = java_home / "bin" / "java"
    return str(candidate) if candidate.is_file() else ""


def _is_file(path: Path) -> bool:
    """安全版 is_file：权限不足等 OSError 时返回 False 而不是抛异常。

    枚举目录时会大量调用，不能让个别坏路径中断整个流程。
    """
    try:
        return path.is_file()
    except OSError:
        return False


class JavaManager:
    def __init__(self, config: Config, tasks: TaskManager, bus: EventBus) -> None:
        """初始化，并准备系统 Java 的进程内缓存（避免每次选 Java 都扫一遍磁盘）。
        """
        self.config = config
        self.tasks = tasks
        self.bus = bus
        self._system_cache: tuple[float, list[dict[str, Any]]] | None = None
        self._lock = threading.Lock()

    # ---------- 枚举 ----------

    def managed(self) -> list[dict[str, Any]]:
        """枚举启动器托管的 Java（config.javas_directory 下的每个子目录）。

        兼容两种目录层级：直接是 JAVA_HOME，或解压后多套了一层（如 zulu-21/zulu-21.x），
        通过查找含 bin 的子目录来判断。单个目录读取失败只记日志并跳过。
        """
        root = self.config.javas_directory
        items: list[dict[str, Any]] = []
        if not root.is_dir():
            return items
        try:
            children = sorted(root.iterdir())
        except OSError as error:
            self.bus.log(f"无法读取 Java 运行时目录: {error}", source="java", level="error")
            return items
        for child in children:
            try:
                if not child.is_dir():
                    continue
                home = child
                # 兼容解压后多套一层目录（zulu-21/zulu-21.x/bin）
                nested = [entry for entry in child.iterdir() if entry.is_dir() and (entry / "bin").is_dir()]
                for entry in nested:
                    if (entry / "bin").is_dir():
                        home = entry
                        break
                binary = _binary_of(home)
                if not binary:
                    continue
                release = _read_release(home)
                version = release.get("JAVA_VERSION") or release.get("JAVA_RUNTIME_VERSION") or ""
                items.append(
                    {
                        "path": binary,
                        "home": str(home),
                        "name": release.get("IMPLEMENTOR") or "Zulu",
                        "version": version,
                        "major": _major_of(version),
                        "managed": True,
                        "vendor": "Azul Zulu",
                        "source": "managed",
                        "label": f"{JAVA_LABELS.get(_major_of(version), 'Java')} · Zulu",
                    }
                )
            except OSError as error:
                self.bus.log(f"跳过无法访问的 Java 运行时 {child}: {error}", source="java", level="error")
                continue
        return items

    def system(self, force: bool = False) -> list[dict[str, Any]]:
        """枚举系统中可用的 Java，结果缓存 300 秒。

        来源有两个：
            1. minecraft_launcher_lib 的 find_system_java_versions_information（注册表/PATH 等）；
            2. <游戏目录>/runtime，即官方启动器下载的运行时。
        用 resolved 路径去重，避免同一个 Java 被列两次。
        """
        now = time.time()
        # 5 分钟内复用上次扫描结果，避免频繁扫盘
        if not force and self._system_cache and now - self._system_cache[0] < 300:
            return self._system_cache[1]
        found: list[dict[str, Any]] = []
        try:
            import minecraft_launcher_lib as mll

            # 上游库会查注册表 / 常见安装路径 / PATH
            for info in mll.java_utils.find_system_java_versions_information():
                binary = info.get("java_path") or info.get("javaw_path")
                if not binary:
                    continue
                version = str(info.get("version") or "")
                found.append(
                    {
                        "path": binary,
                        "home": str(_java_home_of(Path(binary))),
                        "name": info.get("name") or "系统 Java",
                        "version": version,
                        "major": _major_of(version),
                        "managed": False,
                        "vendor": info.get("name") or "System",
                        "source": "system",
                        "label": f"{info.get('name') or 'Java'} {version}".strip(),
                    }
                )
        except Exception:
            pass
        runtime_root = self.config.minecraft_directory / "runtime"
        seen = {str(Path(item["path"]).resolve()).lower() for item in found if item.get("path")}
        if runtime_root.is_dir():
            # 官方启动器的 runtime 目录结构是 runtime/<组件>/<平台>/bin/java
            patterns = ("**/bin/java.exe", "**/bin/java") if os.name == "nt" else ("**/bin/java",)
            for pattern in patterns:
                try:
                    candidates = runtime_root.glob(pattern)
                    for binary in candidates:
                        if not _is_file(binary):
                            continue
                        key = str(binary.resolve()).lower()
                        if key in seen:
                            continue
                        seen.add(key)
                        home = _java_home_of(binary)
                        release = _read_release(home)
                        version = release.get("JAVA_VERSION") or release.get("JAVA_RUNTIME_VERSION") or ""
                        major = _major_of(version)
                        found.append(
                            {
                                "path": str(binary),
                                "home": str(home),
                                "name": "Minecraft 内置 Java",
                                "version": version,
                                "major": major,
                                "managed": False,
                                "vendor": release.get("IMPLEMENTOR") or "Minecraft Runtime",
                                "source": "minecraft-runtime",
                                "label": f"Minecraft Runtime · Java {major}",
                            }
                        )
                except OSError:
                    continue
        self._system_cache = (now, found)
        return found

    def all_java(self, force: bool = False) -> list[dict[str, Any]]:
        """汇总所有可用 Java：手动指定的优先，然后托管 Java 与系统 Java 合并去重。

        排序规则：托管的排在前面，同级内大版本号高的在前，
        这样 resolve 在“随便挑一个”时也能拿到较新的运行时。
        """
        seen: set[str] = set()
        merged: list[dict[str, Any]] = []
        configured = (self.config.get("java_path") or "").strip()
        if configured and _is_file(Path(configured)):
            version = _version_from_binary(Path(configured))
            merged.append(
                {
                    "path": configured,
                    "home": str(_java_home_of(Path(configured))),
                    "name": "手动指定",
                    "version": version,
                    "major": _major_of(version),
                    "managed": False,
                    "vendor": "自定义",
                    "source": "custom",
                    "label": f"自定义 Java {version}".strip(),
                }
            )
            seen.add(str(Path(configured).resolve()).lower())
        for item in self.managed() + self.system(force):
            key = str(Path(item["path"]).resolve()).lower()
            if key in seen:
                continue
            seen.add(key)
            merged.append(item)
        # 托管的排前面，同级内版本高的优先
        merged.sort(key=lambda item: (not item.get("managed"), -int(item.get("major") or 0)))
        return merged

    # ---------- 解析 ----------

    def resolve(self, instance: dict[str, Any] | None = None) -> dict[str, Any] | None:
        """为实例挑选合适的 Java，返回带来源标记的字典。

        选择优先级：
            1. 实例自身指定的 java_path（最高优先级，用户明确选择应被尊重）；
            2. 无游戏版本信息时用全局配置，再退化到第一个候选；
            3. 按游戏版本算出所需大版本，优先精确匹配，且同类中优先托管的；
            4. 没有精确匹配时退而使用更高版本，并标记 mismatch=True；
            5. 仍没有则回退全局配置，最后返回 None 交由上层报错。
        """
        instance_java = ((instance or {}).get("java_path") or "").strip()
        if instance_java and _is_file(Path(instance_java)):
            version = _version_from_binary(Path(instance_java))
            return {
                "path": instance_java,
                "major": _major_of(version),
                "version": version,
                "label": f"实例指定 Java {version}".strip(),
                "source": "instance",
            }

        candidates = self.all_java()
        mc_version = str((instance or {}).get("mc_version") or "")
        if not mc_version:
            configured = (self.config.get("java_path") or "").strip()
            if configured and _is_file(Path(configured)):
                return {
                    "path": configured,
                    "major": _major_of(_version_from_binary(Path(configured))),
                    "label": "全局默认 Java",
                    "source": "global",
                }
            return candidates[0] if candidates else None

        required = java_major_for_minecraft(mc_version)
        # 精确匹配大版本，避免用错 Java 导致启动失败
        exact = [item for item in candidates if int(item.get("major") or 0) == required]
        if exact:
            # 同为精确匹配时优先用启动器自己装的，路径可控
            preferred = next((item for item in exact if item.get("managed")), exact[0])
            return {**preferred, "required": required}
        higher = sorted(
            [item for item in candidates if int(item.get("major") or 0) >= required],
            key=lambda item: int(item.get("major") or 0),
        )
        if higher:
            # 没有精确版本时退到更低要求满足的高版本，并标记不匹配
            return {**higher[0], "required": required, "mismatch": True}
        configured = (self.config.get("java_path") or "").strip()
        if configured and _is_file(Path(configured)):
            return {
                "path": configured,
                "major": _major_of(_version_from_binary(Path(configured))),
                "label": "全局默认 Java",
                "source": "global",
                "required": required,
            }
        return None

    def for_minecraft(self, mc_version: str) -> dict[str, Any] | None:
        """便捷方法：只按游戏版本挑选 Java。
        """
        return self.resolve({"mc_version": mc_version})

    def resolve_for_install(self, mc_version: str) -> str:
        """为“安装加载器”这一场景准备 Java，必要时自动下载。

        与 resolve 的区别是它必须有可用的 Java：
            1. 已解析到且不 mismatch，直接返回；
            2. 未开启 auto_download_java 时直接报错，让用户自己装；
            3. 若已有同版本的 Java 安装任务在跑，复用它而不是重复下载；
            4. 轮询等待任务结束（最长 15 分钟），完成后重新解析并返回路径。
        """
        required = java_major_for_minecraft(mc_version)
        resolved = self.resolve({"mc_version": mc_version})
        if resolved and resolved.get("path") and not resolved.get("mismatch"):
            return str(resolved["path"])
        if not bool(self.config.get("auto_download_java", True)):
            raise JavaError(
                f"加载器安装需要 Java {required}，请先安装匹配的 Java 运行时"
            )

        # 已有同版本安装任务在跑就复用，避免重复下载几百 MB
        active_install = next(
            (
                item
                for item in self.tasks.list()
                if item.get("kind") == "java"
                and item.get("state") == "running"
                and f"Java {required}" in str(item.get("title") or "")
            ),
            None,
        )
        task = active_install or self.install(required)
        # 自动下载 Java 可能较慢，最多等待 15 分钟
        deadline = time.time() + 15 * 60
        while time.time() < deadline:
            task_id = task.get("id") if isinstance(task, dict) else task.id
            current = self.tasks.get(task_id)
            if current is not None and current.state == "done":
                break
            if current is not None and current.state == "error":
                raise JavaError(current.error or f"Java {required} 安装失败")
            time.sleep(0.25)
        else:
            raise JavaError(f"等待 Java {required} 安装完成超时")

        resolved = self.resolve({"mc_version": mc_version})
        if resolved and resolved.get("path") and not resolved.get("mismatch"):
            return str(resolved["path"])
        raise JavaError(f"无法准备加载器安装所需的 Java {required}")

    # ---------- 安装 ----------

    def resolve_package(self, major: int) -> dict[str, Any]:
        """向 Azul 接口查询指定大版本的 Zulu JDK 下载信息。

        查询条件固定为 zip + jdk + 非 JavaFX + GA 版本 + 最新，
        并先尝试 availability_types=CA（带商业支持版本），
        遇到 406 或空结果再退回不带该参数的查询。
        只接受 .zip 结尾的地址，因为解压逻辑基于 zipfile。
        返回 url / name / size / sha256 / major / version，供下载与校验使用。
        """
        api = (self.config.get("zulu_api") or "").strip() or "https://api.azul.com/metadata/v1/zulu"
        params: dict[str, Any] = {
            "java_version": major,
            "archive_type": "zip",
            "java_package_type": "jdk",
            "javafx_bundled": "false",
            "latest": "true",
            "release_status": "ga",
            "page_size": 20,
            **_platform_params(),
        }
        headers = {"User-Agent": USER_AGENT, "Accept": "application/json"}
        attempts = [
            # 先尝试带商业支持的构建（更稳定）
            {**params, "availability_types": "CA"},
            params,
        ]
        last_error: Exception | None = None
        for query in attempts:
            try:
                with httpx.Client(timeout=25, follow_redirects=True, headers=headers) as client:
                    response = client.get(f"{api.rstrip('/')}/packages/", params=query)
                # 部分版本不支持 availability_types，406 时退回普通查询
                if response.status_code == 406:
                    continue
                if response.status_code != 200:
                    last_error = JavaError(f"Azul 接口返回 HTTP {response.status_code}")
                    continue
                payload = response.json()
                if not isinstance(payload, list):
                    last_error = JavaError("Azul 接口返回了意外的数据格式")
                    continue
                for item in payload:
                    url = item.get("download_url") or ""
                    # 只接受 zip，因为解压依赖 zipfile
                    if url.lower().endswith(".zip"):
                        return {
                            "url": url,
                            "name": item.get("name") or f"zulu-{major}.zip",
                            "size": item.get("size") or 0,
                            "sha256": (item.get("sha256_hash") or "").lower(),
                            "major": major,
                            "version": item.get("openjdk_version") or ".".join(str(v) for v in (item.get("java_version") or [])),
                        }
                last_error = JavaError(f"没有找到 Java {major} 的 Zulu 安装包")
            except Exception as error:
                last_error = error
        raise JavaError(f"获取 Zulu Java {major} 失败: {last_error}")

    def install(self, major: int) -> dict[str, Any]:
        """下载并安装指定大版本的 Zulu Java（异步）。

        task 立即返回快照，真正的下载解压在后台线程完成：
            1. 解析安装包 → 下载到临时目录 → 校验 → 解压；
            2. 在解压结果中定位真正的 JAVA_HOME（含 java 可执行文件的那层）；
            3. 目标目录已存在时追加时间戳，避免覆盖正在使用的运行时；
            4. 同盘 move 到最终位置，读取 release 得到真实版本号；
            5. 清空系统 Java 缓存并广播 java.changed 事件。
        """
        major = int(major)
        if major <= 0:
            raise JavaError("无效的 Java 版本")
        task = self.tasks.create("java", f"安装 Zulu Java {major}")
        self.bus.log(f"开始从 Azul 下载 Zulu Java {major}", source="java")

        def worker() -> None:
            """后台安装线程主体：任何异常都转成任务失败状态 + 错误日志，不让线程静默死亡。
            """
            temp_dir: Path | None = None
            try:
                package = self.resolve_package(major)
                self.tasks.progress(task.id, message=f"解析安装包 {package['name']}")
                root = self.config.javas_directory
                target = root / f"zulu-{major}"
                if target.exists():
                    # 目录已被占用时加时间戳，避免覆盖正在使用的运行时
                    target = root / f"zulu-{major}-{int(time.time())}"
                # 临时目录与目标同盘，后面 move 才是原子改名
                with _temporary_directory(root) as temp_dir:
                    archive = temp_dir / package["name"]
                    self._download(package, archive, task.id)
                    self.tasks.update(
                        task.id,
                        force=True,
                        progress=VERIFY_PROGRESS_END,
                        total=100,
                        message="安装包校验完成，正在解压",
                    )
                    extract_dir = temp_dir / "extract"
                    self._extract_zip(archive, extract_dir, task.id)
                    entries = [entry for entry in extract_dir.iterdir() if entry.is_dir()]
                    # 在解压结果中找真正含 java 的那层目录
                    source = next((entry for entry in entries if _binary_of(entry)), None)
                    if source is None:
                        source = entries[0] if len(entries) == 1 else extract_dir
                    if not _binary_of(source):
                        raise JavaError("解压后未找到 java 可执行文件")
                    self.tasks.progress(task.id, progress=EXTRACT_PROGRESS_END, message="正在安装 Java 文件")
                    if target.exists():
                        shutil.rmtree(target, ignore_errors=True)
                    # 同盘移动即时完成，几乎不会有半装状态
                    shutil.move(str(source), str(target))
                binary = _binary_of(target)
                if not binary:
                    raise JavaError("解压后未找到 java 可执行文件")
                release = _read_release(target)
                version = release.get("JAVA_VERSION") or package.get("version") or str(major)
                # 安装新 Java 后清缓存，下次枚举能看到它
                self._system_cache = None
                self.tasks.finish(
                    task.id,
                    {"path": binary, "version": version, "major": major},
                    f"Zulu Java {major} 安装完成",
                )
                # 通知前端刷新 Java 列表
                self.bus.publish(make_event("java.changed"))
                self.bus.log(f"Zulu Java {major} 已安装到 {target}", source="java")
            except Exception as error:
                self.tasks.fail(task.id, str(error))
                self.bus.log(f"Zulu Java {major} 安装失败: {error}", source="java", level="error")

        threading.Thread(target=worker, daemon=True).start()
        return task.snapshot()

    def ensure(self, mc_version: str, instance: dict[str, Any] | None = None) -> dict[str, Any] | None:
        """启动前的宽松检查：能解析到合适的 Java 就返回，否则触发一次后台安装。

        与 resolve_for_install 不同，这里不阻塞等待安装完成，
        只负责“顺手把缺的 Java 下下来”，适合非关键路径调用。
        """
        resolved = self.resolve(instance)
        if resolved and not resolved.get("mismatch"):
            return resolved
        if not bool(self.config.get("auto_download_java", True)):
            return resolved
        required = java_major_for_minecraft(mc_version)
        if any(int(item.get("major") or 0) == required for item in self.managed()):
            return self.resolve(instance)
        self.install(required)
        return resolved

    # ---------- 内部 ----------

    def _download(self, package: dict[str, Any], target: Path, task_id: str) -> int:
        """流式下载安装包，带进度、大小一致性检查、SHA-256 校验与重试。

        要点：
            1. 以 .part 为临时文件，成功后原子改名，避免半截文件被误用；
            2. 接口声明大小与服务器 Content-Length 不一致时直接报错，防止拿到错误文件；
            3. 按声明长度停止读取——服务器可能保持连接不关，不能等 EOF；
            4. 校验失败或异常时删除 .part，并最多重试 download_retries 次，间隔递增。

        返回实际写入的字节数。
        """
        expected_size = max(0, int(package.get("size") or 0))
        expected_sha256 = str(package.get("sha256") or "").strip().lower()
        self.tasks.progress(
            task_id,
            progress=0,
            total=100,
            message=f"下载 {package['name']}",
        )
        # 禁用压缩，保证收到的字节数等于 Content-Length
        headers = {"User-Agent": USER_AGENT, "Accept-Encoding": "identity"}
        last_error: Exception | None = None
        retries = int(self.config.get("download_retries", 3) or 3)
        timeout = int(self.config.get("download_timeout", 60) or 60)
        for attempt in range(1, max(1, retries) + 1):
            # 先写 .part，校验通过后才算正式文件
            part = target.with_suffix(target.suffix + ".part")
            try:
                with httpx.Client(timeout=timeout, follow_redirects=True, headers=headers) as client:
                    with client.stream("GET", package["url"]) as response:
                        response.raise_for_status()
                        content_length = _content_length(response)
                        # 接口声明大小与响应头长度可能同时存在，用于交叉校验
                        declared_sizes = {
                            size for size in (expected_size, content_length) if size > 0
                        }
                        if len(declared_sizes) > 1:
                            raise JavaError(
                                f"安装包大小信息不一致（接口 {expected_size}，服务器 {content_length}）"
                            )
                        total = next(iter(declared_sizes), 0)
                        written = 0
                        digest = hashlib.sha256()
                        with part.open("wb") as handle:
                            # 按块流式写入，避免把几百 MB 读进内存
                            for chunk in response.iter_raw(DOWNLOAD_CHUNK_SIZE):
                                if not chunk:
                                    continue
                                handle.write(chunk)
                                digest.update(chunk)
                                written += len(chunk)
                                progress = (
                                    min(
                                        DOWNLOAD_PROGRESS_END,
                                        int(written * DOWNLOAD_PROGRESS_END / total),
                                    )
                                    if total
                                    else 0
                                )
                                self.tasks.progress(
                                    task_id,
                                    progress=progress,
                                    total=100,
                                    message=_download_message(package["name"], written, total),
                                )
                                # Servers can report the full Content-Length while keeping the
                                # connection open. Stop after the declared file is complete
                                # instead of waiting indefinitely for another chunk.
                                # 达到声明长度立即停止，不等服务器关连接
                                if total and written >= total:
                                    break
                if total and written != total:
                    raise JavaError(f"安装包下载不完整（期望 {total} 字节，实际 {written} 字节）")
                if expected_sha256:
                    self.tasks.update(
                        task_id,
                        force=True,
                        progress=DOWNLOAD_PROGRESS_END,
                        total=100,
                        message="下载完成，正在校验 SHA-256",
                    )
                    # 哈希不符说明文件损坏或被篡改，必须拒绝
                    if digest.hexdigest() != expected_sha256:
                        raise JavaError("Zulu 安装包校验失败（SHA-256 不匹配）")
                # 原子改名，避免别的进程看到半截文件
                part.replace(target)
                return written
            except Exception as error:
                last_error = error
                try:
                    part.unlink(missing_ok=True)
                except Exception:
                    pass
                if attempt < retries:
                    self.tasks.progress(
                        task_id,
                        progress=0,
                        total=100,
                        message=f"下载中断，正在进行第 {attempt + 1} 次尝试",
                    )
                    time.sleep(min(1.5 * attempt, 6))
        raise JavaError(f"下载失败: {last_error}")

    def _extract_zip(self, archive: Path, extract_dir: Path, task_id: str) -> None:
        """解压安装包并按字节进度汇报（限流到每 0.1 秒最多一次）。

        进度区间取自 VERIFY_PROGRESS_END → EXTRACT_PROGRESS_END，
        文案带 (已完成/总数) 便于用户判断当前进度。
        """
        extract_dir.mkdir(parents=True, exist_ok=True)
        with zipfile.ZipFile(archive) as bundle:
            members = bundle.infolist()
            total_bytes = sum(info.file_size for info in members)
            extracted_bytes = 0
            last_report = 0.0
            for index, info in enumerate(members, start=1):
                # 逐个成员解压，便于统计进度
                bundle.extract(info, path=extract_dir)
                if not info.is_dir():
                    extracted_bytes += info.file_size
                now = time.monotonic()
                # 限流：最多每 0.1 秒上报一次，避免刷爆事件总线
                if index == len(members) or now - last_report >= 0.1:
                    progress = (
                        VERIFY_PROGRESS_END
                        + int(
                            (EXTRACT_PROGRESS_END - VERIFY_PROGRESS_END)
                            * extracted_bytes
                            / total_bytes
                        )
                        if total_bytes
                        else VERIFY_PROGRESS_END
                    )
                    self.tasks.progress(
                        task_id,
                        progress=min(EXTRACT_PROGRESS_END, progress),
                        total=100,
                        message=f"正在解压安装包（{index}/{len(members)}）",
                    )
                    last_report = now


def _content_length(response: httpx.Response) -> int:
    """读取响应头中的 Content-Length，非法值按 0 处理（表示长度未知）。
    """
    try:
        return max(0, int(response.headers.get("Content-Length") or 0))
    except (TypeError, ValueError):
        return 0


@contextmanager
def _temporary_directory(parent: Path) -> Iterator[Path]:
    """在指定父目录下创建临时目录，退出时自动删除。

    故意不用 tempfile.mkdtemp：它创建的 0700 目录在 Windows 上可能因 ACL 问题无法被子进程访问；同名冲突时最多重试 100 次。
    """
    parent.mkdir(parents=True, exist_ok=True)
    directory: Path | None = None
    for _ in range(100):
        candidate = parent / f"neo-java-{uuid.uuid4().hex}"
        try:
            # Path.mkdir inherits the parent directory's Windows ACL. The bundled
            # Python's tempfile.mkdtemp can create inaccessible 0700 directories.
            # 用 mkdir 继承父目录 ACL，而不是 mkdtemp 的 0700
            candidate.mkdir()
            directory = candidate
            break
        except FileExistsError:
            continue
    if directory is None:
        raise JavaError("无法创建 Java 安装临时目录")
    try:
        yield directory
    finally:
        shutil.rmtree(directory, ignore_errors=True)


def _format_bytes(value: int) -> str:
    """把字节数格式化为人类可读的 B / KB / MB / GB。
    """
    size = max(0, int(value or 0))
    if size < 1024:
        return f"{size} B"
    if size < 1024**2:
        return f"{size / 1024:.1f} KB"
    if size < 1024**3:
        return f"{size / 1024**2:.1f} MB"
    return f"{size / 1024**3:.2f} GB"


def _download_message(name: str, written: int, total: int) -> str:
    """构造下载进度文案；长度未知时只显示已下载量。
    """
    if total:
        return f"下载 {name} · {_format_bytes(written)} / {_format_bytes(total)}"
    return f"下载 {name} · {_format_bytes(written)}"


def _major_of(version: str) -> int:
    """从版本字符串中提取 Java 大版本号。

    兼容两种写法：1.8.0_392 → 8（取第二段），21.0.8 → 21；
    无法识别时返回 0。
    """
    text = (version or "").strip()
    if not text:
        return 0
    match = re.match(r"^(\d+)", text)
    if not match:
        return 0
    major = int(match.group(1))
    # 老版本号形如 1.8.0_392，大版本是第二段
    if major == 1:
        parts = text.split(".")
        if len(parts) >= 2 and parts[1].isdigit():
            return int(parts[1])
        return 1
    return major


def _version_from_binary(binary: Path) -> str:
    """获取指定 java 可执行文件的版本号。

    先读 release 文件（快且无副作用），失败时再执行 java -version，
    从输出里用正则提取 version "x.y.z"（该输出走 stderr）。
    """
    home = _java_home_of(binary)
    release = _read_release(home)
    if release.get("JAVA_VERSION"):
        return release["JAVA_VERSION"]
    version = release.get("JAVA_RUNTIME_VERSION") or ""
    if version:
        return version
    try:
        import subprocess

        # Windows 下避免弹出控制台窗口
        creationflags = subprocess.CREATE_NO_WINDOW if os.name == "nt" else 0
        output = subprocess.run(
            [str(binary), "-version"],
            capture_output=True,
            text=True,
            timeout=8,
            creationflags=creationflags,
        )
        text = (output.stderr or "") + (output.stdout or "")
        # java -version 的输出走 stderr，需合并后再匹配
        match = re.search(r'version "([^"]+)"', text)
        if match:
            return match.group(1)
    except Exception:
        pass
    return ""


JavaProgressCallback = Callable[[int, int], None]
