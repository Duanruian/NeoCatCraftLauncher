"""启动器核心服务模块。

主要职责：
    1. 版本管理 —— 拉取官方版本清单（含愚人节版本、快照、远古版本分类）
       与本地已安装版本识别（含 Fabric/Quilt/Forge/NeoForge 判断）；
    2. 安装 —— 下载原版、自动安装模组加载器、从本地 JAR 安装加载器；
    3. 实例编排 —— 创建/修复实例，把 mc_version + loader 解析成可启动的 version_id；
    4. 启动 —— 组装 JVM 参数与命令行（内存、authlib-injector、自定义分辨率），
       拉起游戏进程并接管输出流、统计游玩时长。

长耗时操作（下载、安装、启动）统一交给后台线程 + TaskManager 汇报进度，
接口本身只返回任务快照，避免阻塞 UI。
"""

from __future__ import annotations

import hashlib
import json
import os
import re
import shutil
import subprocess
import tempfile
import threading
import time
import zipfile
from pathlib import Path
from typing import Any

import minecraft_launcher_lib as mll

from .auth import AuthService
from .config import APP_NAME, APP_VERSION, LEGACY_JVM_ARGS, SAFE_JVM_ARGS, Config
from .events import EventBus, make_event
from .instances import InstanceError, InstanceManager
from .java_manager import JavaError, JavaManager, java_major_for_minecraft
from .tasks import TaskManager

# 已知愚人节版本的版本 ID 白名单
APRIL_FOOLS_VERSION_IDS = {
    "15w14a",
    "1.rv-pre1",
    "3d shareware v1.34",
    "20w14∞",
    "22w13oneblockatatime",
    "23w13a_or_b",
    "24w14potato",
    "25w14craftmine",
}

def classify_version(version_id: str, version_type: str, release_time: Any = None) -> str:
    """对版本做展示分类：远古版本（alpha/beta）、正式版、愚人节玩笑版、快照。

    愚人节判定同时看版本号白名单与发布时间（4 月 1 日），
    因为部分愚人节版本的 type 字段仍是 snapshot。
    """
    kind = str(version_type or "").strip().lower()
    identifier = str(version_id or "").strip().lower()
    # 远古版本单独归类，便于前端折叠展示
    if kind in {"old_alpha", "old_beta", "alpha", "beta"}:
        return "ancient"
    if kind == "release":
        return "release"
    # 取日期部分判断是否为 4 月 1 日发布
    released_on_april_first = str(release_time or "")[5:10] == "04-01"
    # 白名单或发布日期命中任一即视为愚人节版本
    if identifier in APRIL_FOOLS_VERSION_IDS or released_on_april_first:
        return "april_fools"
    return "snapshot"


def guess_loader(version_id: str) -> str:
    """根据版本 ID 猜测模组加载器类型。

    按特征从强到弱依次判断：fabric/quilt 的 loader 前缀 → neoforge →
    forge（Forge 版本 ID 中通常只含 forge 字样）。默认按原版处理。
    """
    lowered = (version_id or "").lower()
    if lowered.startswith("fabric-loader-") or "-fabric-" in lowered:
        return "fabric"
    if lowered.startswith("quilt-loader-") or "-quilt-" in lowered:
        return "quilt"
    # NeoForge 要优先于 forge 判断，否则会被 forge 分支吞掉
    if lowered.startswith("neoforge-") or "-neoforge-" in lowered:
        return "neoforge"
    if "forge" in lowered:
        return "forge"
    return "vanilla"


def parse_loader_version(loader: str, version_id: str, mc_version: str) -> str:
    """从版本 ID 中反解出加载器版本号。

    各加载器的 ID 命名规则不同，用正则逐一匹配；
    匹配失败时退而取最后一段，作为兜底值。
    """
    value = version_id or ""
    loader = (loader or "").lower()
    patterns = {
        "fabric": rf"^fabric-loader-(.+)-{re.escape(mc_version)}$",
        "quilt": rf"^quilt-loader-(.+)-{re.escape(mc_version)}$",
        # Forge 的 ID 形如 <mc版本>-forge-<加载器版本>
        "forge": rf"^{re.escape(mc_version)}-forge-(.+)$",
        # NeoForge 的 ID 形如 neoforge-<版本>
        "neoforge": r"^neoforge-(.+)$",
    }
    pattern = patterns.get(loader)
    if pattern:
        match = re.match(pattern, value)
        if match:
            return match.group(1)
    if loader and loader != "vanilla" and "-" in value:
        return value.rsplit("-", 1)[-1]
    return ""


def install_mod_loader(
    loader: str,
    minecraft_version: str,
    minecraft_directory: str,
    loader_version: str | None,
    callback: dict[str, Any],
    java_path: str,
) -> tuple[str, str]:
    """用 minecraft_launcher_lib 安装模组加载器（联网自动下载安装器）。

    未指定加载器版本时取最新版；安装后若库未返回版本 ID，
    再查一次已安装版本，仍拿不到则视为失败（否则后续无法启动）。
    """
    module = mll.mod_loader.get_mod_loader(loader)
    # 未指定版本时默认装最新
    selected_version = loader_version or module.get_latest_loader_version(minecraft_version)
    installed_version = module.install(
        minecraft_version,
        minecraft_directory,
        loader_version=selected_version,
        callback=callback,
        java=java_path,
    )
    if not installed_version:
        installed_version = module.get_installed_version(minecraft_version, selected_version)
    if not installed_version:
        raise RuntimeError(f"{module.get_name()} 安装后没有返回可启动的版本 ID")
    resolved_loader_version = (
        parse_loader_version(loader, str(installed_version), minecraft_version) or selected_version
    )
    return str(installed_version), str(resolved_loader_version)


def _jar_text(archive: zipfile.ZipFile, name: str) -> str:
    """安全读取 JAR 包内文本条目，失败或条目缺失返回空串。

    超过 4 MB 的条目不读，避免误读资源文件造成内存暴涨。
    """
    try:
        info = archive.getinfo(name)
    except KeyError:
        return ""
    # 过大的条目多半是资源文件，跳过不读
    if info.file_size > 4 * 1024 * 1024:
        return ""
    data = archive.read(name)
    return data.decode("utf-8", errors="replace")


def _detect_loader_type(*values: Any) -> str:
    """根据多个文本片段中的关键字判断加载器类型。

    传入文件名、manifest、条目列表等任意信息，命中最具体者优先
    （先 neoforge/quilt，再 fabric，最后 forge）。
    """
    text = " ".join(str(value or "") for value in values).lower()
    if "neoforge" in text or "neoforged" in text:
        return "neoforge"
    if "quilt" in text:
        return "quilt"
    if "fabric" in text:
        return "fabric"
    if "forge" in text:
        return "forge"
    return ""


def inspect_mod_loader_jar(installer_path: str | Path) -> dict[str, Any]:
    """解析本地加载器安装包，提取加载器类型、Minecraft 版本与加载器版本。

    处理思路：
        1. 先算 SHA-256（用于缓存命名与去重）；
        2. 读 install_profile.json 与 MANIFEST.MF：
           Forge/NeoForge 用 install/versionInfo 里的字段；
           Fabric/Quilt 的安装器没有 install_profile，改为校验 manifest 与条目路径；
        3. 元信息缺失时，退回到“从文件名正则解析”，再不行按 NeoForge 的
           “<mc 主>.<次>”版本号规则推断对应 Minecraft 版本；
        4. 最终仍无法确定类型或缺少必要文件则抛错，不做猜测性安装。
    """
    path = Path(installer_path).expanduser().resolve()
    if path.suffix.lower() != ".jar" or not path.is_file():
        raise ValueError("请选择有效的模组加载器 .jar 安装包")

    # 用内容哈希标识安装包，避免同名不同内容混淆
    digest = hashlib.sha256()
    with path.open("rb") as handle:
        # 分块读取，防止大文件一次性载入内存
        for chunk in iter(lambda: handle.read(1024 * 1024), b""):
            digest.update(chunk)

    loader = _detect_loader_type(path.name)
    minecraft_version = ""
    loader_version = ""
    profile: dict[str, Any] = {}
    manifest = ""
    profile_text = ""
    entry_names: list[str] = []
    try:
        with zipfile.ZipFile(path) as archive:
            entry_names = archive.namelist()
            # Forge/NeoForge 安装器的元信息入口
            profile_text = _jar_text(archive, "install_profile.json")
            # Fabric/Quilt 安装器的类型标记藏在这里
            manifest = _jar_text(archive, "META-INF/MANIFEST.MF")
            if profile_text:
                profile = json.loads(profile_text)
    except (OSError, zipfile.BadZipFile, json.JSONDecodeError) as error:
        raise ValueError(f"无法读取安装包: {error}") from error

    install_data = profile.get("install") if isinstance(profile.get("install"), dict) else {}
    version_info = profile.get("versionInfo") if isinstance(profile.get("versionInfo"), dict) else {}
    minecraft_version = str(
        profile.get("minecraft")
        or install_data.get("minecraft")
        or version_info.get("inheritsFrom")
        or ""
    ).strip()
    raw_version = str(
        profile.get("version")
        or install_data.get("version")
        or version_info.get("id")
        or ""
    ).strip()
    loader = loader or _detect_loader_type(
        profile_text,
        manifest,
        "\n".join(entry_names),
        raw_version,
        profile.get("path"),
        install_data.get("path"),
    )

    if loader == "forge":
        path_spec = str(profile.get("path") or install_data.get("path") or "")
        match = re.search(r"forge:([^:]+)", path_spec)
        if match and not minecraft_version:
            spec_parts = match.group(1).split("-", 1)
            if len(spec_parts) == 2:
                minecraft_version, raw_version = spec_parts
        if minecraft_version and raw_version.startswith(f"{minecraft_version}-"):
            raw_version = raw_version[len(minecraft_version) + 1 :]
        match = re.search(r"-forge-([^/\\]+)$", raw_version, re.IGNORECASE)
        if match:
            raw_version = match.group(1)
    elif loader == "neoforge":
        path_spec = str(profile.get("path") or install_data.get("path") or "")
        match = re.search(r"neoforge:([^:]+)", path_spec, re.IGNORECASE)
        if match:
            raw_version = match.group(1)
        raw_version = re.sub(r"^neoforge-", "", raw_version, flags=re.IGNORECASE)
        if minecraft_version and raw_version.startswith(f"{minecraft_version}-"):
            raw_version = raw_version[len(minecraft_version) + 1 :]
        match = re.search(r"(?:^|-)neoforge-([^/\\]+)$", raw_version, re.IGNORECASE)
        if match:
            raw_version = match.group(1)

    if loader == "forge" and not raw_version:
        match = re.match(
            r"forge-(?P<mc>\d+\.\d+(?:\.\d+)?)-(?P<loader>.+?)(?:-installer)?\.jar$",
            path.name,
            re.IGNORECASE,
        )
        if match:
            minecraft_version = match.group("mc")
            raw_version = match.group("loader")
    elif loader == "neoforge" and not raw_version:
        match = re.match(
            r"neoforge-(?P<loader>.+?)(?:-installer)?\.jar$",
            path.name,
            re.IGNORECASE,
        )
        if match:
            raw_version = match.group("loader")

    if loader == "neoforge" and not minecraft_version:
        match = re.match(r"(\d+)\.(\d+)(?:\.|$)", raw_version)
        if match:
            major, minor = match.groups()
            # NeoForge 版本号前半段与 Minecraft 版本对应（如 21.1 → 1.21.1）
            minecraft_version = f"1.{major}" if minor == "0" else f"1.{major}.{minor}"

    if not loader:
        raise ValueError("无法从安装包识别加载器类型，请确认下载的是 Forge、NeoForge、Fabric 或 Quilt 安装器")
    # 缺少 install_profile.json 的只能是 Fabric/Quilt 安装器
    if not profile and loader not in {"fabric", "quilt"}:
        raise ValueError("该 JAR 不是可用的加载器安装包，缺少 install_profile.json")
    if loader in {"fabric", "quilt"}:
        installer_text = f"{manifest}\n" + "\n".join(entry_names)
        markers = (
            ("fabricmc/installer", "fabricmc.installer")
            if loader == "fabric"
            else ("quiltmc/installer", "quiltmc.installer")
        )
        if not any(marker.lower() in installer_text.lower() for marker in markers):
            raise ValueError(f"该 JAR 不是有效的 {loader.title()} 官方安装器")

    return {
        "path": str(path),
        "file_name": path.name,
        "size": path.stat().st_size,
        "sha256": digest.hexdigest(),
        "loader": loader,
        "minecraft_version": minecraft_version,
        "loader_version": raw_version,
    }


def cache_mod_loader_jar(config: Config, installer_path: str | Path) -> Path:
    """把本地安装器缓存到配置目录，避免用户删掉原文件后无法修复实例。

    文件名用内容哈希前 16 位做前缀，保证同名不同内容不会互相覆盖。
    """
    details = inspect_mod_loader_jar(installer_path)
    # 清洗文件名，防止路径穿越与非法字符
    safe_name = re.sub(r"[^A-Za-z0-9._-]+", "-", Path(details["file_name"]).name)
    target_dir = config.dir / "loader-installers"
    target_dir.mkdir(parents=True, exist_ok=True)
    target = target_dir / f"{details['sha256'][:16]}-{safe_name}"
    if not target.is_file():
        shutil.copyfile(details["path"], target)
    return target


def _loader_installer_command(
    loader: str,
    minecraft_version: str,
    loader_version: str,
    minecraft_directory: str,
    installer_path: str,
    java_path: str,
) -> list[str]:
    """拼装各加载器官方安装器的命令行参数。

    Forge/NeoForge 用 --installClient；Fabric 需要指定 -mcversion/-loader 并 -noprofile；
    Quilt 用 install client 子命令加 --install-dir。
    """
    if loader in {"forge", "neoforge"}:
        # Forge/NeoForge 安装器只认 --installClient
        return [java_path, "-jar", installer_path, "--installClient", minecraft_directory]
    if loader == "fabric":
        return [
            java_path,
            "-jar",
            installer_path,
            "client",
            "-dir",
            minecraft_directory,
            "-mcversion",
            minecraft_version,
            "-loader",
            loader_version,
            "-noprofile",
            "-snapshot",
        ]
    if loader == "quilt":
        return [
            java_path,
            "-jar",
            installer_path,
            "install",
            "client",
            minecraft_version,
            loader_version,
            f"--install-dir={minecraft_directory}",
            "--no-profile",
        ]
    raise ValueError(f"不支持从 JAR 安装的加载器: {loader}")


def install_mod_loader_from_jar(
    loader: str,
    minecraft_version: str,
    minecraft_directory: str,
    loader_version: str,
    installer_path: str | Path,
    callback: dict[str, Any],
    java_path: str,
) -> tuple[str, str]:
    """用本地安装包离线安装模组加载器。

    执行顺序：
        1. 校验安装包类型与 Minecraft 版本是否与实例匹配（不匹配直接报错）；
        2. 先装原版，Forge/NeoForge 还需补一个空的 launcher_profiles.json，
           否则官方安装器会拒绝执行；
        3. 在临时目录中运行官方安装器（工作目录隔离，避免污染游戏目录）；
        4. 校验版本 JSON 是否真的生成，再安装该版本的依赖库；
    失败时把安装器输出的最后几行带进异常，便于定位问题。
    """
    details = inspect_mod_loader_jar(installer_path)
    detected_loader = str(details.get("loader") or "").lower()
    # 安装包类型与用户选择不一致时直接拒绝
    if loader != detected_loader:
        raise ValueError(
            f"安装包属于 {detected_loader.title()}，与当前选择的 {loader.title()} 不一致"
        )
    detected_mc = str(details.get("minecraft_version") or "")
    # 版本不匹配时装了也用不了，提前报错
    if detected_mc and detected_mc != minecraft_version:
        raise ValueError(
            f"安装包适用于 Minecraft {detected_mc}，与实例的 {minecraft_version} 不一致"
        )
    selected_version = (loader_version or str(details.get("loader_version") or "")).strip()
    if not selected_version:
        raise ValueError("无法从该安装包读取加载器版本，请手动填写")

    set_status = callback.get("setStatus", lambda _: None)
    # 安装加载器前必须先有原版文件
    set_status(f"准备 Minecraft {minecraft_version}")
    mll.install.install_minecraft_version(
        minecraft_version,
        minecraft_directory,
        callback=callback,
    )
    # Forge 安装器要求存在 launcher_profiles.json，缺失时补一个空文件
    if loader in {"forge", "neoforge"} and not mll.vanilla_launcher.do_vanilla_launcher_profiles_exists(
        minecraft_directory
    ):
        mll.vanilla_launcher.create_empty_vanilla_launcher_profiles_file(minecraft_directory)

    command = _loader_installer_command(
        loader,
        minecraft_version,
        selected_version,
        minecraft_directory,
        str(Path(installer_path).resolve()),
        java_path,
    )
    set_status(f"运行 {loader.title()} 官方安装器")
    creation_flags = subprocess.CREATE_NO_WINDOW if os.name == "nt" else 0
    with tempfile.TemporaryDirectory(prefix="neo-loader-installer-") as tempdir:
        result = subprocess.run(
            command,
            cwd=tempdir,
            capture_output=True,
            text=True,
            encoding="utf-8",
            errors="replace",
            creationflags=creation_flags,
            check=False,
        )
    if result.returncode != 0:
        output = (result.stderr or result.stdout or "").strip()
        # 只保留最后 18 行，避免错误信息过长
        tail = "\n".join(output.splitlines()[-18:])
        raise RuntimeError(
            f"官方安装器执行失败（退出码 {result.returncode}）"
            + (f":\n{tail}" if tail else "")
        )

    module = mll.mod_loader.get_mod_loader(loader)
    installed_version = module.get_installed_version(minecraft_version, selected_version)
    version_json = (
        Path(minecraft_directory)
        / "versions"
        / installed_version
        / f"{installed_version}.json"
    )
    # 安装器可能“成功退出但什么也没装”，必须核对产物
    if not version_json.is_file():
        raise RuntimeError(
            f"安装器已结束，但没有生成版本 {installed_version}。"
            "请确认 Minecraft 与加载器版本匹配。"
        )
    set_status("检查加载器文件")
    mll.install.install_minecraft_version(
        installed_version,
        minecraft_directory,
        callback=callback,
    )
    return installed_version, parse_loader_version(
        loader, installed_version, minecraft_version
    ) or selected_version


class LauncherService:
    def __init__(
        self,
        config: Config,
        tasks: TaskManager,
        bus: EventBus,
        instances: InstanceManager,
        java: JavaManager,
        auth: AuthService,
    ) -> None:
        """初始化服务并持有各子服务引用；
        _version_cache 为版本清单的短时缓存（5 分钟），_processes 记录运行中的游戏进程。
        """
        self.config = config
        self.tasks = tasks
        self.bus = bus
        self.instances = instances
        self.java = java
        self.auth = auth
        self._version_cache: tuple[float, list[dict[str, Any]]] | None = None
        self._processes: dict[int, subprocess.Popen] = {}
        self._lock = threading.Lock()

    # ---------- 版本 ----------

    def library_version(self) -> str:
        """返回底层 minecraft_launcher_lib 的版本号，用于诊断。
        """
        return mll.utils.get_library_version()

    def available_versions(self, force: bool = False) -> list[dict[str, Any]]:
        """获取可安装的版本清单（含分类）。

        默认走 5 分钟缓存，force=True 时强制刷新；
        发布时间统一转成 ISO 字符串，方便前端直接展示。
        """
        now = time.time()
        # 5 分钟内复用缓存，减少对官方接口的请求
        if not force and self._version_cache and now - self._version_cache[0] < 300:
            return self._version_cache[1]
        raw = mll.utils.get_version_list()
        versions = [
            {
                "id": item["id"],
                "type": item["type"],
                "category": classify_version(item["id"], item["type"], item.get("releaseTime")),
                "releaseTime": item["releaseTime"].isoformat() if hasattr(item["releaseTime"], "isoformat") else str(item["releaseTime"]),
            }
            for item in raw
        ]
        self._version_cache = (now, versions)
        return versions

    def installed_versions(self) -> list[dict[str, Any]]:
        """列出本地已安装版本，附带加载器类型，按发布时间倒序。
        """
        directory = str(self.config.minecraft_directory)
        result = []
        for item in mll.utils.get_installed_versions(directory):
            version_id = item["id"]
            release = item.get("releaseTime")
            result.append(
                {
                    "id": version_id,
                    "type": item.get("type", "unknown"),
                    "category": classify_version(version_id, item.get("type", "unknown"), release),
                    "loader": guess_loader(version_id),
                    "releaseTime": release.isoformat() if hasattr(release, "isoformat") else str(release),
                }
            )
        # 新版本排前面
        result.sort(key=lambda entry: entry["releaseTime"], reverse=True)
        return result

    def install_version(self, version_id: str, instance_id: str | None = None) -> dict[str, Any]:
        """后台安装某个原版版本。

        成功后清空版本缓存、可选地回写实例的版本字段，
        并广播 versions.changed / instances.changed 事件让前端刷新。
        """
        # 创建任务，前端凭任务 ID 订阅进度
        task = self.tasks.create("install", f"安装 Minecraft {version_id}")
        self.bus.log(f"开始安装 Minecraft {version_id}", source="install")

        def worker() -> None:
            try:
                mll.install.install_minecraft_version(
                    version_id,
                    str(self.config.minecraft_directory),
                    callback=self._callback(task.id),
                )
                self.tasks.finish(task.id, {"version": version_id}, "安装完成")
                self._version_cache = None
                if instance_id:
                    self.instances.update(instance_id, {"version_id": version_id, "mc_version": version_id, "loader": "vanilla"})
                self.bus.publish(make_event("versions.changed"))
                self.bus.publish(make_event("instances.changed"))
                self.bus.log(f"Minecraft {version_id} 安装完成", source="install")
            except Exception as error:
                self.tasks.fail(task.id, str(error))
                self.bus.log(f"安装失败: {error}", source="install", level="error")

        threading.Thread(target=worker, daemon=True).start()
        return task.snapshot()

    # ---------- 实例编排 ----------

    def provision_instance(self, payload: dict[str, Any]) -> dict[str, Any]:
        """创建实例并按其配置安装对应版本。

        流程：先建实例记录（立刻可见）→ 后台安装：
            有本地安装包则用 install_mod_loader_from_jar，并把缓存路径写回实例；
            否则联网安装加载器；纯原版则直接装原版。
        最后把解析出的真实 version_id 与加载器版本写回实例，避免每次启动重复推断。
        """
        instance = self.instances.create(payload)
        instance_id = instance["id"]
        mc_version = instance["mc_version"]
        loader = instance.get("loader") or "vanilla"
        loader_version = instance.get("loader_version") or None
        local_installer = instance.get("loader_installer") or ""
        task = self.tasks.create("instance", f"创建实例 {instance['name']}")
        self.bus.log(f"创建实例 {instance['name']}（{mc_version} / {loader}）", source="instance")

        def worker() -> None:
            try:
                self.tasks.progress(task.id, message=f"安装 Minecraft {mc_version}")
                version_id = mc_version
                if loader and loader != "vanilla":
                    self.tasks.progress(task.id, message=f"安装 {loader} 加载器")
                    # 安装加载器所需的 Java 可能与运行时可执行文件不同
                    java_path = self.java.resolve_for_install(mc_version)
                    if local_installer:
                        cached_installer = cache_mod_loader_jar(self.config, local_installer)
                        # 后续校验与修复都依赖缓存后的路径
                        local_installer = str(cached_installer)
                        self.instances.update(
                            instance_id,
                            {"loader_installer": local_installer},
                        )
                        version_id, resolved_loader_version = install_mod_loader_from_jar(
                            loader,
                            mc_version,
                            str(self.config.minecraft_directory),
                            loader_version or "",
                            cached_installer,
                            self._callback(task.id),
                            java_path,
                        )
                    else:
                        version_id, resolved_loader_version = install_mod_loader(
                            loader,
                            mc_version,
                            str(self.config.minecraft_directory),
                            loader_version,
                            self._callback(task.id),
                            java_path,
                        )
                else:
                    mll.install.install_minecraft_version(
                        mc_version,
                        str(self.config.minecraft_directory),
                        callback=self._callback(task.id),
                    )
                    resolved_loader_version = ""
                self.instances.update(
                    instance_id,
                    {
                        "version_id": version_id,
                        "loader": loader,
                        "loader_version": resolved_loader_version or (loader_version or ""),
                        "loader_installer": local_installer,
                    },
                )
                self._version_cache = None
                self.tasks.finish(task.id, {"instance": instance_id, "version": version_id}, "实例创建完成")
                self.bus.publish(make_event("versions.changed"))
                self.bus.publish(make_event("instances.changed"))
                self.bus.log(f"实例 {instance['name']} 创建完成，版本 ID: {version_id}", source="instance")
            except Exception as error:
                self.tasks.fail(task.id, str(error))
                self.bus.log(f"实例创建失败: {error}", source="instance", level="error")

        threading.Thread(target=worker, daemon=True).start()
        return {"instance": self.instances.snapshot(self.instances.require(instance_id)), "task": task.snapshot()}

    def repair_instance(self, instance_id: str) -> dict[str, Any]:
        """修复实例：按实例已记录的配置重新安装一遍版本与加载器。

        优先复用已缓存的本地安装包，缺失时才联网下载。
        """
        instance = self.instances.require(instance_id)
        task = self.tasks.create("instance", f"修复实例 {instance['name']}")

        def worker() -> None:
            try:
                mc_version = instance["mc_version"]
                loader = instance.get("loader") or "vanilla"
                self.tasks.progress(task.id, message=f"校验 Minecraft {mc_version}")
                version_id = mc_version
                if loader and loader != "vanilla":
                    local_installer = str(instance.get("loader_installer") or "")
                    # 只有缓存的安装包仍然存在才走离线安装
                    if local_installer and Path(local_installer).is_file():
                        version_id, resolved_loader_version = install_mod_loader_from_jar(
                            loader,
                            mc_version,
                            str(self.config.minecraft_directory),
                            instance.get("loader_version") or "",
                            local_installer,
                            self._callback(task.id),
                            self.java.resolve_for_install(mc_version),
                        )
                    else:
                        version_id, resolved_loader_version = install_mod_loader(
                            loader,
                            mc_version,
                            str(self.config.minecraft_directory),
                            instance.get("loader_version") or None,
                            self._callback(task.id),
                            self.java.resolve_for_install(mc_version),
                        )
                else:
                    mll.install.install_minecraft_version(
                        mc_version,
                        str(self.config.minecraft_directory),
                        callback=self._callback(task.id),
                    )
                    resolved_loader_version = ""
                self.instances.update(
                    instance_id,
                    {
                        "version_id": version_id,
                        "loader": loader,
                        "loader_version": resolved_loader_version or instance.get("loader_version") or "",
                        "loader_installer": instance.get("loader_installer") or "",
                    },
                )
                self.tasks.finish(task.id, {"instance": instance_id}, "实例修复完成")
                self.bus.publish(make_event("instances.changed"))
            except Exception as error:
                self.tasks.fail(task.id, str(error))

        threading.Thread(target=worker, daemon=True).start()
        return task.snapshot()

    # ---------- 模组加载器 ----------

    def loader_list(self) -> list[dict[str, str]]:
        """列出所有支持的模组加载器。
        """
        return [
            {"id": loader, "name": mll.mod_loader.get_mod_loader(loader).get_name()}
            for loader in mll.mod_loader.list_mod_loader()
        ]

    def loader_versions(self, loader: str, minecraft_version: str) -> dict[str, Any]:
        """查询某加载器对指定 Minecraft 版本的可用加载器版本。

        先判断兼容性，不兼容时返回空列表并标记 supported=False，
        前端可据此给出“当前版本不支持该加载器”的提示。
        """
        module = mll.mod_loader.get_mod_loader(loader)
        supported = module.is_minecraft_version_supported(minecraft_version)
        versions = module.get_loader_versions(minecraft_version, True) if supported else []
        return {
            "loader": loader,
            "minecraft_version": minecraft_version,
            "supported": supported,
            "versions": versions,
        }

    def loader_minecraft_versions(self, loader: str, stable_only: bool = True) -> list[str]:
        """查询某加载器支持的所有 Minecraft 版本（默认只列稳定版）。
        """
        # stable_only 为真时仅返回正式版
        return mll.mod_loader.get_mod_loader(loader).get_minecraft_versions(stable_only)

    def inspect_loader_jar(self, installer_path: str) -> dict[str, Any]:
        """供前端校验用户选择的本地安装包，返回解析结果。
        """
        return inspect_mod_loader_jar(installer_path)

    def install_loader(
        self,
        loader: str,
        minecraft_version: str,
        loader_version: str | None = None,
        instance_id: str | None = None,
        installer_path: str | None = None,
    ) -> dict[str, Any]:
        """单独安装模组加载器（不改动实例创建流程）。

        installer_path 存在时走本地安装包路径，否则自动下载官方安装器；
        结束时可选地更新指定实例的版本信息。
        """
        module = mll.mod_loader.get_mod_loader(loader)
        name = module.get_name()
        # 任务标题里体现安装来源，方便用户区分
        source_label = "本地安装包" if installer_path else "自动下载官方安装器"
        task = self.tasks.create("loader", f"安装 {name} @ {minecraft_version} · {source_label}")
        self.bus.log(f"开始安装 {name} ({minecraft_version})", source="loader")

        def worker() -> None:
            try:
                cached_installer = ""
                if installer_path:
                    cached_path = cache_mod_loader_jar(self.config, installer_path)
                    cached_installer = str(cached_path)
                    installed, resolved_loader_version = install_mod_loader_from_jar(
                        loader,
                        minecraft_version,
                        str(self.config.minecraft_directory),
                        loader_version or "",
                        cached_path,
                        self._callback(task.id),
                        self.java.resolve_for_install(minecraft_version),
                    )
                else:
                    installed, resolved_loader_version = install_mod_loader(
                        loader,
                        minecraft_version,
                        str(self.config.minecraft_directory),
                        loader_version,
                        self._callback(task.id),
                        self.java.resolve_for_install(minecraft_version),
                    )
                self.tasks.finish(task.id, {"version": installed, "loader": loader}, "加载器安装完成")
                self._version_cache = None
                if instance_id:
                    self.instances.update(
                        instance_id,
                        {
                            "version_id": installed,
                            "loader": loader,
                            "loader_version": resolved_loader_version,
                            "loader_installer": cached_installer,
                        },
                    )
                self.bus.publish(make_event("versions.changed"))
                self.bus.publish(make_event("instances.changed"))
                self.bus.log(f"{name} 安装完成，版本 ID: {installed}", source="loader")
            except Exception as error:
                self.tasks.fail(task.id, str(error))
                self.bus.log(f"{name} 安装失败: {error}", source="loader", level="error")

        threading.Thread(target=worker, daemon=True).start()
        return task.snapshot()

    # ---------- 启动 ----------

    def java_executable(self, instance: dict[str, Any] | None = None) -> str:
        """选出要使用的 Java 可执行文件路径。

        Windows 下若命中 javaw.exe 会优先换成 java.exe，
        因为后续需要读取 --version 的控制台输出做校验；没有可用 Java 则抛 JavaError。
        """
        resolved = self.java.resolve(instance)
        if resolved and resolved.get("path"):
            executable = Path(str(resolved["path"]))
            if os.name == "nt" and executable.name.lower() == "javaw.exe":
                # 改用带控制台的 java.exe 以便捕获版本输出
                console_java = executable.with_name("java.exe")
                try:
                    if console_java.is_file():
                        return str(console_java)
                except OSError:
                    pass
            return str(executable)
        # 给出可操作的引导，而不是空错误
        raise JavaError("未找到可用的 Java。请先在 Java 运行时页面下载 Zulu。")

    def _validate_java_runtime(
        self,
        executable: str,
        required_major: int,
        memory: int,
        min_memory: int,
        jvm_arguments: list[str],
    ) -> None:
        """启动前的 Java 预检。

        带真实内存参数试跑 -version，用途有三：
            1. 确认 JVM 能接受这组参数与内存（内存过大直接暴露）；
            2. 解析实际 Java 主版本，低于实例要求则报错；
            3. 检测 32 位 Java，内存超过 1300 MB 时明确提示。
        提前失败比游戏启动到一半崩掉更容易定位问题。
        """
        try:
            binary = Path(executable)
            if not binary.is_file():
                raise JavaError(f"Java 可执行文件不存在或无法访问: {executable}")
            command = [
                str(binary),
                f"-Xmx{memory}M",
                f"-Xms{min_memory}M",
                *jvm_arguments,
                # 让 JVM 打印系统属性，用于检测 32 位环境
                "-XshowSettings:properties",
                "-version",
            ]
            creationflags = subprocess.CREATE_NO_WINDOW if os.name == "nt" else 0
            probe = subprocess.run(
                command,
                capture_output=True,
                text=True,
                encoding="utf-8",
                errors="replace",
                # 预检设超时，避免 JVM 卡死拖住启动流程
                timeout=15,
                creationflags=creationflags,
            )
        except JavaError:
            raise
        except Exception as error:
            raise JavaError(f"无法启动 Java 运行环境: {error}") from error
        output = ((probe.stdout or "") + "\n" + (probe.stderr or "")).strip()
        if probe.returncode != 0:
            detail = output.splitlines()[-3:] if output else []
            raise JavaError(
                "Java 运行环境预检失败"
                + ("：" + " / ".join(detail) if detail else "，请重新安装或更换 Java")
            )
        # 从 -version 输出中提取版本号
        version_match = re.search(r'version "([^"]+)"', output)
        if version_match:
            detected = version_match.group(1)
            detected_major = int(detected.split(".")[0])
            # Java 8 及更早版本号形如 1.8.0_xxx，主版本取第二段
            if detected_major == 1 and "." in detected:
                detected_major = int(detected.split(".")[1])
            if detected_major < required_major:
                raise JavaError(
                    f"当前 Java {detected_major} 低于实例要求的 Java {required_major}"
                )
        # 32 位 JVM 可用堆上限约 1.3 GB
        if "sun.arch.data.model = 32" in output and memory > 1300:
            raise JavaError("当前是 32 位 Java，无法分配 " + str(memory) + " MB 内存")

    def build_command(self, instance: dict[str, Any], account: dict[str, Any]) -> list[str]:
        """组装完整的游戏启动命令。

        要点：
            1. 内存取实例配置，缺省回落到全局设置；校验下限与“最小值不得大于最大值”；
            2. 旧版默认 JVM 参数（LEGACY_JVM_ARGS）会自动替换成安全参数；
            3. 第三方登录账户追加 authlib-injector 的 -javaagent 参数，注入失败只记日志、不阻断启动；
            4. 分辨率仅在启用时下发 customResolution；
            5. 最终交给 minecraft_launcher_lib 生成可执行命令行。
        """
        settings = self.config.settings
        try:
            memory = int(instance.get("memory_mb") or settings.get("memory_mb", 4096))
            min_memory = int(instance.get("min_memory_mb") or settings.get("min_memory_mb", 512))
        except (TypeError, ValueError) as error:
            raise JavaError("内存设置无效，请检查实例与启动器设置") from error
        # 明显非法的内存组合直接拦截
        if memory < 512 or min_memory < 256 or min_memory > memory:
            raise JavaError("内存设置无效：最小内存不能高于最大内存")
        extra = instance.get("jvm_args")
        if extra is None:
            extra = settings.get("jvm_args") or ""
        # 旧版默认参数存在兼容问题，自动迁移到安全参数
        if str(extra).strip() == LEGACY_JVM_ARGS:
            extra = SAFE_JVM_ARGS
        resolution = instance.get("resolution") or settings.get("resolution") or {}

        jvm_arguments = [f"-Xmx{memory}M", f"-Xms{min_memory}M"]
        for token in str(extra).split():
            if token.strip():
                jvm_arguments.append(token)
        executable = self.java_executable(instance)
        self._validate_java_runtime(
            executable,
            java_major_for_minecraft(str(instance.get("mc_version") or "")),
            memory,
            min_memory,
            [token for token in str(extra).split() if token.strip()],
        )
        try:
            jvm_arguments.extend(self.auth.authlib_arguments(account))
        except Exception as error:
            self.bus.log(f"注入 authlib-injector 失败: {error}", source="launch", level="error")

        version_id = instance.get("version_id") or instance.get("mc_version")
        directory = self.instances.directory_of(instance)
        options: dict[str, Any] = {
            "username": account.get("name", "Player"),
            "uuid": account.get("uuid", ""),
            "token": account.get("access_token") or "0",
            "executablePath": executable,
            "jvmArguments": jvm_arguments,
            # 上报启动器名称与版本，供服务端统计
            "launcherName": APP_NAME,
            "launcherVersion": APP_VERSION,
            "gameDirectory": str(directory),
        }
        # 仅用户显式开启时才覆盖游戏分辨率
        if resolution.get("enabled"):
            options["customResolution"] = True
            options["resolutionWidth"] = str(resolution.get("width", 1280))
            options["resolutionHeight"] = str(resolution.get("height", 720))

        return mll.command.get_minecraft_command(version_id, str(self.config.minecraft_directory), options)

    def launch(self, instance_id: str, account: dict[str, Any]) -> dict[str, Any]:
        """启动游戏进程。

        先确认版本文件齐全（否则提示修复实例），再组装命令并 Popen 拉起；
        进程句柄记入 _processes，随后启动读取线程持续转发游戏日志，
        进程退出时统计游玩时长、清理句柄并广播 game.exited。
        标准输入接到 DEVNULL，避免游戏等待输入。
        """
        instance = self.instances.require(instance_id)
        if not self.instances.version_installed(instance):
            # 版本文件丢失时给出明确修复指引
            raise InstanceError("该实例的版本文件缺失，请先修复实例")
        command = self.build_command(instance, account)
        task = self.tasks.create("launch", f"启动 {instance['name']}")
        self.bus.log(f"启动实例 {instance['name']}（PID 即将分配）", source="launch")

        creationflags = subprocess.CREATE_NO_WINDOW if os.name == "nt" else 0
        directory = self.instances.directory_of(instance)
        process = subprocess.Popen(
            command,
            cwd=str(directory),
            # 合并 stderr 到 stdout，便于按行转发日志
            stdout=subprocess.PIPE,
            stderr=subprocess.STDOUT,
            # 避免子进程等待标准输入而挂起
            stdin=subprocess.DEVNULL,
            text=True,
            encoding="utf-8",
            errors="replace",
            # 行缓冲，保证日志实时输出
            bufsize=1,
            creationflags=creationflags,
        )
        with self._lock:
            self._processes[process.pid] = process
        # 进程一拉起即视为启动成功，后续异常由 game.exited 事件处理
        self.tasks.finish(task.id, {"pid": process.pid}, "游戏进程已启动")
        # 记录最近游玩时间，用于列表排序
        self.instances.touch_played(instance_id)
        self.bus.publish(make_event("game.started", pid=process.pid, instance=instance_id, version=instance.get("version_id")))
        self.bus.publish(make_event("instances.changed"))

        def reader() -> None:
            # 记录启动时刻，进程退出时据此计算游玩时长
            started_at = time.time()
            try:
                if process.stdout is not None:
                    for line in process.stdout:
                        self.bus.publish(make_event("log", source="game", line=line.rstrip(), level="game"))
            finally:
                # 阻塞等待进程结束并取得退出码
                code = process.wait()
                with self._lock:
                    self._processes.pop(process.pid, None)
                self._add_playtime(instance_id, int(time.time() - started_at))
                self.bus.publish(make_event("game.exited", pid=process.pid, code=code, instance=instance_id))
                self.bus.publish(make_event("instances.changed"))

        threading.Thread(target=reader, daemon=True).start()
        return {"pid": process.pid, "instance": instance_id, "task": task.snapshot()}

    def running_games(self) -> list[dict[str, Any]]:
        """返回当前仍在运行的进程列表，顺便清理已退出的句柄。
        """
        alive = []
        for pid, process in list(self._processes.items()):
            # poll 为 None 表示进程仍存活
            if process.poll() is None:
                alive.append({"pid": pid})
            else:
                self._processes.pop(pid, None)
        return alive

    def stop_all(self) -> None:
        """终止所有由本启动器拉起的游戏进程（启动器退出时调用）。
        """
        for process in list(self._processes.values()):
            try:
                # 先发终止信号，尽量让游戏正常保存后退出
                process.terminate()
            except Exception:
                pass
        self._processes.clear()

    # ---------- 内部 ----------

    def _add_playtime(self, instance_id: str, seconds: int) -> None:
        """累加实例游玩时长（秒）；失败静默忽略，不影响主流程。
        """
        instance = self.instances.get(instance_id)
        if not instance:
            return
        try:
            self.instances.update(instance_id, {"playtime": int(instance.get("playtime") or 0) + max(0, seconds)})
        except Exception:
            pass

    def _callback(self, task_id: str) -> dict[str, Any]:
        """构造 minecraft_launcher_lib 需要的回调字典。

        把库的 setStatus / setProgress / setMax 适配到 TaskManager，
        让下载进度能实时反映到前端任务面板。
        """
        def set_status(status: str) -> None:
            self.tasks.progress(task_id, message=str(status))

        def set_progress(progress: int) -> None:
            self.tasks.progress(task_id, progress=int(progress))

        def set_max(maximum: int) -> None:
            # 总进度量，供前端计算百分比
            self.tasks.progress(task_id, total=int(maximum))

        return {"setStatus": set_status, "setProgress": set_progress, "setMax": set_max}
