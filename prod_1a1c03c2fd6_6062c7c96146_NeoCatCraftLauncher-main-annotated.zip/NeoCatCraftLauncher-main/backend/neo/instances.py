"""游戏实例管理模块。

一个“实例”代表一套独立的游戏环境（版本 + 加载器 + 模组 + 存档）。
本模块负责实例的创建、修改、删除、复制、持久化（instances.json）以及目录布局：
    隔离实例：<minecraft>/instances/<id>/ 内含 mods、saves、resourcepacks 等子目录；
    非隔离实例：直接使用全局 .minecraft 目录。
"""

from __future__ import annotations

import json
import re
import shutil
import threading
import time
import uuid as uuid_lib
from pathlib import Path
from typing import Any

from .config import Config

# 允许通过 update 修改的字段白名单，其余字段（如 created_at）不可外部改写
INSTANCE_FIELDS: tuple[str, ...] = (
    "name",
    "mc_version",
    "loader",
    "loader_version",
    "loader_installer",
    "version_id",
    "isolation",
    "directory",
    "memory_mb",
    "min_memory_mb",
    "java_path",
    "jvm_args",
    "resolution",
    "icon",
    "background",
    "group",
    "favorite",
    "notes",
)

# 用于生成 ID 的非法字符（只保留小写字母、数字与 . _ -）
_SAFE_ID = re.compile(r"[^a-z0-9._-]+")
# 用于净化显示名的非法字符（Windows 文件名规则 + 控制字符）
_SAFE_NAME = re.compile(r'[<>:"/\\|?*\x00-\x1f]+')


class InstanceError(ValueError):
    """实例相关业务异常，继承 ValueError，便于上层统一转换为 400 响应。
    """
    pass


def _slugify(text: str) -> str:
    """把任意文本转为安全的目录/ID 形式（小写、仅保留字母数字与 . _ -）。
    结果为空时兜底为 instance，保证目录名合法。
    """
    slug = _SAFE_ID.sub("-", (text or "").strip().lower()).strip("-.")
    return slug or "instance"


def _sanitize_name(text: str) -> str:
    """净化实例显示名：去掉文件名非法字符，最长 48 字符，空值兜底为“新实例”。
    """
    cleaned = _SAFE_NAME.sub("-", (text or "").strip()).strip(" .")
    return cleaned[:48] or "新实例"


def _default_icon(loader: str) -> str:
    """按加载器类型给出默认图标标识，未知类型使用 grass（草方块）。
    """
    mapping = {"fabric": "fabric", "forge": "forge", "neoforge": "neoforge", "quilt": "quilt"}
    return mapping.get((loader or "").lower(), "grass")


class InstanceManager:
    """实例仓库。

    所有变更都通过 self._lock 串行化，并在修改后立即写回 instances.json；
    对外返回的字典一律是副本，调用方修改不会影响内部状态。
    """
    def __init__(self, config: Config) -> None:
        """初始化实例管理器并载入磁盘数据。

        参数:
            config: 配置对象，用于取实例根目录与全局 .minecraft 目录。
        """
        self.config = config
        self.file = config.dir / "instances.json"
        self._lock = threading.RLock()
        self._items: list[dict[str, Any]] = []
        self._load()

    # ---------- 持久化 ----------

    def _load(self) -> None:
        """从 instances.json 载入实例列表。

        兼容两种历史格式：{instances: [...]} 或直接是数组。
        单条记录解析失败时跳过该条，不影响其余实例，避免一处损坏导致全部丢失。
        """
        if not self.file.is_file():
            return
        try:
            # 解析失败（文件损坏/被截断）时直接放弃加载，保持空列表
            payload = json.loads(self.file.read_text(encoding="utf-8"))
        except Exception:
            return
        # 兼容历史格式：对象包裹或裸数组
        items = payload.get("instances") if isinstance(payload, dict) else payload
        if not isinstance(items, list):
            return
        for raw in items:
            if not isinstance(raw, dict):
                continue
            try:
                self._items.append(self._normalize(raw))
            except Exception:
                continue

    def _save(self) -> None:
        """把实例列表整体写回磁盘（带版本号，便于后续结构迁移）。
        """
        payload = {"instances": self._items, "version": 1}
        self.file.write_text(json.dumps(payload, ensure_ascii=False, indent=2), encoding="utf-8")

    def _normalize(self, raw: dict[str, Any]) -> dict[str, Any]:
        """把外部传入的原始字典补全为完整实例记录。

        处理内容:
            1. ID 生成与去重（重名时追加 4 位随机后缀）；
            2. 字段类型收敛（bool/str/float/int），缺省值补齐；
            3. 名称净化、加载器小写化、默认图标；
            4. 补齐 created_at / last_played / playtime 三个统计字段。
        """
        instance_id = _slugify(str(raw.get("id") or uuid_lib.uuid4().hex[:10]))
        if any(item["id"] == instance_id for item in self._items):
            # ID 冲突时追加随机后缀，确保唯一
            instance_id = f"{instance_id}-{uuid_lib.uuid4().hex[:4]}"
        loader = (raw.get("loader") or "vanilla").strip().lower()
        mc_version = str(raw.get("mc_version") or "").strip()
        record: dict[str, Any] = {
            "id": instance_id,
            "name": _sanitize_name(str(raw.get("name") or mc_version or "新实例")),
            "mc_version": mc_version,
            "loader": loader,
            "loader_version": str(raw.get("loader_version") or ""),
            "loader_installer": str(raw.get("loader_installer") or ""),
            "version_id": str(raw.get("version_id") or mc_version),
            "isolation": bool(raw.get("isolation", True)),
            "directory": str(raw.get("directory") or ""),
            "memory_mb": raw.get("memory_mb"),
            "min_memory_mb": raw.get("min_memory_mb"),
            "java_path": str(raw.get("java_path") or ""),
            "jvm_args": raw.get("jvm_args"),
            "resolution": raw.get("resolution"),
            "icon": str(raw.get("icon") or _default_icon(loader)),
            "background": str(raw.get("background") or ""),
            "group": str(raw.get("group") or ""),
            "favorite": bool(raw.get("favorite", False)),
            "notes": str(raw.get("notes") or ""),
            "created_at": float(raw.get("created_at") or time.time()),
            "last_played": float(raw.get("last_played") or 0),
            "playtime": int(raw.get("playtime") or 0),
        }
        return record

    # ---------- 查询 ----------

    def raw_list(self) -> list[dict[str, Any]]:
        """返回内部记录副本列表（不含计算字段），用于内部逻辑与持久化。
        """
        with self._lock:
            return [dict(item) for item in self._items]

    def get(self, instance_id: str) -> dict[str, Any] | None:
        """按 ID 取实例副本，未找到返回 None。
        """
        with self._lock:
            for item in self._items:
                if item["id"] == instance_id:
                    return dict(item)
        return None

    def require(self, instance_id: str) -> dict[str, Any]:
        """按 ID 取实例，不存在时抛 InstanceError，供写操作使用。
        """
        instance = self.get(instance_id)
        if instance is None:
            raise InstanceError(f"实例不存在: {instance_id}")
        return instance

    def resolve(self, instance_id: str | None) -> dict[str, Any] | None:
        """解析“当前实例”。

        优先级：显式传入的 ID > 配置中的 active_instance > 列表第一个。
        全部为空时返回 None（表示使用全局目录）。
        """
        if instance_id:
            return self.get(instance_id)
        active = (self.config.get("active_instance") or "").strip()
        if active:
            return self.get(active)
        items = self.raw_list()
        return items[0] if items else None

    def directory_of(self, instance: dict[str, Any]) -> Path:
        """计算实例的实际游戏目录并确保其存在。

        优先级：记录中的自定义目录 > 隔离模式下的 instances/<id> > 全局 .minecraft。
        """
        custom = (instance.get("directory") or "").strip()
        if custom:
            path = Path(custom)
        elif instance.get("isolation", True):
            path = self.config.instances_directory / instance["id"]
        else:
            path = self.config.minecraft_directory
        path.mkdir(parents=True, exist_ok=True)
        return path

    def mods_directory_of(self, instance: dict[str, Any] | None) -> Path:
        """返回实例的 mods 目录（实例为 None 时退化为全局 mods 目录）。
        """
        if instance is None:
            return self.config.mods_directory
        path = self.directory_of(instance) / "mods"
        path.mkdir(parents=True, exist_ok=True)
        return path

    def version_installed(self, instance: dict[str, Any]) -> bool:
        """判断实例对应的游戏版本是否已经安装。

        判定依据：versions/<version_id>/<version_id>.json 是否存在；
        若实例声明了非原版加载器但 version_id 仍等于原版号，说明加载器尚未安装，直接返回 False。
        """
        version_id = instance.get("version_id") or instance.get("mc_version")
        if not version_id:
            return False
        loader = str(instance.get("loader") or "vanilla").lower()
        # 声明了加载器却仍是原版版本号，说明加载器未安装完成
        if loader not in {"", "vanilla"} and version_id == instance.get("mc_version"):
            return False
        # 以版本 JSON 是否存在作为“已安装”的判定依据
        json_file = self.config.minecraft_directory / "versions" / version_id / f"{version_id}.json"
        return json_file.is_file()

    def snapshot(self, instance: dict[str, Any]) -> dict[str, Any]:
        """生成发给前端的实例视图。

        在原记录基础上补充：实际目录、mods 目录、是否已安装、加载器展示名。
        """
        payload = dict(instance)
        directory = self.directory_of(instance)
        payload["directory"] = str(directory)
        payload["mods_directory"] = str(directory / "mods")
        payload["installed"] = self.version_installed(instance)
        payload["display_loader"] = (
            "原版"
            if instance.get("loader") in ("", "vanilla")
            else f"{str(instance.get('loader')).title()} {instance.get('loader_version') or ''}".strip()
        )
        return payload

    def list(self) -> list[dict[str, Any]]:
        """返回全部实例视图，按“收藏 → 最近游玩 → 名称”排序。
        """
        items = [self.snapshot(item) for item in self.raw_list()]
        # 收藏优先，其次按最近游玩时间倒序，最后按名称
        items.sort(key=lambda item: (not item.get("favorite"), -float(item.get("last_played") or 0), item.get("name", "")))
        return items

    # ---------- 写入 ----------

    def create(self, payload: dict[str, Any]) -> dict[str, Any]:
        """创建新实例。

        参数:
            payload: 至少包含 mc_version，其余字段可选。

        行为:
            1. 生成唯一 ID（同 slug 冲突时追加序号）；
            2. 创建标准子目录（mods/saves/resourcepacks/shaderpacks/config/logs）；
            3. 若当前没有激活实例，则自动设为激活。

        异常:
            InstanceError: 缺少 Minecraft 版本。
        """
        mc_version = str(payload.get("mc_version") or "").strip()
        if not mc_version:
            raise InstanceError("缺少 Minecraft 版本")
        loader = str(payload.get("loader") or "vanilla").strip().lower()
        name = _sanitize_name(str(payload.get("name") or f"{mc_version} {loader}".strip()))
        with self._lock:
            base_id = _slugify(payload.get("id") or name)
            instance_id = base_id
            counter = 1
            existing = {item["id"] for item in self._items}
            # 基础 ID 被占用则依次尝试 base-2、base-3…
            while instance_id in existing:
                counter += 1
                instance_id = f"{base_id}-{counter}"
            record = self._normalize(
                {
                    **payload,
                    "id": instance_id,
                    "name": name,
                    "mc_version": mc_version,
                    "loader": loader,
                }
            )
            record["id"] = instance_id
            self._items.append(record)
            self._save()
        directory = self.directory_of(record)
        # 预创建标准目录，避免首次进游戏时因目录缺失报错
        for folder in ("mods", "saves", "resourcepacks", "shaderpacks", "config", "logs"):
            (directory / folder).mkdir(parents=True, exist_ok=True)
        # 首个实例自动成为激活实例，方便用户直接点“启动”
        if not (self.config.get("active_instance") or "").strip():
            self.config.set("active_instance", instance_id)
        return self.snapshot(record)

    def update(self, instance_id: str, patch: dict[str, Any]) -> dict[str, Any]:
        """按 ID 局部更新实例。

        只接受 INSTANCE_FIELDS 白名单内的字段；名称与加载器会额外净化。
        开启隔离模式时会清空自定义目录，避免与非隔离目录互相干扰。

        异常:
            InstanceError: 实例不存在。
        """
        with self._lock:
            for index, item in enumerate(self._items):
                if item["id"] != instance_id:
                    continue
                updated = dict(item)
                for key in INSTANCE_FIELDS:
                    if key in patch:
                        updated[key] = patch[key]
                if "name" in patch:
                    updated["name"] = _sanitize_name(str(patch["name"]))
                if "loader" in patch:
                    updated["loader"] = str(patch["loader"] or "vanilla").lower()
                # 隔离模式下不允许自定义目录，二者只能取其一
                if updated.get("isolation") and updated.get("directory"):
                    updated["directory"] = ""
                self._items[index] = self._normalize({**updated, "id": instance_id})
                self._items[index]["id"] = instance_id
                self._save()
                return self.snapshot(self._items[index])
        raise InstanceError(f"实例不存在: {instance_id}")

    def delete(self, instance_id: str, delete_files: bool = False) -> dict[str, Any]:
        """删除实例记录，可选是否同时删除磁盘文件。

        参数:
            instance_id: 实例 ID。
            delete_files: 是否删除实例目录（仅对隔离实例生效）。

        安全约束:
            绝不删除全局 .minecraft 目录本身，只删其子目录。

        返回:
            {deleted: 实例 ID, files_removed: 是否真正删除了文件}。
        """
        with self._lock:
            target = None
            for item in self._items:
                if item["id"] == instance_id:
                    target = item
                    break
            if target is None:
                raise InstanceError(f"实例不存在: {instance_id}")
            self._items = [item for item in self._items if item["id"] != instance_id]
            self._save()
        if (self.config.get("active_instance") or "") == instance_id:
            remaining = self.raw_list()
            self.config.set("active_instance", remaining[0]["id"] if remaining else "")
        removed = False
        # 仅隔离实例拥有独立目录，非隔离实例删文件会误伤全局目录
        if delete_files and target.get("isolation", True):
            directory = self.directory_of(target)
            try:
                # 二次保险：当前目录等于全局 .minecraft 时拒绝删除
                if directory.is_dir() and directory != self.config.minecraft_directory:
                    shutil.rmtree(directory, ignore_errors=True)
                    removed = True
            except Exception:
                removed = False
        return {"deleted": instance_id, "files_removed": removed}

    def duplicate(self, instance_id: str, name: str | None = None) -> dict[str, Any]:
        """复制实例。

        新实例强制开启隔离且取消收藏标记；若源实例是隔离模式，
        则递归复制其目录，但跳过日志与崩溃报告，减少无谓占用。
        """
        source = self.require(instance_id)
        payload = {key: source.get(key) for key in INSTANCE_FIELDS if key != "directory"}
        payload["name"] = name or f"{source['name']} 副本"
        payload["isolation"] = True
        payload["favorite"] = False
        created = self.create(payload)
        if source.get("isolation", True):
            try:
                shutil.copytree(
                    self.directory_of(source),
                    Path(created["directory"]),
                    dirs_exist_ok=True,
                    # 复制实例时跳过日志与崩溃报告，只保留有效内容
                    ignore=shutil.ignore_patterns("logs", "crash-reports"),
                )
            except Exception:
                pass
        return created

    def touch_played(self, instance_id: str) -> None:
        """刷新实例的最近游玩时间（启动游戏时调用）。
        """
        with self._lock:
            for item in self._items:
                if item["id"] == instance_id:
                    item["last_played"] = time.time()
                    self._save()
                    return
