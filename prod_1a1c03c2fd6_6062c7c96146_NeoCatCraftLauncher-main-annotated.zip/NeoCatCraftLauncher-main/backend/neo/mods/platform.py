"""模组平台客户端与下载服务模块。

内容分三部分：
    1. ModrinthClient：官方 v2 API（无需鉴权），负责搜索、版本列表、版本详情、项目名。
    2. CurseForgeClient：Eternal API（需 API Key），负责搜索、文件列表、文件详情。
    3. ModService：面向业务层的统一服务，屏蔽两个平台的差异，
       提供聚合搜索、版本选择、依赖分析、下载安装（含前置依赖递归）、
       本地扫描 / 启用禁用 / 删除等能力。

所有网络请求统一走 httpx，下载任务交给 tasks.TaskManager 异步执行，
本地文件变化通过 events.EventBus 以 mods.changed 等事件通知前端刷新。
"""

from __future__ import annotations

import json
import re
import threading
from concurrent.futures import ThreadPoolExecutor, as_completed
from pathlib import Path
from typing import Any
from urllib.parse import quote

import httpx

from ..config import Config
from ..events import EventBus, make_event
from ..tasks import TaskManager
from .downloader import USER_AGENT, download_file
from .scanner import scan_mods

# Modrinth 官方 v2 API，无需鉴权
MODRINTH_API = "https://api.modrinth.com/v2"
CURSEFORGE_API = "https://api.curseforge.com/v1"
# CurseForge 中 Minecraft 的固定 gameId
CURSEFORGE_GAME_ID = 432
# classId=6 表示“模组”分类
CURSEFORGE_MOD_CLASS = 6
# CurseForge 用数字枚举表示加载器，这里做名字到数字的映射
CURSEFORGE_LOADER_TYPES = {"forge": 1, "fabric": 4, "quilt": 5, "neoforge": 6}
# 依赖关系 3 表示必需前置
CURSEFORGE_RELATION_REQUIRED = 3
MODRINTH_LOADERS = {"forge", "fabric", "quilt", "neoforge"}
MODRINTH_PROJECT_PATHS = {
    "mod": "mod",
    "modpack": "modpack",
    "shader": "shader",
    "resourcepack": "resourcepack",
    "datapack": "datapack",
}
# 用于从 CurseForge 的混合标签里筛出真正的游戏版本号
_MC_VERSION = re.compile(r"^\d+\.\d+(\.\d+)?([-.][0-9A-Za-z]+)*$")


# 平台相关错误的统一类型，方便上层统一捕获并转成用户可读提示
class ModPlatformError(RuntimeError):
    pass


def _http(timeout: int = 20) -> httpx.Client:
    """创建统一的 httpx 客户端：带默认超时、跟随重定向、统一 User-Agent。

    用 with 语句使用，保证连接及时释放。
    """
    # 跟随重定向：CDN 下载链接常返回 302
    return httpx.Client(timeout=timeout, follow_redirects=True, headers={"User-Agent": USER_AGENT})


def _dumps(value: Any) -> str:
    """紧凑 JSON 序列化。

    Modrinth 的 facets/loaders 等参数要求传 JSON 字符串，且不接受多余空格。
    """
    return json.dumps(value, separators=(",", ":"))


def _trim(text: Any, limit: int = 400) -> str:
    """把多行文本压成单行并截断，避免前端卡片被超长描述撑坏。
    """
    cleaned = " ".join(str(text or "").split())
    return cleaned[:limit]


def _sha1_from_hashes(value: Any) -> str | None:
    """从各平台五花八门的哈希结构中抽取 sha1。

    兼容三种形态：
        1. Modrinth：{"sha1": "..."} 或 {"1": "..."}；
        2. CurseForge：{"algo": 1, "value": "..."} 的列表；
        3. 嵌套字典（部分接口把哈希再包一层）。
    拿不到时返回 None，下载器会退化为只校验大小。
    """
    if isinstance(value, dict):
        direct = value.get("sha1") or value.get("1")
        if direct:
            return str(direct)
        for entry in value.values():
            if isinstance(entry, dict):
                resolved = _sha1_from_hashes(entry)
                if resolved:
                    return resolved
        return None
    if isinstance(value, list):
        for entry in value:
            if not isinstance(entry, dict):
                continue
            if entry.get("algo") in (1, "1", "sha1") and entry.get("value"):
                return str(entry["value"])
        for entry in value:
            if isinstance(entry, dict) and entry.get("value"):
                return str(entry["value"])
    return None


class ModrinthClient:
    def __init__(self, timeout: int = 20) -> None:
        self.timeout = timeout

    def search(
        self,
        query: str,
        minecraft_version: str | None,
        loader: str | None,
        limit: int = 20,
        offset: int = 0,
        project_type: str = "mod",
    ) -> dict[str, Any]:
        """按关键词搜索 Modrinth 项目。

        参数:
            query: 搜索词，为空时按下载量排序（浏览热门）。
            minecraft_version: 限定适配的游戏版本。
            loader: 限定加载器（forge/fabric/quilt/neoforge）。
            limit: 每页数量，内部夹在 1~50。
            offset: 偏移量，用于分页。
            project_type: 项目类型，决定 facets 过滤条件与详情页路径。

        返回:
            统一结构的字典：platform / total / hits / offset。
        """
        # Modrinth 用 facets 过滤，内层列表内条件为“或”，列表之间为“与”
        facets: list[list[str]] = [[f"project_type:{project_type}"]]
        if loader in MODRINTH_LOADERS:
            facets.append([f"categories:{loader}"])
        if minecraft_version:
            facets.append([f"versions:{minecraft_version}"])
        params = {
            "query": query or "",
            # 平台上限 50，这里做兜底夹取
            "limit": max(1, min(limit, 50)),
            "offset": max(0, offset),
            # 有搜索词按相关度排序，空搜索按下载量排序（浏览热门）
            "index": "relevance" if query else "downloads",
            "facets": _dumps(facets),
        }
        with _http(self.timeout) as client:
            response = client.get(f"{MODRINTH_API}/search", params=params)
            if response.status_code != 200:
                raise ModPlatformError(f"Modrinth 搜索失败（HTTP {response.status_code}）")
            payload = response.json()
        # 统一结构后再返回，前端无需关心平台差异
        hits = [self._normalize_hit(hit, project_type) for hit in payload.get("hits", [])]
        return {"platform": "modrinth", "total": payload.get("total_hits", len(hits)), "hits": hits, "offset": params["offset"]}

    @staticmethod
    def _normalize_hit(hit: dict[str, Any], project_type: str = "mod") -> dict[str, Any]:
        """把 Modrinth 的搜索结果条目转成统一结构。

        项目类型不同会映射到不同的详情页路径（mod/modpack/shader 等）。
        """
        project_path = MODRINTH_PROJECT_PATHS.get(project_type, project_type)
        return {
            "platform": "modrinth",
            "id": hit.get("project_id"),
            "slug": hit.get("slug"),
            "title": hit.get("title") or hit.get("slug"),
            "description": _trim(hit.get("description")),
            "author": hit.get("author"),
            "downloads": hit.get("downloads") or 0,
            "follows": hit.get("follows") or 0,
            "icon": hit.get("icon_url"),
            "categories": hit.get("display_categories") or hit.get("categories") or [],
            "url": f"https://modrinth.com/{project_path}/{hit.get('slug')}" if hit.get("slug") else None,
            "project_type": project_type,
            # 只保留最近 8 个适配版本，避免标签过长
            "game_versions": (hit.get("versions") or [])[-8:],
            "date_modified": hit.get("date_modified"),
        }

    def versions(self, project_id: str, minecraft_version: str | None = None, loader: str | None = None) -> list[dict[str, Any]]:
        """获取项目的版本列表，可按游戏版本与加载器过滤。

        返回的每个版本都经过 normalize_version 标准化。
        """
        params: dict[str, Any] = {}
        if minecraft_version:
            params["game_versions"] = _dumps([minecraft_version])
        if loader in MODRINTH_LOADERS:
            params["loaders"] = _dumps([loader])
        with _http(self.timeout) as client:
            response = client.get(f"{MODRINTH_API}/project/{project_id}/version", params=params)
            if response.status_code != 200:
                raise ModPlatformError(f"Modrinth 版本列表获取失败（HTTP {response.status_code}）")
            payload = response.json()
        return [self.normalize_version(item, project_id) for item in payload]

    def version(self, version_id: str) -> dict[str, Any]:
        """按版本 id 获取单个版本的详情（含下载文件与依赖信息）。
        """
        with _http(self.timeout) as client:
            response = client.get(f"{MODRINTH_API}/version/{version_id}")
            if response.status_code != 200:
                raise ModPlatformError(f"Modrinth 版本详情获取失败（HTTP {response.status_code}）")
            payload = response.json()
        return self.normalize_version(payload, payload.get("project_id"))

    def projects(self, ids: list[str]) -> dict[str, str]:
        """批量把项目 id 映射为项目标题，请求失败时返回空字典。

        用途：依赖列表里只有 id，需要一个人类可读的名字来展示。
        """
        if not ids:
            return {}
        with _http(self.timeout) as client:
            response = client.get(f"{MODRINTH_API}/projects", params={"ids": _dumps(ids)})
            if response.status_code != 200:
                return {}
            payload = response.json()
        return {item.get("id"): item.get("title") or item.get("slug") for item in payload if isinstance(item, dict)}

    @staticmethod
    def normalize_version(payload: dict[str, Any], project_id: str | None) -> dict[str, Any]:
        """把 Modrinth 的版本对象标准化。

        重点提取：下载文件列表（url / 文件名 / 大小 / 是否主文件 / sha1）
        与依赖列表（区分 required / optional / incompatible）。
        """
        files = []
        for item in payload.get("files") or []:
            files.append(
                {
                    "url": item.get("url"),
                    "filename": item.get("filename"),
                    "size": item.get("size"),
                    "primary": bool(item.get("primary")),
                    "sha1": _sha1_from_hashes(item.get("hashes")),
                }
            )
        dependencies = []
        for item in payload.get("dependencies") or []:
            dependencies.append(
                {
                    "project_id": item.get("project_id"),
                    "version_id": item.get("version_id"),
                    "dependency_type": item.get("dependency_type") or "optional",
                }
            )
        return {
            "platform": "modrinth",
            "project_id": project_id or payload.get("project_id"),
            "version_id": payload.get("id"),
            "name": payload.get("name"),
            "version_number": payload.get("version_number"),
            "channel": payload.get("version_type") or "release",
            "game_versions": payload.get("game_versions") or [],
            "loaders": payload.get("loaders") or [],
            "date": payload.get("date_published"),
            "downloads": payload.get("downloads") or 0,
            # 下载器需要 url/filename/size/sha1 四项，缺一都会影响校验
            "files": files,
            "dependencies": dependencies,
        }


class CurseForgeClient:
    def __init__(self, api_key: str, timeout: int = 20) -> None:
        self.api_key = (api_key or "").strip()
        self.timeout = timeout

    def _headers(self) -> dict[str, str]:
        """构造 CurseForge 请求头；缺少 API Key 时直接抛错。

        注意 x-api-key 是鉴权头，不能放到查询参数里。
        """
        if not self.api_key:
            raise ModPlatformError("CurseForge 需要 API Key，请先在设置中填写 curseforge_api_key")
        return {"User-Agent": USER_AGENT, "x-api-key": self.api_key, "Accept": "application/json"}

    def _get(self, path: str, params: dict[str, Any] | None = None) -> Any:
        """发送 GET 请求并解包 data 字段。

        403 单独提示，因为绝大多数情况是 Key 无效或无权限，这个信息对用户最有用。
        """
        with _http(self.timeout) as client:
            response = client.get(f"{CURSEFORGE_API}{path}", params=params, headers=self._headers())
            # 403 基本都是 Key 无效或被拉黑，直接给出可操作提示
            if response.status_code == 403:
                raise ModPlatformError("CurseForge 拒绝了请求，请检查 API Key 是否有效")
            if response.status_code != 200:
                raise ModPlatformError(f"CurseForge 请求失败（HTTP {response.status_code}）")
            return response.json().get("data")

    def search(
        self,
        query: str,
        minecraft_version: str | None,
        loader: str | None,
        limit: int = 20,
        offset: int = 0,
        class_id: int = CURSEFORGE_MOD_CLASS,
    ) -> dict[str, Any]:
        """CurseForge 搜索。

        排序策略：有关键词按相关度（sortField=2），无关键词按下载量（sortField=6）。
        loader 需换算成 CurseForge 的数字枚举（见 CURSEFORGE_LOADER_TYPES）。
        注意该接口不返回总数，total 只是当前页条数。
        """
        params: dict[str, Any] = {
            "gameId": CURSEFORGE_GAME_ID,
            "classId": class_id,
            "searchFilter": query or "",
            # 2=相关度，6=下载量
            "sortField": 2 if query else 6,
            "sortOrder": "desc",
            "index": max(0, offset),
            # 每页上限 50，与前端口径一致
            "pageSize": max(1, min(limit, 50)),
        }
        if minecraft_version:
            params["gameVersion"] = minecraft_version
        if loader in CURSEFORGE_LOADER_TYPES:
            params["modLoaderType"] = CURSEFORGE_LOADER_TYPES[loader]
        data = self._get("/mods/search", params) or []
        hits = [self._normalize_hit(item) for item in data]
        return {"platform": "curseforge", "total": len(hits), "hits": hits, "offset": params["index"]}

    @staticmethod
    def _normalize_hit(item: dict[str, Any]) -> dict[str, Any]:
        """把 CurseForge 的搜索结果转成与 Modrinth 一致的结构，便于前端复用同一套渲染逻辑。

        CurseForge 没有 follows 概念，固定填 0。
        """
        authors = item.get("authors") or []
        logo = item.get("logo") or {}
        return {
            "platform": "curseforge",
            "id": str(item.get("id")),
            "slug": item.get("slug"),
            "title": item.get("name"),
            "description": _trim(item.get("summary")),
            # CurseForge 只展示第一作者
            "author": authors[0].get("name") if authors else None,
            "downloads": item.get("downloadCount") or 0,
            "follows": 0,
            "icon": logo.get("thumbnailUrl") or logo.get("url"),
            # 分类只取名字，前端按标签渲染
            "categories": [category.get("name") for category in item.get("categories") or []],
            "url": (item.get("links") or {}).get("websiteUrl"),
            "game_versions": sorted({entry.get("gameVersion") for entry in item.get("latestFilesIndexes") or [] if entry.get("gameVersion")})[-8:],
            "date_modified": item.get("dateModified"),
        }

    def files(self, mod_id: str, minecraft_version: str | None = None, loader: str | None = None) -> list[dict[str, Any]]:
        """获取模组的文件列表（可下载版本），可按游戏版本与加载器过滤。
        """
        params: dict[str, Any] = {"pageSize": 50}
        if minecraft_version:
            params["gameVersion"] = minecraft_version
        if loader in CURSEFORGE_LOADER_TYPES:
            params["modLoaderType"] = CURSEFORGE_LOADER_TYPES[loader]
        data = self._get(f"/mods/{mod_id}/files", params) or []
        return [self.normalize_file(item, mod_id) for item in data]

    def file(self, mod_id: str, file_id: str) -> dict[str, Any]:
        """获取单个文件详情。
        """
        data = self._get(f"/mods/{mod_id}/files/{file_id}")
        if not data:
            raise ModPlatformError("CurseForge 未找到指定文件")
        return self.normalize_file(data, mod_id)

    def mod(self, mod_id: str) -> dict[str, Any]:
        """获取模组主体信息（用于取标题、图标等）。
        """
        return self._get(f"/mods/{mod_id}") or {}

    @staticmethod
    def fallback_url(file_id: str, filename: str) -> str:
        """在 downloadUrl 缺失时，按 CurseForge 的 CDN 规则拼出直链。

        规则：文件 id 前去掉最后三位作为目录，后三位补零作为文件名前缀，
        例如 1234567 → /files/1234/567/<filename>。
        部分作者禁用了第三方分发，官方接口会返回空 downloadUrl，此时用此直链兜底。
        """
        # 文件 id 在 URL 中按千位切分目录
        numeric = int(file_id)
        return f"https://mediafilez.forgecdn.net/files/{numeric // 1000}/{numeric % 1000:03d}/{quote(filename)}"

    @classmethod
    def normalize_file(cls, item: dict[str, Any], mod_id: str | None) -> dict[str, Any]:
        """把 CurseForge 的文件对象标准化成与 Modrinth 版本一致的结构。

        要点:
            1. downloadUrl 为空时用 fallback_url 拼直链；
            2. gameVersions 是混合标签，需用正则筛出真正的 Minecraft 版本号，
               再按加载器白名单筛出加载器名；
            3. releaseType 1/2/3 映射为 release/beta/alpha；
            4. isAvailable 为 False 表示文件已被作者删除或屏蔽。
        """
        filename = item.get("fileName")
        # 作者禁用第三方分发时该字段为空，需要用 CDN 规则兜底
        url = item.get("downloadUrl")
        if not url and filename and item.get("id") is not None:
            url = cls.fallback_url(str(item.get("id")), filename)
        dependencies = []
        for entry in item.get("dependencies") or []:
            dependencies.append(
                {
                    "project_id": str(entry.get("modId")),
                    "version_id": None,
                    "dependency_type": "required" if entry.get("relationType") == CURSEFORGE_RELATION_REQUIRED else "optional",
                }
            )
        raw_tags = [str(value) for value in item.get("gameVersions") or [] if value]
        # 从混合标签中筛出真正的版本号
        game_versions = [value for value in raw_tags if _MC_VERSION.match(value)]
        # 同时筛出加载器标签
        loaders = [value.lower() for value in raw_tags if value.lower() in MODRINTH_LOADERS]
        return {
            "platform": "curseforge",
            "project_id": str(mod_id or item.get("modId")),
            "version_id": str(item.get("id")),
            "name": item.get("displayName") or filename,
            "version_number": item.get("displayName") or filename,
            # 发布类型数字转文案
            "channel": {1: "release", 2: "beta", 3: "alpha"}.get(item.get("releaseType"), "release"),
            "game_versions": game_versions[:12],
            "loaders": loaders,
            "date": item.get("fileDate"),
            "downloads": item.get("downloadCount") or 0,
            "files": [
                {
                    "url": url,
                    "filename": filename,
                    "size": item.get("fileLength"),
                    "primary": True,
                    "sha1": _sha1_from_hashes(item.get("hashes")),
                }
            ],
            "dependencies": dependencies,
            # 标记文件是否已被删除或屏蔽
            "unavailable": bool(item.get("isAvailable") is False),
        }


class ModService:
    def __init__(self, config: Config, tasks: TaskManager, bus: EventBus, instances: Any = None) -> None:
        """初始化服务并创建标题缓存与互斥锁。

        _title_cache 用于避免重复请求项目名；_lock 保证多线程下载时的缓存读写安全。
        """
        self.config = config
        self.tasks = tasks
        self.bus = bus
        self.instances = instances
        self._title_cache: dict[str, str] = {}
        # 下载在多个线程中执行，标题缓存需要加锁
        self._lock = threading.Lock()

    # ---------- 目录 ----------

    def mods_directory(self, instance_id: str | None = None) -> Path:
        """解析实际的模组目录。

        优先使用指定实例的 mods 目录；未指定实例或实例不存在时回退到全局配置目录。
        """
        if self.instances is not None and instance_id:
            instance = self.instances.get(instance_id)
            if instance:
                # 按实例隔离 mods 目录，实现版本隔离
                return self.instances.mods_directory_of(instance)
        return self.config.mods_directory

    # ---------- 平台 ----------

    def platform_status(self) -> list[dict[str, Any]]:
        """返回各平台的可用状态，供前端决定是否显示 CurseForge 入口。

        CurseForge 需要用户自行申请 API Key，未配置时标记为不可用。
        """
        return [
            {"id": "modrinth", "name": "Modrinth", "available": True, "requires_key": False},
            {
                "id": "curseforge",
                "name": "CurseForge",
                # 未配置 Key 时 CurseForge 不可用
                "available": bool((self.config.get("curseforge_api_key") or "").strip()),
                "requires_key": True,
            },
        ]

    def _clients(self) -> tuple[ModrinthClient, CurseForgeClient]:
        """构造两个平台客户端。API 请求超时固定 20 秒，与下载超时分离。
        """
        timeout = int(self.config.get("download_timeout", 60) or 60)
        # API 超时固定 20 秒，与下载超时解耦
        return ModrinthClient(timeout=20), CurseForgeClient(self.config.get("curseforge_api_key") or "", timeout=20)

    # ---------- 搜索 ----------

    def search(
        self,
        platform: str,
        query: str,
        minecraft_version: str | None = None,
        loader: str | None = None,
        limit: int = 20,
        offset: int = 0,
    ) -> dict[str, Any]:
        """统一搜索入口。platform 取 all 时并行查询两个平台并合并排序；
        取 curseforge / 其它值时分别落到对应客户端（默认 Modrinth）。
        """
        modrinth, curseforge = self._clients()
        if platform == "all":
            # platform=all 时走双平台并行聚合
            return self._aggregate_search(query, minecraft_version, loader, limit, offset)
        if platform == "curseforge":
            return curseforge.search(query, minecraft_version, loader, limit, offset)
        return modrinth.search(query, minecraft_version, loader, limit, offset)

    def _aggregate_search(
        self,
        query: str,
        minecraft_version: str | None,
        loader: str | None,
        limit: int,
        offset: int,
    ) -> dict[str, Any]:
        """并行聚合两个平台的搜索结果。

        任一平台报错不会影响另一个平台的结果，错误信息收集到 warnings 中一并返回。
        合并后按下载量降序、标题升序排序，保证结果稳定可复现。
        """
        hits: list[dict[str, Any]] = []
        warnings: list[str] = []
        # 两个平台并行请求，缩短总耗时
        with ThreadPoolExecutor(max_workers=2) as pool:
            futures = {
                pool.submit(
                    self._search_platform,
                    platform,
                    query,
                    minecraft_version,
                    loader,
                    limit,
                    offset,
                ): platform
                for platform in ("modrinth", "curseforge")
            }
            for future in as_completed(futures):
                platform = futures[future]
                try:
                    payload = future.result()
                    hits.extend(payload.get("hits") or [])
                except Exception as error:
                    warnings.append(f"{platform}: {error}")
        # 按下载量降序、标题升序排序，保证结果稳定
        hits.sort(
            key=lambda item: (
                -int(item.get("downloads") or 0),
                str(item.get("title") or "").lower(),
            )
        )
        return {
            "platform": "all",
            "total": len(hits),
            "hits": hits[: max(1, min(limit, 50))],
            "offset": max(0, offset),
            # 把单平台失败信息回传，前端可提示“某平台暂不可用”
            "warnings": warnings,
        }

    def _search_platform(
        self,
        platform: str,
        query: str,
        minecraft_version: str | None,
        loader: str | None,
        limit: int,
        offset: int,
    ) -> dict[str, Any]:
        """按平台名分派到对应的客户端搜索，供线程池调用。
        """
        modrinth, curseforge = self._clients()
        if platform == "curseforge":
            return curseforge.search(query, minecraft_version, loader, limit, offset)
        return modrinth.search(query, minecraft_version, loader, limit, offset)

    def versions(self, platform: str, project_id: str, minecraft_version: str | None = None, loader: str | None = None) -> dict[str, Any]:
        """统一版本列表入口：CurseForge 的“文件”与 Modrinth 的“版本”在这里被抹平。
        """
        modrinth, curseforge = self._clients()
        if platform == "curseforge":
            items = curseforge.files(project_id, minecraft_version, loader)
        else:
            items = modrinth.versions(project_id, minecraft_version, loader)
        return {"platform": platform, "project_id": project_id, "versions": items}

    def inspect_dependencies(
        self,
        platform: str,
        project_id: str,
        version_id: str | None = None,
        minecraft_version: str | None = None,
        loader: str | None = None,
        instance_id: str | None = None,
    ) -> dict[str, Any]:
        """分析某个版本的前置依赖，并标注本地是否已安装。

        用于下载前给用户展示“还需要装哪些前置”，避免装完发现跑不起来。
        """
        version = self._resolve_version(
            platform,
            project_id,
            version_id,
            minecraft_version,
            loader,
        )
        installed = self._installed_mod_ids(self.mods_directory(instance_id))
        return {
            "platform": platform,
            "project_id": project_id,
            "version_id": version.get("version_id"),
            "version_number": version.get("version_number"),
            "dependencies": self._dependency_details(version, installed),
        }

    # ---------- 安装 ----------

    def install(
        self,
        platform: str,
        project_id: str,
        version_id: str | None = None,
        minecraft_version: str | None = None,
        loader: str | None = None,
        with_dependencies: bool = False,
        enabled: bool = True,
        instance_id: str | None = None,
        dependency_project_ids: list[str] | None = None,
    ) -> dict[str, Any]:
        """异步下载并安装指定模组。

        流程:
            1. 先创建 download 类型任务，立即返回快照给前端展示进度；
            2. 后台线程解析目标版本、下载主文件；
            3. with_dependencies 为真时递归安装 required 依赖（深度限制 2 层）；
            4. 用户额外勾选的依赖（dependency_project_ids）单独安装，失败只记录不中断。

        参数:
            enabled: 为 False 时下载完成后自动加 .disabled 后缀（只下载不启用）。
            instance_id: 指定实例，缺省写入全局 mods 目录。
        """
        # 先建任务，可立即返回给前端显示进度
        task = self.tasks.create("download", f"准备下载模组 #{project_id}")

        def worker() -> None:
            """后台下载协程：整个过程在独立线程中执行，异常统一落到任务状态与事件日志。
            """
            try:
                version = self._resolve_version(
                    platform,
                    project_id,
                    version_id,
                    minecraft_version,
                    loader,
                )
                title = self._project_title(platform, project_id)
                target_dir = self.mods_directory(instance_id)
                self.tasks.update(
                    task.id,
                    title=f"下载 {title} {version.get('version_number') or ''}".strip(),
                    message="已获取下载信息，开始下载",
                    force=True,
                )
                result = self._install_version(
                    version,
                    title,
                    with_dependencies,
                    enabled,
                    depth=0,
                    visited=set(),
                    target_dir=target_dir,
                    existing_task=task,
                    finish_task=False,
                )
                # 只安装用户明确勾选的前置依赖
                selected_dependencies = {
                    str(project_id)
                    for project_id in (dependency_project_ids or [])
                    if str(project_id).strip()
                }
                children = list(result.get("children") or [])
                installed = self._installed_mod_ids(target_dir) | {
                    str(version.get("project_id") or "").lower()
                }
                for dependency in version.get("dependencies") or []:
                    dependency_project = str(dependency.get("project_id") or "")
                    if (
                        not dependency_project
                        or dependency_project not in selected_dependencies
                        or dependency_project.lower() in installed
                    ):
                        continue
                    try:
                        child_version = self._resolve_dependency(platform, dependency, version)
                        if child_version is None:
                            raise ModPlatformError("没有找到兼容的前置版本")
                        child_title = self._project_title(
                            child_version.get("platform") or platform,
                            dependency_project,
                        )
                        child = self._install_version(
                            child_version,
                            child_title,
                            False,
                            enabled,
                            depth=1,
                            visited=set(),
                            target_dir=target_dir,
                        )
                        # 记录子依赖的安装结果
                        children.append(child)
                        installed.add(dependency_project.lower())
                    except Exception as error:
                        children.append(
                            {
                                "file": None,
                                "error": str(error),
                                "project_id": dependency_project,
                                # 依赖安装失败不中断主流程，标记为跳过
                                "skipped": True,
                                "dependencies": [],
                                "children": [],
                            }
                        )
                result["children"] = children
                self.tasks.finish(
                    task.id,
                    {"project_id": project_id, "version": version, **result},
                    f"已下载 {title}",
                )
            except Exception as error:
                self.tasks.fail(task.id, str(error))
                self.bus.log(f"模组 #{project_id} 下载失败: {error}", source="mods", level="error")

        # daemon 线程：不阻塞进程退出
        threading.Thread(target=worker, daemon=True).start()
        # 返回任务快照，前端据此订阅或轮询进度
        return task.snapshot()

    def _resolve_version(
        self,
        platform: str,
        project_id: str,
        version_id: str | None,
        minecraft_version: str | None,
        loader: str | None,
    ) -> dict[str, Any]:
        """确定要下载的具体版本。

        指定了 version_id 就直接取详情；否则取版本/文件列表按当前游戏版本与加载器过滤后的第一个
        （平台返回已按发布时间倒序，第一个通常就是最新兼容版本）。
        """
        modrinth, curseforge = self._clients()
        if platform == "curseforge":
            if version_id:
                return curseforge.file(project_id, version_id)
            files = curseforge.files(project_id, minecraft_version, loader)
            if not files:
                raise ModPlatformError("没有匹配当前版本与加载器的 CurseForge 文件")
            return files[0]
        if version_id:
            return modrinth.version(version_id)
        versions = modrinth.versions(project_id, minecraft_version, loader)
        if not versions:
            raise ModPlatformError("没有匹配当前版本与加载器的 Modrinth 版本")
        return versions[0]

    def _project_title(self, platform: str, project_id: str) -> str:
        """获取项目标题并缓存。

        查询失败时降级为“平台 #id”，保证下载流程不被标题请求阻塞。
        """
        if platform == "curseforge":
            key = f"cf:{project_id}"
            with self._lock:
                if key in self._title_cache:
                    return self._title_cache[key]
            try:
                data = self._clients()[1].mod(project_id)
                title = data.get("name") or f"CurseForge #{project_id}"
            except Exception:
                title = f"CurseForge #{project_id}"
        else:
            key = f"mr:{project_id}"
            with self._lock:
                if key in self._title_cache:
                    return self._title_cache[key]
            try:
                title = self._clients()[0].projects([project_id]).get(project_id) or f"Modrinth #{project_id}"
            except Exception:
                title = f"Modrinth #{project_id}"
        with self._lock:
            self._title_cache[key] = title
        return title

    def _install_version(
        self,
        version: dict[str, Any],
        title: str,
        with_dependencies: bool,
        enabled: bool,
        depth: int,
        visited: set[str],
        target_dir: Path,
        existing_task: Any = None,
        finish_task: bool = True,
    ) -> dict[str, Any]:
        """下载单个版本并递归处理其前置依赖。

        参数:
            depth: 当前递归深度，超过 2 层不再展开，防止依赖环导致无限递归。
            visited: 已处理版本签名集合，用于去重与防环。
            existing_task: 复用外部已创建的任务（顶层下载时传入）。
            finish_task: 是否由本方法收尾任务；顶层下载由 install 统一收尾。

        返回:
            包含最终文件路径、是否走了秒传跳过、依赖提示与子依赖结果的字典。
        """
        # 版本签名，用于去重与防止依赖环递归
        signature = f"{version.get('platform')}:{version.get('version_id')}"
        # 已处理过直接跳过
        if signature in visited:
            return {"file": None, "skipped": True, "dependencies": [], "children": []}
        visited.add(signature)

        task = existing_task or self.tasks.create(
            "download",
            f"下载 {title} {version.get('version_number') or ''}".strip(),
        )
        self.bus.log(f"开始下载 {title}（{version.get('platform')}）", source="mods")

        # 安装前先扫描本地，给出“已安装/缺前置”提示
        installed_ids = self._installed_mod_ids(target_dir)
        dependencies = self._dependency_hints(version, installed_ids)
        children: list[dict[str, Any]] = []
        try:
            primary = self._primary_file(version)
            if not primary:
                raise ModPlatformError("该版本没有可下载文件")
            result = download_file(
                primary["url"],
                target_dir,
                primary["filename"],
                expected_size=primary.get("size"),
                sha1=primary.get("sha1"),
                retries=int(self.config.get("download_retries", 3) or 3),
                timeout=int(self.config.get("download_timeout", 60) or 60),
                tasks=self.tasks,
                task_id=task.id,
                label=f"下载 {title}",
            )
            final_path = Path(result.path)
            # 下载后如需禁用，直接加 .disabled 后缀
            if not enabled and not final_path.name.lower().endswith(".disabled"):
                disabled = final_path.with_name(final_path.name + ".disabled")
                final_path.replace(disabled)
                final_path = disabled
            self.bus.publish(make_event("mods.downloaded", platform=version.get("platform"), project_id=version.get("project_id"), path=str(final_path)))

            # 依赖递归深度限制 2 层，防止依赖环爆炸
            if with_dependencies and depth < 2:
                for dependency in version.get("dependencies") or []:
                    # 自动安装只处理必需前置
                    if dependency.get("dependency_type") != "required":
                        continue
                    try:
                        child_version = self._resolve_dependency(version.get("platform"), dependency, version)
                        if child_version is None:
                            continue
                        child_title = self._project_title(version.get("platform"), dependency.get("project_id"))
                        children.append(
                            self._install_version(child_version, child_title, True, enabled, depth + 1, visited, target_dir)
                        )
                    except Exception as error:
                        children.append({"file": None, "error": str(error), "skipped": True, "dependencies": []})

            if finish_task:
                self.tasks.finish(
                    task.id,
                    {"file": str(final_path), "dependencies": dependencies, "children": children},
                    f"已下载到 {final_path.name}",
                )
            self.bus.log(f"{title} 已保存为 {final_path.name}", source="mods")
            self.bus.publish(make_event("mods.changed"))
            return {"file": str(final_path), "skipped": bool(result.skipped), "dependencies": dependencies, "children": children}
        except Exception as error:
            self.tasks.fail(task.id, str(error))
            self.bus.log(f"{title} 下载失败: {error}", source="mods", level="error")
            raise

    def _primary_file(self, version: dict[str, Any]) -> dict[str, Any] | None:
        """选出该版本的主下载文件：优先 primary 标记，否则取第一个可下载文件。
        """
        files = [item for item in version.get("files") or [] if item.get("url")]
        for item in files:
            if item.get("primary"):
                return item
        return files[0] if files else None

    def _resolve_dependency(self, platform: str | None, dependency: dict[str, Any], parent: dict[str, Any]) -> dict[str, Any] | None:
        """解析单个依赖对应的可下载版本。

        CurseForge 的依赖只给 modId，只能取该模组最新文件；
        Modrinth 优先用依赖里指定的 version_id，否则按父模组的加载器与游戏版本去找兼容版本。
        """
        project_id = dependency.get("project_id")
        if not project_id:
            return None
        modrinth, curseforge = self._clients()
        if platform == "curseforge":
            # CurseForge 依赖只给 modId，不限定版本与加载器，取最新文件
            files = curseforge.files(str(project_id), None, None)
            return files[0] if files else None
        if dependency.get("version_id"):
            return modrinth.version(dependency["version_id"])
        loaders = [value for value in parent.get("loaders") or [] if value in MODRINTH_LOADERS]
        game_versions = parent.get("game_versions") or []
        # 按父模组的首个游戏版本与加载器找兼容依赖
        versions = modrinth.versions(str(project_id), game_versions[0] if game_versions else None, loaders[0] if loaders else None)
        return versions[0] if versions else None

    def _dependency_hints(self, version: dict[str, Any], installed_ids: set[str]) -> list[dict[str, Any]]:
        """提取 required 依赖并转成展示用提示列表。
        """
        entries = [item for item in version.get("dependencies") or [] if item.get("dependency_type") == "required"]
        return self._dependency_details(version, installed_ids, entries=entries)

    def _dependency_details(
        self,
        version: dict[str, Any],
        installed_ids: set[str],
        entries: list[dict[str, Any]] | None = None,
    ) -> list[dict[str, Any]]:
        """把依赖条目补充为可展示的详情：项目名、类型、本地是否已安装。

        安装判定同时兼容 mod id 与“标题转连字符”两种形态，
        因为有些依赖只能拿到标题级别的信息。
        """
        entries = entries if entries is not None else [
            item
            for item in version.get("dependencies") or []
            if item.get("dependency_type") in {"required", "optional"}
        ]
        if not entries:
            return []
        hints: list[dict[str, Any]] = []
        platform = version.get("platform") or "modrinth"
        titles: dict[str, str] = {}
        if platform == "modrinth":
            try:
                titles = self._clients()[0].projects([str(item.get("project_id")) for item in entries if item.get("project_id")])
            except Exception:
                titles = {}
        # 去重，避免同一前置在列表里出现多次
        seen: set[str] = set()
        for item in entries:
            project_id = str(item.get("project_id") or "")
            if not project_id or project_id in seen:
                continue
            seen.add(project_id)
            title = titles.get(project_id) or f"{platform} #{project_id}"
            hints.append(
                {
                    "project_id": project_id,
                    "version_id": item.get("version_id"),
                    "name": title,
                    "dependency_type": item.get("dependency_type") or "optional",
                    # 兼容 mod id 与标题转连字符两种命中方式
                    "installed": project_id.lower() in installed_ids or title.lower().replace(" ", "-") in installed_ids,
                    "platform": platform,
                }
            )
        return hints

    def _installed_mod_ids(self, directory: Path | None = None) -> set[str]:
        """扫描目录得到已安装的 mod id 集合（小写去重）。
        扫描失败时返回空集合，避免影响主流程。
        """
        try:
            # 复用 scanner 的解析能力
            report = scan_mods(directory or self.config.mods_directory)
        except Exception:
            return set()
        ids: set[str] = set()
        for mod in report.get("mods", []):
            if mod.get("mod_id"):
                ids.add(mod["mod_id"].lower())
        return ids

    # ---------- 本地管理 ----------

    def scan(self, instance_id: str | None = None) -> dict[str, Any]:
        """扫描指定实例的模组目录，返回解析结果。
        """
        return scan_mods(self.mods_directory(instance_id))

    def toggle(self, file_name: str, instance_id: str | None = None) -> dict[str, Any]:
        """切换模组的启用/禁用状态。

        Minecraft 只识别 .jar，禁用即把文件重命名为 .jar.disabled；
        目标文件名已存在时拒绝操作，避免覆盖。
        """
        directory = self.mods_directory(instance_id)
        source = directory / file_name
        if not source.is_file():
            raise ModPlatformError("文件不存在")
        if source.name.lower().endswith(".disabled"):
            # 去掉后缀即恢复启用
            target = directory / source.name[: -len(".disabled")]
        else:
            # 加后缀即禁用，游戏不会加载
            target = directory / (source.name + ".disabled")
        # 目标已存在时拒绝，避免覆盖用户文件
        if target.exists():
            raise ModPlatformError(f"{target.name} 已存在，无法切换")
        source.replace(target)
        self.bus.publish(make_event("mods.changed", instance_id=instance_id))
        return {"file": target.name, "enabled": not target.name.lower().endswith(".disabled")}

    def delete(self, file_name: str, instance_id: str | None = None) -> dict[str, Any]:
        """删除模组文件。

        安全校验：先确认是普通文件，再用 resolve() 解析真实路径，
        确认父目录就是模组目录，防止通过 ../ 或软链接越权删除其它文件。
        """
        directory = self.mods_directory(instance_id)
        candidate = directory / file_name
        if not candidate.is_file():
            raise ModPlatformError("文件不存在")
        # 解析真实路径，软链接也会被展开
        resolved = candidate.resolve()
        # 防路径穿越：真实父目录必须是模组目录
        if resolved.parent != directory.resolve():
            raise ModPlatformError("非法的文件路径")
        # 只删文件本身，不做递归删除
        resolved.unlink()
        self.bus.publish(make_event("mods.changed", instance_id=instance_id))
        return {"deleted": resolved.name}
