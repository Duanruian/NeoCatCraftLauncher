"""模组文件下载工具。

提供文件名净化、重名避让、断点分块写入、SHA1/大小校验与失败重试，
并把下载进度同步到 TaskManager，供前端展示进度条。
"""

from __future__ import annotations

import hashlib
import re
import time
from dataclasses import dataclass
from pathlib import Path
from typing import Any

import httpx

from ..tasks import TaskManager

# 标识客户端身份，部分平台会拒绝空 UA 的下载请求
USER_AGENT = "NeoCatCraftLauncher/0.1.0 (mod manager; +https://modrinth.com)"
# 分块大小 64KB，兼顾内存占用与进度刷新频率
CHUNK_SIZE = 64 * 1024
# Windows 文件名非法字符（含 0x00-0x1f 控制字符），统一替换为下划线
_ILLEGAL = re.compile(r'[<>:"/\\|?*\x00-\x1f]')
# 已知扩展名，缺失时补 .jar
_KNOWN_EXTENSIONS = (".jar", ".jar.disabled", ".zip", ".mrpack")


@dataclass
class DownloadResult:
    """一次下载的结果描述。

    字段:
        path: 最终落盘路径。
        size: 文件字节数。
        skipped: 是否因已存在相同文件而跳过。
        attempts: 实际尝试次数。
        renamed_from: 若因重名被改名，这里记录改名后的文件名。
    """
    path: str
    size: int
    skipped: bool
    attempts: int
    renamed_from: str | None = None

    def snapshot(self) -> dict[str, Any]:
        """转换为可 JSON 序列化的字典，供 API 返回。
        """
        return {
            "path": self.path,
            "size": self.size,
            "skipped": self.skipped,
            "attempts": self.attempts,
            "renamed_from": self.renamed_from,
        }


def sanitize_filename(filename: str) -> str:
    """净化文件名，防止路径穿越与非法字符。

    处理:
        1. 去掉 Windows 不允许的字符与首尾空格、点；
        2. 空名兜底为 download.jar；
        3. 缺失已知扩展名时补 .jar；
        4. 截断到 180 字符，避免超出文件系统上限。
    """
    name = _ILLEGAL.sub("_", (filename or "").strip()).strip(" .")
    if not name:
        name = "download.jar"
    if not name.lower().endswith(_KNOWN_EXTENSIONS):
        name += ".jar"
    return name[:180]


def resolve_target(directory: Path, filename: str) -> tuple[Path, bool]:
    """计算可用的目标路径，处理重名。

    参数:
        directory: 目标目录，不存在会自动创建。
        filename: 原始文件名（会先净化）。

    返回:
        (目标路径, 是否因重名被改名)。重名时按 "名字 (1).jar" 递增命名。
    """
    directory.mkdir(parents=True, exist_ok=True)
    clean = sanitize_filename(filename)
    target = directory / clean
    if not target.exists():
        return target, False
    stem = target.stem
    suffix = target.suffix
    if clean.lower().endswith(".jar.disabled"):
        stem = clean[: -len(".jar.disabled")]
        suffix = ".jar.disabled"
    index = 1
    while True:
        candidate = directory / f"{stem} ({index}){suffix}"
        if not candidate.exists():
            return candidate, True
        index += 1


def _existing_same_file(target: Path, expected_size: int | None) -> bool:
    """判断目标文件是否已存在且大小匹配（用于秒传跳过）。
    未提供期望大小时一律视为不匹配，保证完整性可验证。
    """
    if not target.exists() or not expected_size:
        return False
    try:
        return target.stat().st_size == expected_size
    except OSError:
        return False


def download_file(
    url: str,
    directory: Path,
    filename: str,
    *,
    expected_size: int | None = None,
    sha1: str | None = None,
    retries: int = 3,
    timeout: int = 60,
    tasks: TaskManager | None = None,
    task_id: str | None = None,
    label: str = "",
) -> DownloadResult:
    """下载单个文件到指定目录。

    参数:
        url: 下载地址。
        directory: 保存目录。
        filename: 期望文件名。
        expected_size: 期望字节数，用于跳过判断与完整性校验。
        sha1: 期望的 SHA1，用于内容校验。
        retries: 最大尝试次数。
        timeout: 单次请求超时秒数。
        tasks / task_id: 进度上报所用任务管理器与任务 ID。
        label: 进度提示文案。

    返回:
        DownloadResult。

    异常:
        RuntimeError: 所有重试均失败。
    """
    directory.mkdir(parents=True, exist_ok=True)
    base_target = directory / sanitize_filename(filename)

    if _existing_same_file(base_target, expected_size):
        if tasks and task_id:
            tasks.progress(task_id, progress=expected_size, total=expected_size, message="已存在相同文件，跳过")
        return DownloadResult(path=str(base_target), size=expected_size or 0, skipped=True, attempts=0)

    target, renamed = resolve_target(directory, filename)
    # 先写 .part 临时文件，成功后再原子改名，避免留下半截文件
    partial = target.with_name(target.name + ".part")
    attempts = 0
    last_error: Exception | None = None

    headers = {"User-Agent": USER_AGENT, "Accept": "*/*"}

    while attempts < max(1, retries):
        attempts += 1
        try:
            # 跟随重定向，兼容各大平台的 CDN 跳转
            with httpx.Client(timeout=timeout, follow_redirects=True, headers=headers) as client:
                with client.stream("GET", url) as response:
                    response.raise_for_status()
                    # 优先用调用方给定的总量，否则取响应头
                    total = expected_size or int(response.headers.get("Content-Length") or 0)
                    if tasks and task_id and total:
                        tasks.progress(task_id, progress=0, total=total, message=label or "开始下载")
                    digest = hashlib.sha1()
                    written = 0
                    with partial.open("wb") as handle:
                        for chunk in response.iter_bytes(CHUNK_SIZE):
                            if not chunk:
                                continue
                            handle.write(chunk)
                            digest.update(chunk)
                            written += len(chunk)
                            if tasks and task_id:
                                tasks.progress(task_id, progress=written, message=label or "下载中")
                    # 边下边算 SHA1，避免二次读盘
                    if sha1 and digest.hexdigest().lower() != sha1.lower():
                        raise ValueError("文件校验失败（SHA1 不匹配）")
                    if expected_size and written != expected_size:
                        raise ValueError(f"文件大小不匹配（期望 {expected_size}，实际 {written}）")
            # 原子替换，保证目标文件不会出现写了一半的状态
            partial.replace(target)
            return DownloadResult(
                path=str(target),
                size=written,
                skipped=False,
                attempts=attempts,
                renamed_from=target.name if renamed else None,
            )
        except Exception as error:
            last_error = error
            try:
                partial.unlink(missing_ok=True)
            except OSError:
                pass
            if attempts < max(1, retries):
                if tasks and task_id:
                    tasks.progress(task_id, message=f"下载失败，第 {attempts} 次重试…")
                # 指数式退避，最长等待 6 秒
                time.sleep(min(1.5 * attempts, 6))
    raise RuntimeError(f"下载失败（已尝试 {attempts} 次）：{last_error}")
