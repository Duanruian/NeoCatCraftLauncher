"""模组子包。
对外统一导出模组下载、平台检索与本地扫描能力。
"""

from .downloader import DownloadResult, download_file, resolve_target
from .platform import ModPlatformError, ModService
from .scanner import parse_mod_jar, scan_mods

__all__ = [
    "DownloadResult",
    "download_file",
    "resolve_target",
    "ModPlatformError",
    "ModService",
    "parse_mod_jar",
    "scan_mods",
]
