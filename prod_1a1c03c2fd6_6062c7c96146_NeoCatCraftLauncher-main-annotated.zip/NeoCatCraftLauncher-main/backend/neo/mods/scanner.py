"""模组 jar 解析与本地扫描模块。

按优先级探测常见加载器的元数据文件：
    quilt.mod.json > fabric.mod.json > META-INF/neoforge.mods.toml >
    META-INF/mods.toml > mcmod.info > META-INF/MANIFEST.MF
从中提取名称、版本、mod id、作者、描述、适配版本与图标，
并输出可用于前端展示的 data URI 图标。解析失败的模组不会中断整体扫描，
而是在 issues 中记录原因。
"""

from __future__ import annotations

import base64
import json
import re
import zipfile
from pathlib import Path
from typing import Any

try:
    import tomllib
# tomllib 自 Python 3.11 起内置，低版本降级为不可用
except ModuleNotFoundError:
    tomllib = None

# 图标上限 384KB，防止过大图片拖慢列表渲染
ICON_LIMIT_BYTES = 384 * 1024
# 描述截断长度，避免超长文本撑爆卡片
DESCRIPTION_LIMIT = 260
# 图标缓存，键为 “路径|修改时间”，文件变更后自动失效
ICON_CACHE: dict[str, str | None] = {}

# Minecraft 颜色/格式代码（§ 加一个字符）
_FORMAT_CODE = re.compile(r"\u00a7.")
_WHITESPACE = re.compile(r"\s+")
_IMAGE_SUFFIXES = {".png", ".jpg", ".jpeg", ".gif", ".webp", ".bmp"}


def _clean_text(value: Any, limit: int = DESCRIPTION_LIMIT) -> str:
    """清理元数据文本：去掉 Minecraft 颜色/格式代码（§x）、压缩连续空白、截断到指定长度。
    """
    if not value:
        return ""
    text = _FORMAT_CODE.sub("", str(value))
    text = _WHITESPACE.sub(" ", text).strip()
    return text[:limit]


def _jar_display_name(path: Path) -> str:
    """从文件名推导展示名，逐层剥离 .jar / .disabled 后缀。
    """
    filename = path.name
    while filename.lower().endswith((".jar", ".disabled")):
        filename = filename.rsplit(".", 1)[0]
    return filename or path.stem


def _as_list(value: Any) -> list[str]:
    """把各种形态的作者字段统一成字符串列表。

    兼容：单个字符串、字典（取 key）、列表/元组（元素可为字符串或含 name/login/id 的字典）。
    """
    if isinstance(value, str):
        return [value] if value.strip() else []
    # 部分加载器的作者字段是 {作者名: 角色} 形式的字典
    if isinstance(value, dict):
        return [str(key) for key in value.keys()]
    if isinstance(value, (list, tuple)):
        result: list[str] = []
        for item in value:
            if isinstance(item, str):
                result.append(item)
            elif isinstance(item, dict):
                candidate = item.get("name") or item.get("login") or item.get("id")
                if candidate:
                    result.append(str(candidate))
        return result
    return []


def _read_json(archive: zipfile.ZipFile, name: str) -> Any:
    """读取 jar 内的 JSON 文件并解析。
    文件不存在或解析失败都返回 None，交由调用方尝试下一个加载器。
    """
    try:
        raw = archive.read(name)
    except KeyError:
        return None
    except Exception:
        return None
    try:
        return json.loads(raw.decode("utf-8", errors="replace"))
    except Exception:
        return None


def _read_text(archive: zipfile.ZipFile, name: str) -> str | None:
    """读取 jar 内的文本文件（UTF-8，非法字节替换），失败返回 None。
    """
    try:
        return archive.read(name).decode("utf-8", errors="replace")
    except Exception:
        return None


def _image_mime(data: bytes, suffix: str) -> str:
    """按文件头魔数识别图片 MIME，识别不出时按扩展名兜底为 PNG。

    比只看扩展名可靠：有些 mod 的 logo 扩展名与实际格式不一致。
    """
    # PNG 文件头魔数
    if data.startswith(b"\x89PNG\r\n\x1a\n"):
        return "image/png"
    # JPEG 文件头魔数
    if data.startswith(b"\xff\xd8\xff"):
        return "image/jpeg"
    if data.startswith((b"GIF87a", b"GIF89a")):
        return "image/gif"
    if data.startswith(b"RIFF") and data[8:12] == b"WEBP":
        return "image/webp"
    if data.startswith(b"BM"):
        return "image/bmp"
    return {
        ".jpg": "image/jpeg",
        ".jpeg": "image/jpeg",
        ".gif": "image/gif",
        ".webp": "image/webp",
        ".bmp": "image/bmp",
    }.get(suffix.lower(), "image/png")


def _icon_candidates(icon_path: str, mod_id: Any) -> list[str]:
    """生成图标的候选路径列表。

    依次尝试：原路径、命名空间写法（assets/<ns>/<path>）、
    补 assets/ 前缀、assets/<mod_id>/<path>，最后是约定俗成的
    assets/<mod_id>/icon.png 与根目录 icon.png / logo.png。
    """
    candidates: list[str] = []

    def add(value: str) -> None:
        normalized = value.replace("\\", "/").strip().lstrip("/")
        if normalized and normalized not in candidates:
            candidates.append(normalized)

    path = icon_path.replace("\\", "/").strip().lstrip("/")
    if path:
        add(path)
        # 命名空间写法 model:path，需展开为 assets/<ns>/<path>
        if ":" in path and "://" not in path:
            namespace, resource = path.split(":", 1)
            if namespace and resource:
                add(f"assets/{namespace}/{resource}")
        if not path.lower().startswith("assets/"):
            add(f"assets/{path}")
            identifier = _clean_text(mod_id, 120).lower()
            if identifier:
                add(f"assets/{identifier}/{path}")

    identifier = _clean_text(mod_id, 120).lower()
    if identifier:
        for filename in ("icon.png", "logo.png", "icon.jpg", "logo.jpg"):
            add(f"assets/{identifier}/{filename}")
    for filename in ("icon.png", "logo.png"):
        add(filename)
    return candidates


def _icon_data_uri(archive: zipfile.ZipFile, icon_path: Any, mod_id: Any = None) -> str | None:
    """把 jar 内的图标转成 data:image/...;base64 字符串。

    安全与性能:
        1. 只接受白名单图片后缀，且限制文件大小（ICON_LIMIT_BYTES）；
        2. 已是 data URI 时直接透传，但限制长度；
        3. 主路径匹配不到时，允许按“唯一同名文件”做一次回退匹配，
           避免误取到别的模组图标。
    """
    if isinstance(icon_path, dict):
        icon_path = icon_path.get("path") or icon_path.get("icon")
    if not isinstance(icon_path, str):
        icon_path = ""

    raw_path = icon_path.strip()
    if raw_path.lower().startswith("data:image/"):
        if len(raw_path.encode("utf-8")) <= ICON_LIMIT_BYTES * 2:
            return raw_path
        return None

    # zip 内路径大小写不敏感匹配（Windows 打包的 jar 常见大小写不一致）
    archive_names = {name.lower(): name for name in archive.namelist()}
    for candidate in _icon_candidates(raw_path, mod_id):
        actual = archive_names.get(candidate.lower())
        if not actual:
            continue
        try:
            info = archive.getinfo(actual)
            # 跳过空文件与超限文件，避免解压炸弹
            if info.file_size <= 0 or info.file_size > ICON_LIMIT_BYTES:
                continue
            data = archive.read(actual)
        except Exception:
            continue
        suffix = Path(actual).suffix.lower()
        if suffix and suffix not in _IMAGE_SUFFIXES:
            continue
        mime = _image_mime(data, suffix)
        return f"data:{mime};base64," + base64.b64encode(data).decode("ascii")

    # Metadata occasionally uses a different directory but the same unique
    # image filename. Only use that fallback when the basename is unambiguous.
    basename = Path(raw_path.replace("\\", "/")).name.lower()
    if basename and Path(basename).suffix.lower() in _IMAGE_SUFFIXES:
        matches = [
            actual
            for lowered, actual in archive_names.items()
            if Path(lowered).name == basename and Path(lowered).suffix.lower() in _IMAGE_SUFFIXES
        ]
        # 同名文件唯一时才采用回退匹配，防止取错图标
        if len(matches) == 1:
            try:
                info = archive.getinfo(matches[0])
                if 0 < info.file_size <= ICON_LIMIT_BYTES:
                    data = archive.read(matches[0])
                    suffix = Path(matches[0]).suffix.lower()
                    mime = _image_mime(data, suffix)
                    return f"data:{mime};base64," + base64.b64encode(data).decode("ascii")
            except Exception:
                pass
    return None


def _parse_fabric(archive: zipfile.ZipFile, meta: dict[str, Any]) -> dict[str, Any]:
    """解析 fabric.mod.json。
    适配版本从 depends.minecraft 中读取，作者取 authors 列表。
    """
    return {
        "loader": "fabric",
        "name": meta.get("name") or meta.get("id"),
        "version": meta.get("version"),
        "mod_id": meta.get("id"),
        "description": meta.get("description"),
        "authors": _as_list(meta.get("authors")),
        "mc_version": (meta.get("depends") or {}).get("minecraft"),
        "icon": meta.get("icon"),
    }


def _parse_quilt(archive: zipfile.ZipFile, meta: dict[str, Any]) -> dict[str, Any]:
    """解析 quilt.mod.json。

    Quilt 的结构是 quilt_loader 包裹 metadata 与 depends，
    依赖是数组形式，需遍历找到 id 为 minecraft 的条目取其版本范围。
    """
    loader_section = meta.get("quilt_loader") or {}
    metadata = loader_section.get("metadata") or {}
    dependencies = loader_section.get("depends") or []
    minecraft_range = None
    if isinstance(dependencies, list):
        for entry in dependencies:
            if isinstance(entry, dict) and entry.get("id") == "minecraft":
                # Quilt 依赖以数组描述，取 minecraft 项的版本范围
                minecraft_range = entry.get("versions")
    return {
        "loader": "quilt",
        "name": metadata.get("name") or loader_section.get("id"),
        "version": loader_section.get("version"),
        "mod_id": loader_section.get("id"),
        "description": metadata.get("description"),
        "authors": _as_list(metadata.get("contributors")),
        "mc_version": minecraft_range,
        "icon": metadata.get("icon"),
    }


def _parse_toml(archive: zipfile.ZipFile, text: str, loader: str) -> dict[str, Any]:
    """解析 Forge / NeoForge 的 mods.toml。

    只取第一个 [[mods]] 段作为主模组信息，同时记录文件内模组数量（mod_count）；
    适配版本从 [[dependencies.*]] 中 modId 为 minecraft 的 versionRange 读取。

    异常:
        ValueError: 当前 Python 缺少 tomllib（<3.11）时抛出。
    """
    if tomllib is None:
        raise ValueError("当前 Python 缺少 tomllib，无法解析 mods.toml")
    data = tomllib.loads(text)
    mods = data.get("mods") or []
    first = mods[0] if mods else {}
    minecraft_range = None
    dependencies = data.get("dependencies") or {}
    # Forge 的依赖按 loader 分组，需要遍历各组内的数组
    if isinstance(dependencies, dict):
        for entries in dependencies.values():
            if not isinstance(entries, list):
                continue
            for entry in entries:
                if isinstance(entry, dict) and str(entry.get("modId", "")).lower() in {"minecraft"}:
                    minecraft_range = entry.get("versionRange")
    return {
        "loader": loader,
        "name": first.get("displayName") or first.get("modId"),
        "version": first.get("version"),
        "mod_id": first.get("modId"),
        "description": first.get("description"),
        "authors": _as_list(first.get("authors")) or _as_list(data.get("authors")),
        "mc_version": minecraft_range,
        "icon": first.get("logoFile") or data.get("logoFile"),
        "mod_count": len(mods),
        "mod_loader": data.get("modLoader"),
        "loader_version": data.get("loaderVersion"),
    }


def _parse_mcmod_info(archive: zipfile.ZipFile, data: Any) -> dict[str, Any]:
    """解析旧版 Forge 的 mcmod.info。

    兼容两种结构：{modList: [...]} 或直接是数组。
    """
    if isinstance(data, dict):
        entries = data.get("modList") or data.get("modlist") or []
    elif isinstance(data, list):
        entries = data
    else:
        entries = []
    first = entries[0] if entries else {}
    return {
        "loader": "forge",
        "name": first.get("name") or first.get("modid"),
        "version": first.get("version"),
        "mod_id": first.get("modid"),
        "description": first.get("description"),
        "authors": _as_list(first.get("authorList") or first.get("author")),
        "mc_version": first.get("mcversion") or first.get("acceptedMinecraftVersions"),
        "icon": first.get("logoFile"),
        "mod_count": len(entries),
    }


def _parse_manifest(archive: zipfile.ZipFile, text: str) -> dict[str, Any]:
    """解析 META-INF/MANIFEST.MF 作为最后兜底。

    按 RFC 风格处理续行（以空格开头的行表示上一行内容的延续），
    从中取 Implementation-Title / Version / Vendor。
    """
    fields: dict[str, str] = {}
    key = None
    for line in text.splitlines():
        if not line.strip():
            continue
        # MANIFEST.MF 续行规则：以空格开头的行接到上一个键上
        if line.startswith(" ") and key:
            fields[key] += line.strip()
            continue
        if ":" in line:
            key, value = line.split(":", 1)
            key = key.strip().lower()
            fields[key] = value.strip()
    return {
        "loader": "unknown",
        "name": fields.get("implementation-title"),
        "version": fields.get("implementation-version"),
        "mod_id": None,
        "description": None,
        "authors": _as_list(fields.get("implementation-vendor")),
        "mc_version": None,
        "icon": None,
    }


def parse_mod_jar(path: Path) -> dict[str, Any]:
    """解析单个模组 jar，返回结构化信息。

    参数:
        path: jar 文件路径。

    返回:
        包含文件名、大小、修改时间、启用状态、名称、版本、mod id、
        加载器、描述、作者、适配版本、图标 data URI、是否解析成功、
        以及 issues（解析过程中的问题清单）的字典。

    容错:
        jar 无法打开时只记录 issue 并返回基础信息，绝不抛异常中断整体扫描。
    """
    stat = path.stat()
    base: dict[str, Any] = {
        "file_name": path.name,
        "path": str(path),
        "size": stat.st_size,
        "modified": stat.st_mtime,
        "enabled": not path.name.lower().endswith(".disabled"),
        "name": _jar_display_name(path),
        "version": "",
        "mod_id": "",
        "loader": "unknown",
        "description": "",
        "authors": [],
        "mc_version": None,
        "icon": None,
        "parsed": False,
        "issues": [],
    }

    try:
        archive = zipfile.ZipFile(path)
    except Exception as error:
        base["issues"].append(f"无法读取 jar: {error.__class__.__name__}")
        return base

    with archive:
        metadata: dict[str, Any] | None = None
        try:
            # 探测顺序 1：Quilt（兼容 Fabric 格式，优先识别更具体的）
            quilt_json = _read_json(archive, "quilt.mod.json")
            fabric_json = _read_json(archive, "fabric.mod.json")
            if quilt_json is not None:
                metadata = _parse_quilt(archive, quilt_json)
            # 探测顺序 2：Fabric
            elif fabric_json is not None:
                metadata = _parse_fabric(archive, fabric_json)
            if metadata is None:
                # 探测顺序 3：NeoForge
                neoforge_text = _read_text(archive, "META-INF/neoforge.mods.toml")
                if neoforge_text:
                    metadata = _parse_toml(archive, neoforge_text, "neoforge")
            if metadata is None:
                # 探测顺序 4：Forge
                forge_text = _read_text(archive, "META-INF/mods.toml")
                if forge_text:
                    metadata = _parse_toml(archive, forge_text, "forge")
            if metadata is None:
                # 探测顺序 5：旧版 Forge 的 mcmod.info
                info = _read_json(archive, "mcmod.info")
                if info is not None:
                    metadata = _parse_mcmod_info(archive, info)
            if metadata is None:
                # 探测顺序 6：通用 MANIFEST.MF 兜底
                manifest = _read_text(archive, "META-INF/MANIFEST.MF")
                if manifest:
                    metadata = _parse_manifest(archive, manifest)
        except Exception as error:
            base["issues"].append(f"元数据解析失败: {error}")

        if metadata is None:
            base["issues"].append("未找到可识别的模组元数据")
            return base

        base["name"] = _clean_text(metadata.get("name"), 120) or _jar_display_name(path)
        base["version"] = _clean_text(metadata.get("version"), 60)
        base["mod_id"] = _clean_text(metadata.get("mod_id"), 120)
        base["loader"] = metadata.get("loader") or "unknown"
        base["description"] = _clean_text(metadata.get("description"))
        base["authors"] = [a for a in (_clean_text(x, 60) for x in metadata.get("authors") or []) if a][:6]
        base["mc_version"] = _clean_text(metadata.get("mc_version"), 60) or None
        base["parsed"] = bool(base["version"] or base["mod_id"] or metadata.get("name"))

        # 以路径+修改时间做缓存键，文件被替换后缓存自然失效
        cache_key = f"{path}|{stat.st_mtime}"
        if cache_key in ICON_CACHE:
            base["icon"] = ICON_CACHE[cache_key]
        else:
            icon = _icon_data_uri(archive, metadata.get("icon"), metadata.get("mod_id"))
            ICON_CACHE[cache_key] = icon
            base["icon"] = icon

    return base


def scan_mods(mods_directory: Path) -> dict[str, Any]:
    """扫描模组目录。

    返回:
        directory（目录）、count（总数）、unparsed（未解析成功数）、
        duplicates（重复 mod id → 文件名列表）、mods（逐个模组信息）。

    重复检测的意义：同名 mod id 的多个 jar 同时存在会导致游戏启动失败，
    前端可据此提示用户清理。
    """
    mods_directory.mkdir(parents=True, exist_ok=True)
    files = sorted(
        [entry for entry in mods_directory.iterdir() if entry.is_file() and entry.name.lower().endswith((".jar", ".jar.disabled"))],
        key=lambda entry: entry.name.lower(),
    )
    # 逐个解析，单个失败只影响自身条目
    mods = [parse_mod_jar(entry) for entry in files]

    duplicates: dict[str, list[str]] = {}
    for mod in mods:
        if mod["mod_id"]:
            duplicates.setdefault(mod["mod_id"], []).append(mod["file_name"])
    # 只保留真正重复的 mod id（同名文件多于一个）
    duplicate_ids = {mod_id: names for mod_id, names in duplicates.items() if len(names) > 1}

    return {
        "directory": str(mods_directory),
        "count": len(mods),
        "unparsed": len([mod for mod in mods if not mod["parsed"]]),
        "duplicates": duplicate_ids,
        "mods": mods,
    }
