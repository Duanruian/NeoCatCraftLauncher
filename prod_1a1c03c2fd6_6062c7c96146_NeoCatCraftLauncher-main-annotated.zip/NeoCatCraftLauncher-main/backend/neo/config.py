"""配置与账号存储模块。

职责:
    1. 定义全局常量（应用名、版本、端口、各类 API 地址）与默认设置；
    2. 以 JSON 文件持久化用户设置（settings.json）与账号列表（accounts.json）；
    3. 以读写锁保护内存中的配置副本，对外只返回深拷贝，避免调用方误改。

配置目录优先取环境变量 NEO_CONFIG_DIR，其次 APPDATA，最后用户主目录。
"""

from __future__ import annotations

import copy
import json
import os
import threading
from pathlib import Path
from typing import Any

from .mirror import DEFAULT_BMCLAPI_BASE

APP_NAME = "NeoCatCraftLauncher"
# 版本号，同时用于 User-Agent 与前端展示
APP_VERSION = "0.2.2"
# 本地后端服务默认端口（仅监听本机）
DEFAULT_PORT = 47821
BUNDLED_CURSEFORGE_API_KEY = "$2a$10$1KoV3Z0Sd0GAwO1g6ptAjuNuEx63qCy5KjHY6bWsMEjuGs9urbWlS"

# Azul Zulu JDK 元数据接口，用于自动下载 Java
AZUL_API = "https://api.azul.com/metadata/v1/zulu"
# 统一通行证（外置登录）认证服务基准地址
UNIFIED_AUTH_BASE = "https://auth.mc-user.com:233"

DEFAULT_SKIN_SITES: list[dict[str, str]] = [
    {"id": "littleskin", "name": "LittleSkin", "url": "https://littleskin.cn/api/yggdrasil"},
    {"id": "littleskin-global", "name": "LittleSkin 国际", "url": "https://littleskin.cn/api/yggdrasil"},
    {"id": "custom", "name": "自定义皮肤站", "url": ""},
]

# 推荐 JVM 参数：G1 回收器 + 强制 UTF-8，兼容多数整合包中文日志
SAFE_JVM_ARGS = "-XX:+UseG1GC -Dfile.encoding=UTF-8"
# 旧版默认参数，仅用于启动时识别并迁移
LEGACY_JVM_ARGS = (
    "-XX:+UseG1GC -XX:G1NewSizePercent=20 "
    "-XX:+UnlockExperimentalVMOptions -Dfile.encoding=UTF-8"
)


def _default_minecraft_directory() -> str:
    """推断 .minecraft 目录位置。

    优先调用 minecraft_launcher_lib 的官方逻辑（可识别各平台约定目录），
    库不可用时回退到 ~/.minecraft。
    """
    try:
        # 可选依赖：已安装时可用其跨平台默认目录推断
        import minecraft_launcher_lib

        return minecraft_launcher_lib.utils.get_minecraft_directory()
    except Exception:
        return str(Path.home() / ".minecraft")


def _config_dir() -> Path:
    """计算本应用的配置目录。

    优先级: NEO_CONFIG_DIR 环境变量 > APPDATA > 用户主目录。
    """
    # 便携模式/测试时可通过环境变量指定配置目录
    override = os.environ.get("NEO_CONFIG_DIR")
    if override:
        return Path(override)
    base = os.environ.get("APPDATA") or str(Path.home())
    return Path(base) / APP_NAME


DEFAULT_SETTINGS: dict[str, Any] = {
    "minecraft_directory": _default_minecraft_directory(),
    "java_path": "",
    "memory_mb": 4096,
    "min_memory_mb": 512,
    "jvm_args": SAFE_JVM_ARGS,
    "resolution": {"enabled": False, "width": 1280, "height": 720},
    "microsoft_client_id": os.environ.get("NEO_MS_CLIENT_ID", ""),
    # 优先使用用户自备 Key，未配置时回落内置 Key
    "curseforge_api_key": os.environ.get("NEO_CURSEFORGE_API_KEY") or BUNDLED_CURSEFORGE_API_KEY,
    "preferred_platform": "all",
    "last_version": "",
    "last_loader": "fabric",
    "minecraft_download_source": "official",
    "bmclapi_base": DEFAULT_BMCLAPI_BASE,
    "download_retries": 3,
    "download_timeout": 60,
    "close_animation": True,
    "theme": "ocean",
    "theme_mode": "light",
    "accent_color": "",
    "first_run_done": False,
    "disclaimer_accepted": False,
    "default_isolation": True,
    "active_instance": "",
    "javas_directory": "",
    "java_provider": "zulu",
    "auto_download_java": True,
    "zulu_api": AZUL_API,
    "skin_sites": copy.deepcopy(DEFAULT_SKIN_SITES),
    "unified_auth_base": UNIFIED_AUTH_BASE,
    "unified_server_id": "",
    "authlib_injector_url": "",
}


class Config:
    """配置与账号的内存缓存 + 文件持久化入口。

    所有读写方法均加可重入锁，保证多线程（API 线程、任务线程）并发安全；
    settings 与 accounts 两个属性都会返回深拷贝，防止外部修改内部状态。
    """
    def __init__(self) -> None:
        """初始化配置对象：确定文件路径、载入磁盘内容，并执行一次性的配置迁移。

        迁移内容:
            旧版 LEGACY_JVM_ARGS 会被替换为 SAFE_JVM_ARGS，避免部分 JVM 启动失败；
            即使配置文件只读，内存中的迁移也照常生效。
        """
        self.dir = _config_dir()
        self.dir.mkdir(parents=True, exist_ok=True)
        self.settings_file = self.dir / "settings.json"
        self.accounts_file = self.dir / "accounts.json"
        self._lock = threading.RLock()
        self._settings: dict[str, Any] = copy.deepcopy(DEFAULT_SETTINGS)
        self._accounts: list[dict[str, Any]] = []
        self._active_account: str | None = None
        self._load()
        # 一次性迁移：把旧默认 JVM 参数替换为新版
        if self._settings.get("jvm_args") == LEGACY_JVM_ARGS:
            self._settings["jvm_args"] = SAFE_JVM_ARGS
            try:
                self._save_settings()
            except OSError:
                # The in-memory migration still keeps this session launchable
                # when the user configuration directory is read-only.
                pass

    def _load(self) -> None:
        """从磁盘载入设置与账号。

        容错策略：文件缺失或 JSON 解析失败都静默忽略，保持默认值继续运行；
        CurseForge API Key 为空时自动回落为内置 Key。
        """
        if self.settings_file.is_file():
            try:
                stored = json.loads(self.settings_file.read_text(encoding="utf-8"))
                # 只接受字典，防止配置被写成数组/标量后污染内存状态
                if isinstance(stored, dict):
                    self._settings.update(stored)
            except Exception:
                pass
        if not str(self._settings.get("curseforge_api_key") or "").strip():
            self._settings["curseforge_api_key"] = BUNDLED_CURSEFORGE_API_KEY
        if self.accounts_file.is_file():
            try:
                stored = json.loads(self.accounts_file.read_text(encoding="utf-8"))
                self._accounts = list(stored.get("accounts", []))
                self._active_account = stored.get("active")
            except Exception:
                pass

    def _save_settings(self) -> None:
        """把当前设置整体写入 settings.json（UTF-8、保留中文、缩进 2）。
        """
        self.settings_file.write_text(
            json.dumps(self._settings, ensure_ascii=False, indent=2), encoding="utf-8"
        )

    def _save_accounts(self) -> None:
        """把账号列表与当前激活账号写入 accounts.json。
        """
        payload = {"accounts": self._accounts, "active": self._active_account}
        self.accounts_file.write_text(
            json.dumps(payload, ensure_ascii=False, indent=2), encoding="utf-8"
        )

    @property
    def settings(self) -> dict[str, Any]:
        """返回设置的完整深拷贝，供只读展示使用。
        """
        with self._lock:
            return copy.deepcopy(self._settings)

    def get(self, key: str, default: Any = None) -> Any:
        """读取单个配置项，返回深拷贝。

        参数:
            key: 配置键名。
            default: 键不存在时的默认值。
        """
        with self._lock:
            return copy.deepcopy(self._settings.get(key, default))

    def set(self, key: str, value: Any) -> None:
        """写入单个配置项并立即落盘。
        """
        with self._lock:
            self._settings[key] = value
            self._save_settings()

    def update_settings(self, patch: dict[str, Any]) -> dict[str, Any]:
        """批量更新配置并落盘，返回更新后的完整设置。

        只接受 DEFAULT_SETTINGS 中已定义的键，未知键被忽略，防止配置文件被写脏。
        """
        with self._lock:
            for key, value in patch.items():
                # 白名单校验：忽略未知配置键，避免写入无效字段
                if key in DEFAULT_SETTINGS:
                    self._settings[key] = value
            self._save_settings()
            return copy.deepcopy(self._settings)

    @property
    def minecraft_directory(self) -> Path:
        """Minecraft 主目录（保证存在）。
        路径取自配置，为空或非法时回退到默认位置。
        """
        path = Path(self.get("minecraft_directory") or _default_minecraft_directory())
        path.mkdir(parents=True, exist_ok=True)
        return path

    @property
    def mods_directory(self) -> Path:
        """全局模组目录（<minecraft>/mods），不存在则创建。
        """
        path = self.minecraft_directory / "mods"
        path.mkdir(parents=True, exist_ok=True)
        return path

    @property
    def javas_directory(self) -> Path:
        """Java 运行时存放目录。
        配置为空时使用配置目录下的 javas，保证便携。
        """
        configured = (self.get("javas_directory") or "").strip()
        path = Path(configured) if configured else self.dir / "javas"
        path.mkdir(parents=True, exist_ok=True)
        return path

    @property
    def instances_directory(self) -> Path:
        """实例根目录（<minecraft>/instances），不存在则创建。
        """
        path = self.minecraft_directory / "instances"
        path.mkdir(parents=True, exist_ok=True)
        return path

    @property
    def accounts(self) -> list[dict[str, Any]]:
        """返回账号列表的深拷贝（含令牌等敏感字段，仅内部使用）。
        """
        with self._lock:
            return copy.deepcopy(self._accounts)

    def public_accounts(self) -> list[dict[str, Any]]:
        """返回可直接下发给前端的账号列表。

        脱敏处理：剔除 accessToken、refreshToken 等凭据，只保留展示所需字段。
        """
        result = []
        for account in self.accounts:
            result.append(
                {
                    "uuid": account.get("uuid"),
                    "name": account.get("name"),
                    "type": account.get("type", "offline"),
                    "active": account.get("uuid") == self._active_account,
                    "skin": account.get("skin"),
                    "skin_model": account.get("skin_model") or "classic",
                    "cape": account.get("cape"),
                    "server": account.get("server"),
                    "server_name": account.get("server_name"),
                }
            )
        return result

    def find_account(self, uuid: str) -> dict[str, Any] | None:
        """按 UUID 查找账号（返回深拷贝），未找到返回 None。
        """
        for account in self.accounts:
            if account.get("uuid") == uuid:
                return account
        return None

    def active_account(self) -> dict[str, Any] | None:
        """返回当前激活账号（深拷贝），未激活或已被删除时返回 None。
        """
        for account in self.accounts:
            if account.get("uuid") == self._active_account:
                return account
        return None

    def set_active_account(self, uuid: str | None) -> None:
        """设置当前激活账号并落盘；传入 None 表示取消激活。
        """
        with self._lock:
            self._active_account = uuid
            self._save_accounts()

    def upsert_account(self, account: dict[str, Any]) -> None:
        """新增或更新账号：先移除同 UUID 旧记录再追加，并将其设为激活账号。
        """
        with self._lock:
            self._accounts = [a for a in self._accounts if a.get("uuid") != account.get("uuid")]
            self._accounts.append(account)
            self._active_account = account.get("uuid")
            self._save_accounts()

    def update_account(self, uuid: str, patch: dict[str, Any]) -> dict[str, Any] | None:
        """按 UUID 局部更新账号字段。

        返回:
            更新后的账号深拷贝；UUID 不存在时返回 None。
        """
        with self._lock:
            for account in self._accounts:
                if account.get("uuid") != uuid:
                    continue
                account.update(patch)
                self._save_accounts()
                return copy.deepcopy(account)
        return None

    def remove_account(self, uuid: str) -> None:
        """删除账号。
        若删除的是当前激活账号，自动切换到剩余列表中的第一个，账号全空则置为 None。
        """
        with self._lock:
            self._accounts = [a for a in self._accounts if a.get("uuid") != uuid]
            if self._active_account == uuid:
                # 删除当前账号后自动切换到剩余第一个账号
                self._active_account = self._accounts[0]["uuid"] if self._accounts else None
            self._save_accounts()

    def redirect_uri(self) -> str:
        """Microsoft 登录回调地址。
        端口取环境变量 NEO_PORT，缺省使用 DEFAULT_PORT，需与 Azure 应用注册的回调保持一致。
        """
        # 端口需与 OAuth 应用注册的回调地址一致
        port = int(os.environ.get("NEO_PORT", DEFAULT_PORT))
        return f"http://localhost:{port}/api/auth/microsoft/callback"
