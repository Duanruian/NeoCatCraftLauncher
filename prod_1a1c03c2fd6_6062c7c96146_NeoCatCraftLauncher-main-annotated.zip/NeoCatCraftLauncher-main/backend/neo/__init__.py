"""neo 后端核心包。
集中导出配置、事件总线与任务管理器等公共对象，
便于上层（FastAPI 路由层）以 from neo import ... 的方式统一引用。
"""

from .config import APP_NAME, APP_VERSION, Config
from .events import EventBus, make_event
from .tasks import TaskManager

__all__ = ["APP_NAME", "APP_VERSION", "Config", "EventBus", "make_event", "TaskManager"]
