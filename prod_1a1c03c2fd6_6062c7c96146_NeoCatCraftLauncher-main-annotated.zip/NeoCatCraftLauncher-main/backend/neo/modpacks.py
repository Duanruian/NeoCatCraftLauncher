"""整合包安装服务模块。

支持两种主流格式：
    1. .mrpack（Modrinth）：读 modrinth.index.json，用 minecraft_launcher_lib 官方实现安装；
    2. CurseForge 整合包：读 manifest.json，自行创建实例、安装基础环境、
       释放 overrides 配置、按清单逐个下载模组。

安装全程在后台线程执行，进度通过 TaskManager 汇报，完成后发布
instances.changed / versions.changed 事件让前端刷新实例列表。
"""

from __future__ import annotations

import json
import shutil
import tempfile
import threading
import zipfile
from concurrent.futures import ThreadPoolExecutor, as_completed
from pathlib import Path
from typing import Any
from urllib.parse import unquote, urlparse

import httpx
import minecraft_launcher_lib as mll

from .config import Config
from .events import EventBus, make_event
from .instances import InstanceError, InstanceManager
from .java_manager import JavaManager
from .mods.downloader import USER_AGENT, download_file
from .mods.platform import CURSEFORGE_API, CurseForgeClient, ModrinthClient, ModPlatformError
from .tasks import TaskManager

# CurseForge 中“整合包”的分类 id
CURSEFORGE_MODPACK_CLASS = 4471

# mrpack 的清单文件，作为格式识别标志
MRPACK_INDEX = "modrinth.index.json"
# CurseForge 整合包的清单文件，作为格式识别标志
CURSEFORGE_MANIFEST = "manifest.json"


class ModpackError(RuntimeError):
    pass


def _loader_from_manifest_id(raw: str) -> tuple[str, str]:
    """从 CurseForge manifest 的加载器 id 中拆出加载器名与版本。

    形如 fabric-0.15.7 / neoforge-20.4.237，返回 ("fabric", "0.15.7")；
    无法识别时按 vanilla 处理，避免因加载器信息异常导致整体安装失败。
    """
    text = (raw or "").strip()
    if not text:
        return "vanilla", ""
    lowered = text.lower()
    # 按名称长度优先匹配，避免 neoforge 被误判为 forge
    for name in ("neoforge", "fabric", "quilt", "forge"):
        prefix = f"{name}-"
        if lowered.startswith(prefix):
            return name, text[len(prefix):]
    if "-" in text:
        head, _, tail = text.partition("-")
        return head.strip().lower(), tail.strip()
    return "vanilla", ""


def _loader_from_mrpack(dependencies: dict[str, Any]) -> tuple[str, str]:
    """从 mrpack 的 dependencies 中识别加载器与版本。

    键名到加载器名的映射见 mapping，一个都没命中时返回 vanilla。
    """
    mapping = {
        "fabric-loader": "fabric",
        "quilt-loader": "quilt",
        "forge": "forge",
        "neoforge": "neoforge",
    }
    for key, loader in mapping.items():
        value = dependencies.get(key)
        if value:
            return loader, str(value)
    return "vanilla", ""


def _read_zip_json(archive: Path, name: str) -> dict[str, Any] | None:
    """读取压缩包内的 JSON 文件。

    文件不存在或解析失败都返回 None，调用方借此判断整合包格式。
    """
    try:
        with zipfile.ZipFile(archive) as bundle:
            if name not in bundle.namelist():
                return None
            return json.loads(bundle.read(name).decode("utf-8"))
    except Exception:
        return None


def _safe_member(name: str, root: Path) -> Path | None:
    """把压缩包内的相对路径解析为目标目录下的安全路径。

    用于防 Zip Slip：解析后的路径必须仍位于 root 之内，
    否则返回 None 并跳过该条目（恶意整合包可通过 ../../ 写出任意文件）。
    """
    # 先解析为绝对路径，再判断是否越界
    target = (root / name).resolve()
    try:
        # 不在 root 之下会抛 ValueError，从而被拦截
        target.relative_to(root.resolve())
    except ValueError:
        return None
    return target


def _extract_overrides(archive: Path, prefix: str, target_dir: Path) -> int:
    """释放整合包里的 overrides 目录到实例目录。

    参数:
        prefix: overrides 前缀（CurseForge 清单可自定义该目录名）。

    返回写入的文件数量，便于日志统计。
    """
    written = 0
    with zipfile.ZipFile(archive) as bundle:
        for entry in bundle.infolist():
            if not entry.filename.startswith(prefix) or entry.is_dir():
                continue
            relative = entry.filename[len(prefix):]
            if not relative:
                continue
            destination = _safe_member(relative, target_dir)
            if destination is None:
                continue
            destination.parent.mkdir(parents=True, exist_ok=True)
            # 流式复制，避免大文件一次性读入内存
            with bundle.open(entry) as source, destination.open("wb") as handle:
                shutil.copyfileobj(source, handle)
            written += 1
    return written


class ModpackService:
    def __init__(
        self,
        config: Config,
        tasks: TaskManager,
        bus: EventBus,
        instances: InstanceManager,
        java: JavaManager,
    ) -> None:
        """初始化服务，持有配置、任务、事件、实例与 Java 管理器，并创建互斥锁。
        """
        self.config = config
        self.tasks = tasks
        self.bus = bus
        self.instances = instances
        self.java = java
        self._lock = threading.Lock()

    # ---------- 平台 ----------

    def _modrinth(self) -> ModrinthClient:
        """构造 Modrinth 客户端（整合包搜索与版本查询共用）。
        """
        # 整合包接口超时统一 20 秒
        return ModrinthClient(timeout=20)

    def _curseforge(self) -> CurseForgeClient:
        """构造 CurseForge 客户端，API Key 从配置读取。
        """
        return CurseForgeClient(self.config.get("curseforge_api_key") or "", timeout=20)

    def search(
        self,
        platform: str,
        query: str,
        minecraft_version: str | None = None,
        limit: int = 20,
        offset: int = 0,
    ) -> dict[str, Any]:
        """搜索整合包。

        CurseForge 侧用 classId=4471 过滤出整合包分类，
        Modrinth 侧用 project_type=modpack 过滤；两者都不传加载器条件。
        platform=all 时并行聚合。
        """
        if platform == "all":
            return self._aggregate_search(query, minecraft_version, limit, offset)
        if platform == "curseforge":
            return self._curseforge().search(
                query,
                minecraft_version,
                None,
                limit,
                offset,
                # 限定只搜整合包分类
                class_id=CURSEFORGE_MODPACK_CLASS,
            )
        # Modrinth 侧限定项目类型为整合包
        return self._modrinth().search(query, minecraft_version, None, limit, offset, project_type="modpack")

    def _aggregate_search(
        self,
        query: str,
        minecraft_version: str | None,
        limit: int,
        offset: int,
    ) -> dict[str, Any]:
        """并行聚合两个平台的整合包搜索结果。

        单平台失败只记录 warnings，不影响整体返回；
        结果按下载量降序、标题升序排序。
        """
        hits: list[dict[str, Any]] = []
        warnings: list[str] = []
        with ThreadPoolExecutor(max_workers=2) as pool:
            futures = {
                # 两个平台并行搜索，缩短首屏等待
                pool.submit(self.search, platform, query, minecraft_version, limit, offset): platform
                for platform in ("modrinth", "curseforge")
            }
            for future in as_completed(futures):
                platform = futures[future]
                try:
                    payload = future.result()
                    hits.extend(payload.get("hits") or [])
                except Exception as error:
                    warnings.append(f"{platform}: {error}")
        hits.sort(
            key=lambda item: (
                -int(item.get("downloads") or 0),
                str(item.get("title") or "").lower(),
            )
        )
        return {
            "platform": "all",
            "total": len(hits),
            "hits": hits[: max(1, min(limit, 50))],
            "offset": max(0, offset),
            "warnings": warnings,
        }

    def versions(self, platform: str, project_id: str, minecraft_version: str | None = None) -> dict[str, Any]:
        """获取整合包的版本列表。

        CurseForge 的文件结构需要拍平成与 Modrinth 一致的精简结构，
        只保留前端展示需要的字段（文件名、大小等）。
        """
        if platform == "curseforge":
            files = self._curseforge().files(project_id, minecraft_version)
            items = [
                {
                    "version_id": item["version_id"],
                    "name": item.get("name"),
                    "version_number": item.get("version_number"),
                    "channel": item.get("channel"),
                    "game_versions": item.get("game_versions") or [],
                    "loaders": item.get("loaders") or [],
                    "date": item.get("date"),
                    "filename": (item.get("files") or [{}])[0].get("filename"),
                    "size": (item.get("files") or [{}])[0].get("size"),
                }
                for item in files
            ]
            return {"platform": platform, "project_id": project_id, "versions": items}
        modrinth = self._modrinth()
        return {
            "platform": platform,
            "project_id": project_id,
            "versions": modrinth.versions(project_id, minecraft_version, None),
        }

    # ---------- 安装 ----------

    def install(
        self,
        platform: str,
        project_id: str,
        version_id: str | None = None,
        name: str | None = None,
    ) -> dict[str, Any]:
        """从在线平台下载并安装整合包（异步）。

        流程:
            1. 创建 modpack 任务并立即返回快照；
            2. 后台线程解析下载地址 → 下载到临时目录 → 识别格式并安装；
            3. 完成或失败都更新任务状态与事件日志；
            4. 无论如何都清理临时目录。
        """
        project_id = str(project_id or "").strip()
        if not project_id:
            raise ModpackError("缺少 project_id")
        task = self.tasks.create("modpack", f"安装整合包 #{project_id}")

        def worker() -> None:
            """后台安装协程：临时目录在 finally 中清理，避免遗留垃圾文件。
            """
            temp_dir: Path | None = None
            try:
                url, filename = self._resolve_download(platform, project_id, version_id)
                # 下载到独立临时目录，安装结束后整体删除
                temp_dir = Path(tempfile.mkdtemp(prefix="neo-modpack-"))
                archive = temp_dir / filename
                self.tasks.progress(task.id, message=f"下载整合包 {filename}")
                downloaded = download_file(
                    url,
                    temp_dir,
                    filename,
                    retries=int(self.config.get("download_retries", 3) or 3),
                    timeout=int(self.config.get("download_timeout", 60) or 60),
                    tasks=self.tasks,
                    task_id=task.id,
                    label=f"下载整合包 {filename}",
                )
                # download_file may sanitize or de-duplicate the requested name.
                # Always install the file that was actually written to disk.
                # 以下载器实际写盘的文件为准：文件名可能被清洗或去重
                archive = Path(downloaded.path)
                instance = self._install_archive(archive, task.id, fallback_name=name)
                self.tasks.finish(
                    task.id,
                    {"instance": instance["id"], "name": instance["name"]},
                    f"整合包已安装：{instance['name']}",
                )
                self.bus.publish(make_event("instances.changed"))
                self.bus.publish(make_event("versions.changed"))
                self.bus.log(f"整合包 {instance['name']} 已安装到 {instance['directory']}", source="modpack")
            except Exception as error:
                self.tasks.fail(task.id, str(error))
                self.bus.log(f"整合包安装失败: {error}", source="modpack", level="error")
            finally:
                if temp_dir is not None:
                    shutil.rmtree(temp_dir, ignore_errors=True)

        threading.Thread(target=worker, daemon=True).start()
        return task.snapshot()

    def import_file(self, path: str, name: str | None = None) -> dict[str, Any]:
        """从本地文件导入整合包（异步）。

        与在线安装共用 _install_archive，区别是不需要下载、直接使用用户给定的文件。
        """
        source = Path(path)
        if not source.is_file():
            raise ModpackError(f"文件不存在: {path}")
        task = self.tasks.create("modpack", f"导入整合包 {source.name}")

        def worker() -> None:
            """后台导入协程：成功后同样发布实例与版本变更事件。
            """
            try:
                instance = self._install_archive(source, task.id, fallback_name=name)
                self.tasks.finish(
                    task.id,
                    {"instance": instance["id"], "name": instance["name"]},
                    f"整合包已导入：{instance['name']}",
                )
                self.bus.publish(make_event("instances.changed"))
                self.bus.publish(make_event("versions.changed"))
            except Exception as error:
                self.tasks.fail(task.id, str(error))
                self.bus.log(f"导入整合包失败: {error}", source="modpack", level="error")

        threading.Thread(target=worker, daemon=True).start()
        return task.snapshot()

    # ---------- 内部 ----------

    def _resolve_download(self, platform: str, project_id: str, version_id: str | None) -> tuple[str, str]:
        """解析整合包的下载地址与文件名。

        优先使用指定版本；未指定时取列表第一个（平台已按时间倒序）。
        对 Modrinth 优先取 primary 标记的文件。
        下载地址缺失时抛出 ModpackError，由上层转成任务失败提示。
        """
        if platform == "curseforge":
            client = self._curseforge()
            if version_id:
                item = client.file(project_id, version_id)
            else:
                files = client.files(project_id)
                if not files:
                    raise ModpackError("该整合包没有可用文件")
                item = files[0]
            primary = (item.get("files") or [None])[0]
            if not primary or not primary.get("url"):
                raise ModpackError("CurseForge 未提供该整合包的下载地址")
            return primary["url"], primary.get("filename") or f"{project_id}-{version_id}.zip"
        modrinth = self._modrinth()
        if version_id:
            version = modrinth.version(version_id)
        else:
            files = modrinth.versions(project_id, None, None)
            if not files:
                raise ModpackError("该整合包没有可用版本")
            version = files[0]
        primary = next((item for item in version.get("files") or [] if item.get("primary")), None)
        if primary is None:
            files = version.get("files") or []
            primary = files[0] if files else None
        if not primary or not primary.get("url"):
            raise ModpackError("Modrinth 未提供该整合包的下载地址")
        return primary["url"], primary.get("filename") or f"{project_id}.mrpack"

    def _install_archive(self, archive: Path, task_id: str, fallback_name: str | None = None) -> dict[str, Any]:
        """按压缩包内的标志文件识别格式并分派安装。

        存在 modrinth.index.json → mrpack；存在 manifest.json → CurseForge 整合包；
        两者都没有则报错，避免把普通压缩包当成整合包安装。
        """
        if _read_zip_json(archive, MRPACK_INDEX) is not None:
            return self._install_mrpack(archive, task_id, fallback_name)
        if _read_zip_json(archive, CURSEFORGE_MANIFEST) is not None:
            return self._install_curseforge(archive, task_id, fallback_name)
        raise ModpackError("无法识别的整合包格式（仅支持 .mrpack 与 CurseForge 整合包）")

    def _install_mrpack(self, archive: Path, task_id: str, fallback_name: str | None) -> dict[str, Any]:
        """安装 .mrpack 整合包。

        步骤:
            1. 读 index.json 拿到 Minecraft 版本、加载器与整合包名；
            2. 创建隔离实例；
            3. 先安装基础环境（游戏本体 + 加载器）；
            4. 交给 mll.mrpack.install_mrpack 释放文件；
               其中 skipDependenciesInstall=True 表示不装整合包自带的加载器依赖，
               因为上一步已经装好，避免重复下载与版本冲突。

        返回: 安装完成后的实例信息。
        """
        index = _read_zip_json(archive, MRPACK_INDEX) or {}
        dependencies = index.get("dependencies") or {}
        mc_version = str(dependencies.get("minecraft") or "").strip()
        if not mc_version:
            raise ModpackError("整合包缺少 Minecraft 版本信息")
        loader, loader_version = _loader_from_mrpack(dependencies)
        title = str(index.get("name") or fallback_name or archive.stem)
        instance = self.instances.create(
            {
                "name": title,
                "mc_version": mc_version,
                "loader": loader,
                "loader_version": loader_version,
                "isolation": True,
                "notes": str(index.get("summary") or ""),
            }
        )
        directory = self.instances.directory_of(instance)
        self.tasks.progress(task_id, message=f"安装基础环境 Minecraft {mc_version}")
        version_id = self._install_base(mc_version, loader, loader_version, task_id)
        self.instances.update(instance["id"], {"version_id": version_id})
        self.tasks.progress(task_id, message="下载整合包模组文件")
        mll.mrpack.install_mrpack(
            str(archive),
            str(self.config.minecraft_directory),
            modpack_directory=str(directory),
            callback=self._callback(task_id),
            # 加载器已由 _install_base 安装，这里跳过以免重复安装
            mrpack_install_options={"skipDependenciesInstall": True},
        )
        return self.instances.require(instance["id"])

    def _install_curseforge(self, archive: Path, task_id: str, fallback_name: str | None) -> dict[str, Any]:
        """安装 CurseForge 格式整合包。

        步骤:
            1. 读 manifest.json 拿到游戏版本与加载器（多条时优先 primary）；
            2. 创建隔离实例并安装基础环境；
            3. 释放 overrides 中的配置文件；
            4. 逐条按 projectID/fileID 下载必需模组，单条失败只记录并继续；
            5. 全部结束后若有失败则汇总报错（列出前 3 条与剩余数量）。

        这样处理的原因：整合包里通常有几十上百个文件，
        单点失败就让整个安装回滚的体验很差，先尽量装完再提示缺哪些。
        """
        manifest = _read_zip_json(archive, CURSEFORGE_MANIFEST) or {}
        minecraft = manifest.get("minecraft") or {}
        mc_version = str(minecraft.get("version") or "").strip()
        if not mc_version:
            raise ModpackError("整合包缺少 Minecraft 版本信息")
        loaders = [
            item for item in minecraft.get("modLoaders") or []
            if isinstance(item, dict) and item.get("id")
        ]
        primary = next((item for item in loaders if item.get("primary")), None)
        if primary is None and loaders:
            primary = loaders[0]
        loader_raw = str((primary or {}).get("id") or "")
        loader, loader_version = _loader_from_manifest_id(loader_raw)
        title = str(manifest.get("name") or fallback_name or archive.stem)
        authors = manifest.get("author") or ""
        instance = self.instances.create(
            {
                "name": title,
                "mc_version": mc_version,
                "loader": loader,
                "loader_version": loader_version,
                "isolation": True,
                "notes": f"CurseForge 整合包 {manifest.get('version') or ''} · {authors}".strip(),
            }
        )
        directory = self.instances.directory_of(instance)
        self.tasks.progress(task_id, message=f"安装基础环境 Minecraft {mc_version}")
        version_id = self._install_base(mc_version, loader, loader_version, task_id)
        self.instances.update(instance["id"], {"version_id": version_id})

        # 清单可自定义 overrides 目录名，末尾补斜杠以便前缀匹配
        overrides = str(manifest.get("overrides") or "overrides").rstrip("/") + "/"
        self.tasks.progress(task_id, message="释放整合包配置文件")
        # 把整合包自带的配置、资源包等释放到实例目录
        _extract_overrides(archive, overrides, directory)

        # 只处理必需文件，可选文件可由用户后续自行添加
        entries = [item for item in manifest.get("files") or [] if item.get("required", True)]
        mods_dir = self.instances.mods_directory_of(instance)
        total = max(1, len(entries))
        self.tasks.progress(task_id, total=total, progress=0, message="下载整合包模组文件")
        failures: list[str] = []
        for position, entry in enumerate(entries):
            project_id = str(entry.get("projectID") or "").strip()
            file_id = str(entry.get("fileID") or "").strip()
            if not project_id or not file_id:
                failures.append("整合包清单中存在缺少 projectID/fileID 的文件")
                continue
            try:
                url, filename = self._curseforge_file(project_id, file_id)
                download_file(
                    url,
                    mods_dir,
                    filename,
                    retries=int(self.config.get("download_retries", 3) or 3),
                    timeout=int(self.config.get("download_timeout", 60) or 60),
                    tasks=self.tasks,
                    task_id=task_id,
                    label=f"下载 {filename}",
                )
            except Exception as error:
                detail = f"{project_id}/{file_id}: {error}"
                failures.append(detail)
                self.bus.log(f"CurseForge 文件下载失败 {detail}", source="modpack", level="error")
            self.tasks.progress(task_id, progress=position + 1, total=total)
        # 全部尝试完再统一报错，避免一个文件失败就中断安装
        if failures:
            preview = "；".join(failures[:3])
            suffix = f"；另有 {len(failures) - 3} 个文件失败" if len(failures) > 3 else ""
            raise ModpackError(f"有 {len(failures)} 个必需文件下载失败：{preview}{suffix}")
        return self.instances.require(instance["id"])

    def _curseforge_file(self, project_id: str, file_id: str) -> tuple[str, str]:
        """解析 CurseForge 文件的下载地址。

        优先用文件详情里的 url；没有 url 时（作者禁用第三方分发）
        调用 download-url 接口换取官方临时下载地址，仍需 API Key。
        返回 (url, filename)，文件名缺失时从 URL 路径反推。
        """
        item = self._curseforge().file(project_id, file_id)
        primary = (item.get("files") or [{}])[0]
        url = primary.get("url")
        filename = primary.get("filename")
        if url:
            return url, filename or f"{project_id}-{file_id}.jar"
        api_key = (self.config.get("curseforge_api_key") or "").strip()
        if not api_key:
            raise ModpackError("CurseForge 需要 API Key 才能下载该文件")
        headers = {"User-Agent": USER_AGENT, "x-api-key": api_key, "Accept": "application/json"}
        with httpx.Client(timeout=30, follow_redirects=True, headers=headers) as client:
            response = client.get(f"{CURSEFORGE_API}/mods/{project_id}/files/{file_id}/download-url")
        if response.status_code != 200:
            raise ModpackError(f"CurseForge 下载地址获取失败（HTTP {response.status_code}）")
        # download-url 接口把地址放在 data 字段
        resolved = (response.json() or {}).get("data")
        if not resolved:
            raise ModpackError("该文件不允许第三方下载")
        return resolved, filename or unquote(urlparse(resolved).path.rsplit("/", 1)[-1])

    def _install_base(self, mc_version: str, loader: str, loader_version: str, task_id: str) -> str:
        """安装基础环境：Minecraft 本体 + 指定加载器。

        native 版本直接返回游戏版本号；装了加载器则返回加载器安装后的版本 id，
        该 id 需要写回实例，启动时才找得到正确的版本。
        Java 通过 JavaManager 按游戏版本自动选择。
        """
        self.tasks.progress(task_id, message=f"安装 Minecraft {mc_version}")
        mll.install.install_minecraft_version(
            mc_version,
            str(self.config.minecraft_directory),
            callback=self._callback(task_id),
        )
        # 未装加载器时，启动用的版本 id 就是游戏版本号
        version_id = mc_version
        if loader and loader != "vanilla":
            self.tasks.progress(task_id, message=f"安装 {loader} {loader_version}".strip())
            # 按加载器名取对应的安装实现（forge/fabric/quilt/neoforge）
            module = mll.mod_loader.get_mod_loader(loader)
            version_id = module.install(
                mc_version,
                str(self.config.minecraft_directory),
                loader_version=loader_version or None,
                callback=self._callback(task_id),
                # 部分加载器安装器需要 Java 才能运行，按游戏版本挑选运行时
                java=self.java.resolve_for_install(mc_version),
            )
        return version_id

    def _callback(self, task_id: str) -> dict[str, Any]:
        """构造 minecraft_launcher_lib 所需的回调字典。

        把库回调的状态/进度/总量映射到 TaskManager，使前端进度条与实际下载同步。
        """
        def set_status(status: str) -> None:
            self.tasks.progress(task_id, message=str(status))

        def set_progress(progress: int) -> None:
            self.tasks.progress(task_id, progress=int(progress))

        def set_max(maximum: int) -> None:
            self.tasks.progress(task_id, total=int(maximum))

        return {"setStatus": set_status, "setProgress": set_progress, "setMax": set_max}


__all__ = ["ModpackError", "ModpackService", "ModPlatformError", "InstanceError"]
