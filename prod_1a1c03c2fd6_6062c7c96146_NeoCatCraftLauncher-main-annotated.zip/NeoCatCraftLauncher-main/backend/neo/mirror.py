"""Minecraft 官方资源下载镜像（BMCLAPI）支持模块。

实现方式非常轻量：在进程启动时接管 requests.Session.request，
当用户选择了 BMCLAPI 下载源时，把发往 Mojang / Forge / Fabric / Quilt / NeoForge
官方域名的 GET 请求改写为镜像地址；镜像不可用（超时、5xx、403/404 等）时
自动回退到原地址，保证下载成功率。
"""

from __future__ import annotations

import threading
from typing import Any
from urllib.parse import urlsplit, urlunsplit

import requests
# 直接导入具体类，便于后续整体替换其 request 方法
from requests.sessions import Session


# BMCLAPI 公共镜像的默认入口，可在配置中覆盖
DEFAULT_BMCLAPI_BASE = "https://bmclapi2.bangbang93.com"
# 支持的下载源标识，其他取值一律视为 official
DOWNLOAD_SOURCES = {"official", "bmclapi"}
_FALLBACK_STATUS_CODES = {403, 404, 408, 410, 425, 429}
# 默认超时（连接 8 秒，读取 60 秒）
_TIMEOUT = (8, 60)

# 可重入锁，保护下面几个全局开关的读写
_lock = threading.RLock()
_enabled = False
_base = DEFAULT_BMCLAPI_BASE
# 保存原始实现，回退时直接调用它，避免递归
_original_session_request = Session.request
_request_patch_installed = False


def _normalize_base(value: Any) -> str:
    """规范化镜像根地址。

    仅接受 http/https 且带主机名的地址，否则回退到默认 BMCLAPI 地址，
    并去掉结尾多余的斜杠。
    """
    base = str(value or DEFAULT_BMCLAPI_BASE).strip().rstrip("/")
    # 校验协议与主机名，非法地址直接回退默认值
    parsed = urlsplit(base)
    if parsed.scheme not in {"http", "https"} or not parsed.netloc:
        return DEFAULT_BMCLAPI_BASE
    return base


def _mirror_url(url: str) -> str | None:
    """把官方下载地址映射为镜像地址。

    按主机名区分资源类型并拼接对应前缀：
        resources.download.minecraft.net -> /assets（游戏资源文件）
        libraries.minecraft.net / *.minecraftforge.net / maven.* -> /maven（依赖库）
        launchermeta / piston-meta / piston-data -> 原路径（版本元数据 JSON）
        meta.fabricmc.net -> /fabric-meta，meta.quiltmc.org -> /quilt-meta

    返回:
        镜像 URL；域名不在支持列表内时返回 None，表示不代理。
    """
    if not url or not str(url).lower().startswith(("http://", "https://")):
        return None
    parsed = urlsplit(str(url))
    host = parsed.hostname.lower() if parsed.hostname else ""
    # 路径为空时补 /，保证拼接结果合法
    path = parsed.path or "/"

    # 游戏资源文件（音效、语言包、贴图索引等）
    if host == "resources.download.minecraft.net":
        mirror_path = "/assets" + path
    # Mojang 官方依赖库（Maven 布局）
    elif host == "libraries.minecraft.net":
        mirror_path = "/maven" + path
    # 版本清单与元数据类主机，镜像路径与原路径一致
    elif host in {
        "launchermeta.mojang.com",
        "launcher.mojang.com",
        "piston-meta.mojang.com",
        "piston-data.mojang.com",
    }:
        mirror_path = path
    # Forge 依赖库
    elif host == "maven.minecraftforge.net":
        mirror_path = "/maven" + path
    # Forge 下载站的 maven 子路径需要重写，去掉重复前缀
    elif host == "files.minecraftforge.net" and path.startswith("/maven"):
        mirror_path = "/maven" + path.removeprefix("/maven")
    # Fabric 元数据接口
    elif host == "meta.fabricmc.net":
        mirror_path = "/fabric-meta" + path
    # Fabric 依赖库
    elif host == "maven.fabricmc.net":
        mirror_path = "/maven" + path
    # Quilt 元数据接口
    elif host == "meta.quiltmc.org":
        mirror_path = "/quilt-meta" + path
    # NeoForge 的 maven 资源；/api/ 接口不代理，保持官方直连
    elif host == "maven.neoforged.net" and not path.startswith("/api/"):
        mirror_path = "/maven" + path
    else:
        return None

    with _lock:
        base = _base
    return base + mirror_path + (f"?{parsed.query}" if parsed.query else "")


def _should_fallback(response: Any) -> bool:
    """判断镜像响应是否需要回退到官方源。
    限流、鉴权失败类状态码以及所有 5xx 都视为镜像不可用。
    """
    status = int(getattr(response, "status_code", 0) or 0)
    # 限流/鉴权失败与服务器错误都触发回退
    return status in _FALLBACK_STATUS_CODES or status >= 500


def _patched_session_request(self: Session, method: str, url: str, **kwargs: Any) -> Any:
    """替换 requests.Session.request 的代理实现。

    行为约定：
        1. 默认注入 8 秒连接 / 60 秒读取超时；
        2. 仅在开启镜像且方法为 GET 时改写 URL；
        3. 镜像请求抛异常或返回需回退的状态码时，静默改走原地址。

    这是全局猴子补丁，因此所有调用方无需改动代码即可享受镜像加速。
    """
    # 调用方未显式指定超时时补默认值，避免请求无限挂起
    kwargs.setdefault("timeout", _TIMEOUT)
    with _lock:
        enabled = _enabled
    # 只改写 GET 请求，POST/PUT 等一律走官方地址
    mirrored = _mirror_url(url) if enabled and str(method).upper() == "GET" else None
    if not mirrored:
        return _original_session_request(self, method, url, **kwargs)
    try:
        response = _original_session_request(self, method, mirrored, **kwargs)
    # 镜像连接失败（DNS/超时/证书）时回退官方源
    except requests.RequestException:
        return _original_session_request(self, method, url, **kwargs)
    # 镜像返回异常状态码时关闭响应并重试官方源
    if _should_fallback(response):
        response.close()
        return _original_session_request(self, method, url, **kwargs)
    return response


def install_request_patch() -> None:
    """安装全局请求补丁（幂等，重复调用无副作用）。

    注意:
        补丁只在首次调用时替换 Session.request，之后再次调用直接返回；
        因此进程生命周期内只生效一次。
    """
    global _request_patch_installed
    with _lock:
        if _request_patch_installed:
            return
        Session.request = _patched_session_request
        _request_patch_installed = True


def configure_download_mirror(config: Any) -> None:
    """根据配置切换下载源。

    参数:
        config: 配置对象，需支持 get()，读取 minecraft_download_source
            （official / bmclapi）与 bmclapi_base 两项。

    非法的下载源名称会被静默纠正为 official，避免配置手误导致下载失败。
    """
    global _enabled, _base
    source = str(config.get("minecraft_download_source") or "official").strip().lower()
    if source not in DOWNLOAD_SOURCES:
        source = "official"
    base = _normalize_base(config.get("bmclapi_base"))
    with _lock:
        _enabled = source == "bmclapi"
        _base = base


# 模块导入即安装补丁，保证所有下载路径都受配置控制
install_request_patch()


__all__ = [
    "DEFAULT_BMCLAPI_BASE",
    "DOWNLOAD_SOURCES",
    "configure_download_mirror",
]
