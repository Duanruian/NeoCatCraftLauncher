"""任务管理模块。
把耗时操作（下载、安装、启动等）抽象为 Task 对象，统一维护状态、进度与结果，
并通过 EventBus 向前端推送 task 事件，供界面显示进度条。
"""

from __future__ import annotations

import time
import uuid
from dataclasses import asdict, dataclass, field
from typing import Any

from .events import EventBus, make_event


@dataclass
class Task:
    """单个任务的运行时状态快照。

    字段:
        id: 任务短 ID（uuid 前 12 位）。
        kind: 任务类型，如 download / install / launch。
        title: 展示给用户的标题。
        state: 运行状态，running / done / error。
        progress: 已完成数量。
        total: 总数量，为 0 表示总量未知。
        message: 当前阶段提示文案。
        result: 成功后的结构化结果。
        error: 失败原因。
        created_at / updated_at: 创建与最后更新时间戳。
    """
    id: str
    kind: str
    title: str
    state: str = "running"
    progress: int = 0
    total: int = 0
    message: str = ""
    result: dict[str, Any] | None = None
    error: str | None = None
    created_at: float = field(default_factory=time.time)
    updated_at: float = field(default_factory=time.time)

    def snapshot(self) -> dict[str, Any]:
        """序列化为前端可直接消费的字典，并额外计算百分比。
        总量为 0 时百分比固定为 0，避免除零。
        """
        data = asdict(self)
        # 总量未知时百分比按 0 处理，避免除零
        data["percent"] = round(self.progress / self.total * 100, 1) if self.total else 0.0
        return data


class TaskManager:
    """任务注册表与进度推送器。

    负责创建任务、更新字段、限制推送频率，以及在任务过多时清理已完成的旧任务。
    """
    def __init__(self, bus: EventBus) -> None:
        """初始化任务管理器。

        参数:
            bus: 用于对外推送 task 事件的事件总线。
        """
        self.bus = bus
        self._tasks: dict[str, Task] = {}
        # 记录每个任务上次推送时间，用于节流
        self._last_publish: dict[str, float] = {}

    def create(self, kind: str, title: str, total: int = 0) -> Task:
        """注册一个新任务并立即推送一次（force=True 绕过节流）。
        """
        task = Task(id=uuid.uuid4().hex[:12], kind=kind, title=title, total=total)
        self._tasks[task.id] = task
        self._trim()
        self._publish(task, force=True)
        return task

    def get(self, task_id: str) -> Task | None:
        """按 ID 取任务对象，不存在返回 None。
        """
        return self._tasks.get(task_id)

    def list(self) -> list[dict[str, Any]]:
        """返回所有任务的快照列表，按创建时间倒序（最新在前）。
        """
        return [task.snapshot() for task in sorted(self._tasks.values(), key=lambda t: t.created_at, reverse=True)]

    def update(self, task_id: str, force: bool = False, **fields: Any) -> Task | None:
        """更新任务字段并推送。
        仅更新 Task 已有属性，未知字段被忽略，防止写坏对象。
        """
        task = self._tasks.get(task_id)
        if task is None:
            return None
        for key, value in fields.items():
            if hasattr(task, key):
                setattr(task, key, value)
        task.updated_at = time.time()
        self._publish(task, force=force)
        return task

    def finish(self, task_id: str, result: dict[str, Any] | None = None, message: str = "") -> Task | None:
        """把任务标记为完成并附带结果。
        """
        return self.update(task_id, force=True, state="done", result=result or {}, message=message)

    def fail(self, task_id: str, error: str) -> Task | None:
        """把任务标记为失败并记录错误信息。
        """
        return self.update(task_id, force=True, state="error", error=error, message=error)

    def progress(self, task_id: str, progress: int | None = None, total: int | None = None, message: str | None = None) -> None:
        """更新进度信息的便捷方法。
        只覆盖显式传入的字段，未传入的保持原值；total 需大于 0 才更新。
        """
        fields: dict[str, Any] = {}
        if progress is not None:
            fields["progress"] = max(0, progress)
        if total is not None and total > 0:
            fields["total"] = total
        if message is not None:
            fields["message"] = message
        self.update(task_id, **fields)

    def _publish(self, task: Task, force: bool = False) -> None:
        """推送任务快照，默认做 0.12 秒节流。
        高频进度回调不会淹没事件队列，但 force=True 时立即推送。
        """
        now = time.time()
        last = self._last_publish.get(task.id, 0.0)
        # 节流窗口 120ms，避免进度事件刷屏
        if not force and now - last < 0.12:
            return
        self._last_publish[task.id] = now
        self.bus.publish(make_event("task", task=task.snapshot()))

    def _trim(self) -> None:
        """任务数量控制：已完成任务超过 40 个时，删除最旧的若干条。
        运行中的任务永不清理。
        """
        finished = [t for t in self._tasks.values() if t.state != "running"]
        if len(finished) <= 40:
            return
        finished.sort(key=lambda t: t.updated_at)
        for task in finished[: len(finished) - 40]:
            self._tasks.pop(task.id, None)
            self._last_publish.pop(task.id, None)
