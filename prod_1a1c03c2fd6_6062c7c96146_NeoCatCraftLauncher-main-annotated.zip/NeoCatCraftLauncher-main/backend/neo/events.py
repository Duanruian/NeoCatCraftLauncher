"""事件总线模块。
后端各业务模块（下载、安装、启动等）通过 EventBus 向前端推送事件，
事件以 dict 形式承载，经 WebSocket 转发给渲染进程，用于刷新日志与任务进度。
"""

from __future__ import annotations

import asyncio
import time
from typing import Any


def make_event(kind: str, **payload: Any) -> dict[str, Any]:
    """构造一条标准事件字典。

    参数:
        kind: 事件类型标识，如 log / task / instance 等。
        **payload: 附加到事件上的业务字段。

    返回:
        含 type（类型）与 ts（时间戳）的事件字典。
    """
    event = {"type": kind, "ts": time.time()}
    event.update(payload)
    return event


class EventBus:
    """进程内异步事件总线。

    设计要点：后端工作线程（同步代码）可以安全地发布事件，
    实际投递通过 loop.call_soon_threadsafe 切回事件循环线程完成；
    每个订阅者拥有独立队列，互不阻塞。
    """
    def __init__(self) -> None:
        """初始化总线：订阅者集合为空，绑定的事件循环尚未设置。
        """
        # 所有订阅者队列，使用 set 便于增删且避免重复注册
        self._subscribers: set[asyncio.Queue] = set()
        self._loop: asyncio.AbstractEventLoop | None = None

    def bind_loop(self, loop: asyncio.AbstractEventLoop) -> None:
        """绑定后端主事件循环。
        只有绑定之后 publish 才会真正投递事件。
        """
        self._loop = loop

    def subscribe(self) -> asyncio.Queue:
        """注册一个新的订阅者并返回其专属队列。
        队列容量 2048，超出时由 _deliver 丢弃最旧事件，避免慢消费者拖垮整体。
        """
        # 每个订阅者独立的队列，容量受限以防止内存膨胀
        queue: asyncio.Queue = asyncio.Queue(maxsize=2048)
        self._subscribers.add(queue)
        return queue

    def unsubscribe(self, queue: asyncio.Queue) -> None:
        """注销订阅者队列（例如 WebSocket 断开时调用）。
        """
        self._subscribers.discard(queue)

    def publish(self, event: dict[str, Any]) -> None:
        """线程安全地发布事件。
        未绑定循环或循环已关闭时静默丢弃，保证关闭阶段不会抛异常。
        """
        loop = self._loop
        if loop is None or loop.is_closed():
            return
        try:
            # 从工作线程切回事件循环线程投递，保证队列操作单线程安全
            loop.call_soon_threadsafe(self._deliver, event)
        # 事件循环正在关闭时忽略投递失败
        except RuntimeError:
            pass

    def _deliver(self, event: dict[str, Any]) -> None:
        """在事件循环线程内把事件分发给所有订阅者。
        队列满时先弹出最旧的一条再放入，实现“丢旧保新”的背压策略。
        """
        for queue in list(self._subscribers):
            # 队列已满则丢弃最旧事件，保证最新进度可以送达
            if queue.full():
                try:
                    queue.get_nowait()
                except asyncio.QueueEmpty:
                    pass
            try:
                queue.put_nowait(event)
            except asyncio.QueueFull:
                pass

    def log(self, line: str, source: str = "launcher", level: str = "info") -> None:
        """发布一条日志事件的便捷方法。

        参数:
            line: 日志正文。
            source: 日志来源模块名，便于前端按来源过滤。
            level: 日志级别（info / warn / error）。
        """
        self.publish(make_event("log", source=source, line=line, level=level))
