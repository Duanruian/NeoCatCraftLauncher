"""账户认证服务模块。

支持的账号类型：
    microsoft —— 微软正版账户，走 mcauth3 的设备代码登录（device code flow），
                 用户无需输入密码，只需在浏览器里输入一次性代码；
    authlib   —— 第三方皮肤站（Yggdrasil / authlib-injector 协议），账号密码登录；
    unified   —— 统一通行证，本质是固定服务器的 authlib 登录；
    offline   —— 离线账户，本地按 OfflinePlayer:<名字> 生成固定 UUID。

对外能力：登录、令牌刷新与有效性校验、皮肤与披风查询、
生成 authlib-injector 的启动参数、登出，以及把内部账户结构脱敏后交给前端。

安全约定：access_token / refresh_token 只落在配置文件中，
public_account 输出给前端前必须剔除所有令牌字段。
"""

from __future__ import annotations

import base64
import hashlib
import json
import threading
import time
import uuid as uuid_lib
from pathlib import Path
from typing import Any
from urllib.parse import urlparse

import httpx
import minecraft_launcher_lib as mll
from mcauth3 import AuthTimeoutError, MCAuthError, MCMSA, OAuthError, XboxAuthError

from .config import Config
from .events import EventBus, make_event

USER_AGENT = "NeoCatCraftLauncher/0.2 (+https://github.com/neocatcraft)"
# 官方提供的最新版本元信息，含下载地址
AUTHLIB_INJECTOR_META = "https://authlib-injector.yushi.moe/artifact/latest.json"
AUTHLIB_INJECTOR_CDN = "https://authlib-injector.yushi.moe"


class AuthError(ValueError):
    pass


def _http(timeout: int = 20) -> httpx.Client:
    """构造带统一 UA 的 httpx 客户端（默认跟随重定向），供各处请求复用。
    """
    # 认证接口常有多级跳转，需允许跟随
    return httpx.Client(timeout=timeout, follow_redirects=True, headers={"User-Agent": USER_AGENT})


def _yggdrasil_error(response: httpx.Response) -> str:
    """从 Yggdrasil 协议的错误响应里提取可读信息。

    优先取 errorMessage，其次 error，都没有则退回 HTTP 状态码，
    保证错误提示不会只剩空字符串。
    """
    try:
        payload = response.json()
    except Exception:
        return f"HTTP {response.status_code}"
    message = payload.get("errorMessage") or payload.get("error") or ""
    if not message:
        return f"HTTP {response.status_code}"
    return str(message)


class AuthService:
    def __init__(self, config: Config, bus: EventBus) -> None:
        """初始化服务；_device_pending 保存当前进行中的设备代码登录会话，
        两把锁分别保护会话状态与 injector 下载。
        """
        self.config = config
        self.bus = bus
        self._device_pending: dict[str, Any] | None = None
        self._lock = threading.Lock()
        self._injector_lock = threading.Lock()

    # ---------- Microsoft ----------

    def microsoft_client_id(self) -> str | None:
        """读取用户自定义的 Microsoft Client ID，非法或旧格式时返回 None。

        返回 None 表示使用 mcauth3 内置的 Client ID，
        避免用户填了脏值导致 OAuth 直接失败。
        """
        value = (self.config.get("microsoft_client_id") or "").strip()
        if not value:
            return None
        try:
            # 只接受标准 UUID 格式，非法值走下面的告警分支
            return str(uuid_lib.UUID(value))
        except ValueError:
            self.bus.log(
                "已忽略旧版或无效的 Microsoft Client ID，使用 mcauth3 内置 Client ID",
                source="auth",
                level="error",
            )
            return None

    def start_microsoft_login(self) -> dict[str, Any]:
        """兼容旧接口名：直接转调设备代码登录。
        """
        return self.start_microsoft_device_login()

    def start_microsoft_device_login(self) -> dict[str, Any]:
        """发起微软设备代码登录。

        流程：向微软申请一次性代码 → 把 user_code 与验证地址返回前端 →
        启一个后台线程轮询换取令牌。前端只需把代码展示给用户，
        用户自行在浏览器完成登录，启动器不需要拿到密码。
        同时设置最小轮询间隔（不小于 3 秒），避免触发微软限流。
        """
        authenticator = MCMSA(client_id=self.microsoft_client_id())
        try:
            # 向微软申请设备代码，此时用户还没登录
            device_data = authenticator.start_auth()
        except MCAuthError as error:
            raise AuthError(f"mcauth3 无法启动设备代码登录: {error}") from error
        except Exception as error:
            raise AuthError(f"mcauth3 网络请求失败: {error}") from error
        flow = {
            "auth": authenticator,
            "device_data": device_data,
            "status": "pending",
            "account": None,
            "error": None,
            "created_at": time.time(),
            # 微软建议的轮询间隔，且不低于 3 秒
            "interval": max(3, int(device_data.get("interval") or 5)),
        }
        with self._lock:
            self._device_pending = flow
        threading.Thread(
            target=self._finish_microsoft_device_login,
            # 把会话对象传给后台线程，线程内回写状态
            args=(flow,),
            daemon=True,
            # 给线程命名，便于排查卡住的登录
            name="mcauth3-device-login",
        ).start()
        return {
            "status": "pending",
            "user_code": device_data.get("user_code"),
            # 兜底验证地址，防止微软未返回时前端无法展示
            "verification_uri": device_data.get("verification_uri") or "https://microsoft.com/link",
            "verification_uri_complete": device_data.get("verification_uri_complete"),
            "expires_in": int(device_data.get("expires_in") or 900),
            "interval": flow["interval"],
            "message": device_data.get("message") or "",
            "provider": "mcauth3",
        }

    def _finish_microsoft_device_login(self, flow: dict[str, Any]) -> None:
        """后台等待设备代码登录结果（阻塞在 mcauth3 的 finish_auth）。

        按异常类型区分失败原因，让前端能给出准确提示：
            AuthTimeoutError → 代码过期；OAuthError → 用户拒绝或代码失效；
            XboxAuthError → 通过微软账号但 Xbox 资料校验失败（无 Xbox 账号等）。
        """
        try:
            # 阻塞等待用户在浏览器完成授权并换取令牌
            result = flow["auth"].finish_auth(flow["device_data"])
            account = self._account_from_mcauth_result(result, publish=True)
            with self._lock:
                if self._device_pending is flow:
                    flow["status"] = "success"
                    flow["account"] = account
        except AuthTimeoutError as error:
            # 代码过期，需重新发起登录
            self._set_device_error(flow, "expired", f"设备代码已过期: {error}")
        except OAuthError as error:
            self._set_device_error(flow, "denied", f"Microsoft 拒绝了登录或代码已失效: {error}")
        except XboxAuthError as error:
            # 典型原因是账号没有 Xbox 档案或所在地区不支持
            self._set_device_error(flow, "xbox", f"Xbox 验证失败: {error}")
        except MCAuthError as error:
            self._set_device_error(flow, "error", f"mcauth3 验证失败: {error}")
        except Exception as error:
            self._set_device_error(flow, "error", f"mcauth3 登录失败: {error}")

    def _set_device_error(self, flow: dict[str, Any], status: str, message: str) -> None:
        """记录登录失败状态。

        若当前 pending 会话已被新的登录流程替换，则直接忽略，
        避免旧流程的错误覆盖新会话。
        """
        with self._lock:
            if self._device_pending is not flow:
                return
            # 回写失败状态，由前端轮询时读取
            flow["status"] = status
            flow["error"] = message

    def poll_microsoft_device_login(self) -> dict[str, Any]:
        """前端轮询入口：返回当前登录状态。

        进行中直接返回 pending 与建议的轮询间隔；
        已有结果时取走账户并清空会话（一次性消费），后续轮询会提示会话不存在。
        """
        with self._lock:
            flow = self._device_pending
            if not flow:
                raise AuthError("设备代码登录会话不存在，请重新获取代码")
            status = flow["status"]
            if status == "pending":
                return {"status": "pending", "interval": flow["interval"], "provider": "mcauth3"}
            account = flow.get("account")
            message = flow.get("error")
            # 结果已被消费，清空会话避免重复返回
            self._device_pending = None
        if status == "success" and account:
            return {"status": "success", "account": self.public_account(account), "provider": "mcauth3"}
        return {"status": status, "message": message or "mcauth3 登录未完成", "provider": "mcauth3"}

    def complete_microsoft_login(self, _: str = "") -> dict[str, Any]:
        """兼容旧接口：把轮询结果转成“成功返回账户，否则抛错”的形式。
        """
        result = self.poll_microsoft_device_login()
        if result.get("status") == "success":
            return result["account"]
        raise AuthError(result.get("message") or "mcauth3 设备代码登录仍在等待完成")

    def _account_from_mcauth_result(self, result: dict[str, Any], publish: bool = False) -> dict[str, Any]:
        """把 mcauth3 的登录结果整理成启动器内部账户结构并落库。

        必须校验 access_token、uuid、name 三者齐全，否则视为登录失败；
        可从 profile.skins 中取到皮肤地址一并缓存。
        publish=True 时会广播认证变更与登录成功事件，供前端刷新。
        """
        tokens = result.get("tokens") or {}
        profile = result.get("profile") or {}
        access_token = str(tokens.get("minecraft_access_token") or "")
        refresh_token = str(tokens.get("microsoft_refresh_token") or "")
        profile_id = str(profile.get("id") or "")
        profile_name = str(profile.get("name") or "")
        # 三者缺一说明登录结果不完整，必须拒绝入库
        if not access_token or not profile_id or not profile_name:
            raise AuthError("mcauth3 返回的账户令牌或玩家资料不完整")
        skins = profile.get("skins") or []
        account = {
            "uuid": profile_id,
            "name": profile_name,
            "access_token": access_token,
            "refresh_token": refresh_token,
            "type": "microsoft",
            # profile 里通常只带默认皮肤
            "skin": skins[0].get("url") if skins else None,
            "updated_at": time.time(),
        }
        self.config.upsert_account(account)
        if publish:
            self.bus.publish(make_event("auth.changed", account=self.public_account(account)))
            self.bus.publish(make_event("auth.success", name=account["name"]))
        return account

    def refresh_account(self, account: dict[str, Any]) -> dict[str, Any]:
        """刷新账户令牌：微软账户用 refresh_token 走 mcauth3，
        第三方皮肤站走 Yggdrasil refresh 接口，离线账户无需刷新原样返回。
        """
        if account.get("type") == "microsoft":
            if not account.get("refresh_token"):
                return account
            try:
                result = MCMSA(client_id=self.microsoft_client_id()).refresh_auth(
                    str(account["refresh_token"])
                )
                # 刷新得到的令牌同样需要落库
                return self._account_from_mcauth_result(result)
            except MCAuthError as error:
                raise AuthError(f"mcauth3 令牌刷新失败: {error}") from error
            except Exception as error:
                raise AuthError(f"mcauth3 令牌刷新网络错误: {error}") from error
        if account.get("type") in ("authlib", "unified"):
            return self._refresh_yggdrasil(account)
        return account

    # ---------- 第三方皮肤站 / 统一通行证 ----------

    def inspect_server(self, server_url: str) -> dict[str, Any]:
        """探测皮肤站信息（API Root 的 meta 响应）。

        用于用户填地址时的即时校验与展示：返回站点名、实现名、
        皮肤域名白名单与外链等；地址必须带 http(s) 前缀，且需返回 200。
        """
        base = (server_url or "").strip().rstrip("/")
        # 只接受 http(s) 地址，避免拼出非法 URL
        if not base.lower().startswith("http"):
            raise AuthError("皮肤站地址需要以 http:// 或 https:// 开头")
        try:
            with _http() as client:
                response = client.get(base)
            if response.status_code != 200:
                raise AuthError(f"皮肤站无法访问（HTTP {response.status_code}）")
            payload = response.json()
        except AuthError:
            raise
        except Exception as error:
            raise AuthError(f"皮肤站无法访问: {error}") from error
        meta = payload.get("meta") or {}
        return {
            "url": base,
            "name": meta.get("serverName") or urlparse(base).netloc,
            "implementation": meta.get("implementationName") or "authlib-injector",
            "implementation_version": meta.get("implementationVersion") or "",
            "links": payload.get("links") or {},
            "skin_domains": payload.get("skinDomains") or [],
        }

    def authlib_login(
        self,
        server_url: str,
        username: str,
        password: str,
        server_name: str = "",
    ) -> dict[str, Any]:
        """第三方皮肤站账号密码登录（Yggdrasil authenticate）。

        要点：
            1. 每次登录生成新的 clientToken；
            2. 403 明确表示账号或密码错误，与其它失败区分开；
            3. 账号若尚未创建角色（没有 selectedProfile）则给出专门提示；
            4. 登录成功后顺带查询皮肤地址并落库，最后广播事件。
        """
        base = (server_url or "").strip().rstrip("/")
        if not base:
            raise AuthError("请填写皮肤站 API 地址")
        name = (username or "").strip()
        secret = password or ""
        if not name or not secret:
            raise AuthError("请填写邮箱与密码")
        client_token = uuid_lib.uuid4().hex
        payload = {
            "username": name,
            "password": secret,
            "clientToken": client_token,
            # Yggdrasil 协议要求声明登录代理名称与版本
            "agent": {"name": "Minecraft", "version": 1},
            "requestUser": False,
        }
        with _http() as client:
            response = client.post(f"{base}/authserver/authenticate", json=payload)
        # 403 是 Yggdrasil 约定的账号密码错误
        if response.status_code == 403:
            raise AuthError("账号或密码错误")
        if response.status_code != 200:
            raise AuthError(f"登录失败: {_yggdrasil_error(response)}")
        data = response.json()
        # 没有默认角色时退而取第一个可用角色
        profile = data.get("selectedProfile") or (data.get("availableProfiles") or [None])[0]
        if not profile:
            raise AuthError("该账号尚未创建 Minecraft 角色，请先在皮肤站创建角色")
        account = {
            "uuid": profile["id"],
            "name": profile["name"],
            "access_token": data.get("accessToken") or "",
            "client_token": data.get("clientToken") or client_token,
            "refresh_token": "",
            "type": "authlib",
            "server": base,
            "server_name": server_name or urlparse(base).netloc,
            # 登录时顺带查询皮肤，失败不影响登录
            "skin": self._fetch_skin(base, profile["id"]),
            "updated_at": time.time(),
        }
        self.config.upsert_account(account)
        self.bus.publish(make_event("auth.changed", account=self.public_account(account)))
        self.bus.publish(make_event("auth.success", name=account["name"]))
        return self.public_account(account)

    def unified_login(self, server_id: str, username: str, password: str) -> dict[str, Any]:
        """统一通行证登录：在 authlib 登录基础上，把服务器地址拼成 <base>/<服务器ID>。
        """
        server_id = (server_id or "").strip()
        if not server_id:
            raise AuthError("请填写统一通行证服务器 ID")
        # 统一通行证的公共认证网关，末尾去斜杠便于拼接
        base = (self.config.get("unified_auth_base") or "https://auth.mc-user.com:233").rstrip("/")
        return self.authlib_login(
            f"{base}/{server_id}",
            username,
            password,
            server_name=f"统一通行证 #{server_id}",
        )

    def _refresh_yggdrasil(self, account: dict[str, Any]) -> dict[str, Any]:
        """用 accessToken + clientToken 走 Yggdrasil refresh 接口换新令牌，
        并以返回的 selectedProfile 更新玩家名与 UUID。
        缺少必要字段时提示用户重新登录，而不是静默失败。
        """
        base = (account.get("server") or "").rstrip("/")
        token = account.get("access_token") or ""
        client_token = account.get("client_token") or ""
        if not base or not token:
            raise AuthError("该账户缺少可刷新的令牌，请重新登录")
        # refresh 只需令牌对，不需要密码
        payload = {"accessToken": token, "clientToken": client_token}
        with _http() as client:
            response = client.post(f"{base}/authserver/refresh", json=payload)
        if response.status_code != 200:
            raise AuthError(f"令牌刷新失败: {_yggdrasil_error(response)}")
        data = response.json()
        profile = data.get("selectedProfile") or {}
        updated = dict(account)
        updated.update(
            {
                "access_token": data.get("accessToken") or token,
                "client_token": data.get("clientToken") or client_token,
                "name": profile.get("name") or account.get("name"),
                "uuid": profile.get("id") or account.get("uuid"),
                "updated_at": time.time(),
            }
        )
        self.config.upsert_account(updated)
        return updated

    def _validate_yggdrasil(self, account: dict[str, Any]) -> bool:
        """调用 Yggdrasil validate 接口判断令牌是否仍然有效。

        该接口成功时返回 204 且无响应体；网络异常一律按无效处理。
        """
        base = (account.get("server") or "").rstrip("/")
        if not base:
            return False
        try:
            with _http(12) as client:
                response = client.post(
                    f"{base}/authserver/validate",
                    json={
                        "accessToken": account.get("access_token") or "",
                        "clientToken": account.get("client_token") or "",
                    },
                )
            # validate 成功返回 204 且没有响应体
            return response.status_code == 204
        except Exception:
            return False

    @staticmethod
    def _texture_details(payload: dict[str, Any]) -> dict[str, Any]:
        """从材质属性（textures property）中解析皮肤与披风。

        该属性是 base64 编码的 JSON，需先解码再取 textures.SKIN / CAPE；
        skin.metadata.model 为 slim 时表示细手臂模型。
        解析失败时返回全空结果，避免影响主流程。
        """
        for prop in payload.get("properties") or []:
            if prop.get("name") != "textures":
                continue
            try:
                # textures 属性是 base64 编码的 JSON
                raw = base64.b64decode(prop.get("value") or "")
                textures = json.loads(raw).get("textures") or {}
            except Exception:
                continue
            skin = textures.get("SKIN") or {}
            cape = textures.get("CAPE") or {}
            metadata = skin.get("metadata") or {}
            model = str(metadata.get("model") or "classic").lower()
            return {
                "skin": str(skin.get("url") or "") or None,
                # 未知模型一律按经典（粗手臂）处理
                "skin_model": "slim" if model == "slim" else "classic",
                "cape": str(cape.get("url") or "") or None,
            }
        # 解析不出材质时返回空结果
        return {"skin": None, "skin_model": "classic", "cape": None}

    def _fetch_textures(self, profile_url: str) -> dict[str, Any] | None:
        """请求 sessionserver 的 profile 接口并解析材质。

        任何失败（网络、非 200、解析异常）都返回 None，
        调用方据此回退到本地缓存的皮肤。
        """
        try:
            with _http(12) as client:
                response = client.get(profile_url)
            if response.status_code != 200:
                return None
            return self._texture_details(response.json())
        except Exception:
            return None

    def _fetch_skin(self, base: str, uuid_value: str) -> str | None:
        """按皮肤站的会话服务器地址查询玩家皮肤 URL。
        """
        details = self._fetch_textures(
            f"{base}/sessionserver/session/minecraft/profile/{uuid_value}"
        )
        return (details or {}).get("skin")

    def skin_preview(self, uuid_value: str) -> dict[str, Any]:
        """获取某账户的皮肤预览数据。

        只支持微软正版账户（第三方/离线账户的皮肤来源不稳定）。
        先请求 Mojang 会话服务器：拿到皮肤就写回账户缓存；
        拿不到则回退到缓存，并在结果中标记 cached=True。
        注意：本方法不会切换当前激活账户。
        """
        account = self.config.find_account(uuid_value)
        if account is None:
            raise AuthError("账户不存在，请重新登录")
        if account.get("type") != "microsoft":
            raise AuthError("皮肤预览仅支持已登录的微软正版账户")

        profile_url = (
            "https://sessionserver.mojang.com/session/minecraft/profile/"
            f"{account.get('uuid') or ''}"
        )
        # 先尝试在线获取最新皮肤
        details = self._fetch_textures(profile_url)
        if details and details.get("skin"):
            updated = self.config.update_account(
                uuid_value,
                {
                    "skin": details.get("skin"),
                    "skin_model": details.get("skin_model") or "classic",
                    "cape": details.get("cape"),
                    # 记录更新时间，便于前端判断缓存新鲜度
                    "skin_updated_at": time.time(),
                },
            )
            if updated is not None:
                account = updated

        if not account.get("skin"):
            raise AuthError("Mojang 未返回该账户的皮肤，可能尚未设置皮肤或当前网络不可用")
        return {
            **self.public_account(account),
            "active": account.get("uuid") == (self.config.active_account() or {}).get("uuid"),
            # 在线拿不到即为缓存数据，前端可提示离线显示
            "cached": details is None or not details.get("skin"),
        }

    # ---------- authlib-injector ----------

    def injector_jar(self) -> Path:
        """确保 authlib-injector.jar 存在，返回其路径。

        已存在且非空时直接复用；否则按配置的地址下载，
        未配置则向官方 meta 接口查询最新下载地址（支持 CDN 相对路径）。
        双重检查 + 锁，避免并发重复下载；先写 .part 再原子改名。
        """
        target = self.config.dir / "libs" / "authlib-injector.jar"
        if target.is_file() and target.stat().st_size > 0:
            return target
        configured = (self.config.get("authlib_injector_url") or "").strip()
        with self._injector_lock:
            if target.is_file() and target.stat().st_size > 0:
                return target
            url = configured
            if not url:
                try:
                    with _http(20) as client:
                        meta = client.get(AUTHLIB_INJECTOR_META).json()
                    url = str(meta.get("download_url") or "")
                    # meta 返回的是相对路径时需要拼上 CDN 域名
                    if url.startswith("/"):
                        url = AUTHLIB_INJECTOR_CDN + url
                except Exception as error:
                    raise AuthError(f"获取 authlib-injector 下载地址失败: {error}") from error
            if not url:
                raise AuthError("无法解析 authlib-injector 下载地址")
            target.parent.mkdir(parents=True, exist_ok=True)
            # 先下到 .part，成功后再改名
            part = target.with_suffix(".jar.part")
            try:
                with _http(120) as client:
                    with client.stream("GET", url) as response:
                        response.raise_for_status()
                        with part.open("wb") as handle:
                            # 流式写入，防止内存占用过大
                            for chunk in response.iter_bytes(262144):
                                handle.write(chunk)
                part.replace(target)
            except Exception as error:
                try:
                    part.unlink(missing_ok=True)
                except Exception:
                    pass
                raise AuthError(f"下载 authlib-injector 失败: {error}") from error
        self.bus.publish(make_event("java.changed"))
        return target

    def authlib_arguments(self, account: dict[str, Any]) -> list[str]:
        """为第三方登录生成启动参数。

        非 authlib/unified 类型或没有服务器地址时返回空列表；
        否则返回 -javaagent:<jar>=<api_root>，由 JVM 在启动时注入认证实现。
        """
        server = (account.get("server") or "").strip()
        if account.get("type") not in ("authlib", "unified") or not server:
            return []
        jar = self.injector_jar()
        # JVM 启动参数：把插件挂到 javaagent 上并指定 API Root
        return [f"-javaagent:{jar}={server}"]

    # ---------- 离线 ----------

    def ensure_valid_account(self, account: dict[str, Any]) -> dict[str, Any]:
        """启动前的账号有效性保障。

        微软账户按 updated_at 判断：50 分钟内视为新鲜，直接复用；
        否则尝试刷新，失败则要求重新登录。
        第三方账户先 validate，不通过再尝试 refresh。
        离线账户直接返回。
        """
        account_type = account.get("type")
        if account_type == "microsoft":
            # 50 分钟内视为新鲜令牌，省去一次网络请求
            if time.time() - float(account.get("updated_at") or 0) < 3000:
                return account
            try:
                return self.refresh_account(account)
            except Exception as error:
                raise AuthError(f"账户令牌刷新失败，请重新登录: {error}") from error
        if account_type in ("authlib", "unified"):
            if self._validate_yggdrasil(account):
                return account
            try:
                return self._refresh_yggdrasil(account)
            except Exception as error:
                raise AuthError(f"统一认证令牌已失效，请重新登录: {error}") from error
        return account

    def offline_login(self, username: str) -> dict[str, Any]:
        """离线登录。

        用户名限制 3-16 位、仅字母数字下划线（与原版规则一致）；
        UUID 按 OfflinePlayer:<name> 的 MD5 生成并修正为 v3 格式，
        保证同名玩家在离线服务器上始终得到相同 UUID。
        """
        name = (username or "").strip()
        # 原版用户名长度限制
        if not 3 <= len(name) <= 16:
            raise AuthError("离线用户名长度需在 3-16 个字符之间")
        # 只允许字母数字下划线，避免生成非法 UUID 与显示问题
        if not all(char.isalnum() or char == "_" for char in name):
            raise AuthError("离线用户名只能包含字母、数字和下划线")

        # 与官方离线模式同源的 UUID 生成方式
        digest = bytearray(hashlib.md5(f"OfflinePlayer:{name}".encode("utf-8")).digest())
        # 版本位置为 3（MD5 名字型 UUID）
        digest[6] = (digest[6] & 0x0F) | 0x30
        # 设置 RFC 4122 变体位
        digest[8] = (digest[8] & 0x3F) | 0x80
        account = {
            "uuid": str(uuid_lib.UUID(bytes=bytes(digest))),
            "name": name,
            "access_token": "0",
            "refresh_token": "",
            "type": "offline",
            "skin": None,
            "updated_at": time.time(),
        }
        self.config.upsert_account(account)
        self.bus.publish(make_event("auth.changed", account=self.public_account(account)))
        return self.public_account(account)

    def logout(self, uuid: str | None = None) -> None:
        """登出：删除指定账户（默认当前激活账户），并广播认证变更事件。
        """
        target = uuid or (self.config.active_account() or {}).get("uuid")
        if target:
            self.config.remove_account(target)
        self.bus.publish(make_event("auth.changed", account=None))

    @staticmethod
    def public_account(account: dict[str, Any]) -> dict[str, Any]:
        """把内部账户结构脱敏后交给前端。

        刻意不含 access_token / refresh_token 等敏感字段，
        并补上中文类型标签，前端无需自己维护类型映射。
        """
        type_labels = {
            "microsoft": "微软正版",
            "offline": "离线账户",
            "authlib": "第三方皮肤站",
            "unified": "统一通行证",
        }
        account_type = account.get("type", "offline")
        return {
            "uuid": account.get("uuid"),
            "name": account.get("name"),
            "type": account_type,
            # 未知类型直接回显原值，不阻断展示
            "type_label": type_labels.get(account_type, account_type),
            "skin": account.get("skin"),
            "skin_model": account.get("skin_model") or "classic",
            "cape": account.get("cape"),
            "server": account.get("server"),
            "server_name": account.get("server_name"),
            "active": True,
        }
