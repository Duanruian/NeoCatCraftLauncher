"""模组加载器安装器相关函数的单元测试。

覆盖点：
    1. 从 Forge / NeoForge 安装器的 install_profile.json 识别加载器、游戏版本与加载器版本；
    2. 安装器 jar 缓存到配置目录下的 loader-installers；
    3. 没有 install_profile 的 Fabric 安装器可通过 MANIFEST 的 Main-Class 识别；
    4. 无法识别的 jar 抛 ValueError；
    5. 各加载器命令行参数构造正确；
    6. 官方下载地址指向对应 maven 仓库；
    7. 使用本地缓存 jar 安装时，版本 id 与命令参数正确。
"""

from __future__ import annotations

import json
import os
import shutil
import unittest
import zipfile
from pathlib import Path
from unittest import mock

import minecraft_launcher_lib as mll
from neo.config import Config
from neo.launcher import (
    _loader_installer_command,
    cache_mod_loader_jar,
    inspect_mod_loader_jar,
    install_mod_loader_from_jar,
)


class LoaderInstallerTests(unittest.TestCase):
    def setUp(self) -> None:
        """准备独立临时目录并把配置目录重定向进去。
        """
        self.root = Path(__file__).resolve().parents[2] / ".test-tmp" / self._testMethodName
        if self.root.exists():
            shutil.rmtree(self.root)
        self.root.mkdir(parents=True)
        self.previous_config = os.environ.get("NEO_CONFIG_DIR")
        os.environ["NEO_CONFIG_DIR"] = str(self.root / "config")

    def tearDown(self) -> None:
        """还原环境变量并删除临时目录。
        """
        if self.previous_config is None:
            os.environ.pop("NEO_CONFIG_DIR", None)
        else:
            os.environ["NEO_CONFIG_DIR"] = self.previous_config
        shutil.rmtree(self.root, ignore_errors=True)

    def _jar(self, name: str, profile: dict[str, object] | None = None) -> Path:
        """辅助方法：构造一个最小可用的安装器 jar。

        总是写入 MANIFEST.MF，profile 不为空时再写入 install_profile.json，
        用于分别模拟 Forge/NeoForge（有 profile）与普通 jar。
        """
        path = self.root / name
        with zipfile.ZipFile(path, "w") as archive:
            # 所有 jar 都有 MANIFEST，作为基础内容
            archive.writestr("META-INF/MANIFEST.MF", "Manifest-Version: 1.0\n")
            if profile is not None:
                # Forge/NeoForge 安装器靠该文件提供安装信息
                archive.writestr("install_profile.json", json.dumps(profile))
        return path

    def test_reads_forge_profile_metadata(self) -> None:
        """Forge 安装器的版本字符串形如 1.20.1-47.2.0，
        需从中拆出游戏版本与加载器版本（47.2.0）。
        """
        path = self._jar(
            "forge-1.20.1-47.2.0-installer.jar",
            {
                "minecraft": "1.20.1",
                "version": "1.20.1-47.2.0",
                "path": "net.minecraftforge:forge:1.20.1-47.2.0",
            },
        )

        details = inspect_mod_loader_jar(path)

        self.assertEqual(details["loader"], "forge")
        self.assertEqual(details["minecraft_version"], "1.20.1")
        # 从 1.20.1-47.2.0 中剥出加载器版本
        self.assertEqual(details["loader_version"], "47.2.0")

    def test_reads_neoforge_profile_metadata(self) -> None:
        """NeoForge 的 version 本身就是加载器版本，
        游戏版本单独放在 minecraft 字段，与 Forge 的写法不同，验证不会混淆。
        """
        path = self._jar(
            "neoforge-21.1.1-installer.jar",
            {
                "minecraft": "1.21.1",
                "version": "21.1.1",
                "path": "net.neoforged:neoforge:21.1.1",
            },
        )

        details = inspect_mod_loader_jar(path)

        self.assertEqual(details["loader"], "neoforge")
        self.assertEqual(details["minecraft_version"], "1.21.1")
        self.assertEqual(details["loader_version"], "21.1.1")

    def test_caches_installer_inside_config_directory(self) -> None:
        """测试缓存：安装器应复制到 <配置目录>/loader-installers，
        文件名保持不变、内容完全一致，便于离线复用。
        """
        path = self._jar(
            "forge-1.20.1-47.2.0-installer.jar",
            {
                "minecraft": "1.20.1",
                "version": "47.2.0",
                "path": "net.minecraftforge:forge:1.20.1-47.2.0",
            },
        )
        config = Config()

        cached = cache_mod_loader_jar(config, path)

        self.assertTrue(cached.is_file())
        # 缓存位置固定在配置目录下，便于清理
        self.assertEqual(cached.parent, config.dir / "loader-installers")
        self.assertEqual(cached.read_bytes(), path.read_bytes())

    def test_recognizes_fabric_installer_without_profile(self) -> None:
        """Fabric 安装器没有 install_profile.json，
        只能靠 MANIFEST 里的 Main-Class 识别；此时加载器版本未知，返回空字符串。
        """
        path = self.root / "fabric-installer-1.0.1.jar"
        with zipfile.ZipFile(path, "w") as archive:
            archive.writestr(
                "META-INF/MANIFEST.MF",
                # Fabric 安装器的识别特征：主类包名
                "Manifest-Version: 1.0\nMain-Class: net.fabricmc.installer.Main\n",
            )
            # 放一个空的 Main.class，模拟真实 jar 结构
            archive.writestr("net/fabricmc/installer/Main.class", b"")

        details = inspect_mod_loader_jar(path)

        self.assertEqual(details["loader"], "fabric")
        self.assertEqual(details["loader_version"], "")

    def test_rejects_jars_without_installer_metadata(self) -> None:
        """测试异常路径：既无 profile 也无识别特征时抛 ValueError，防止把普通 mod 当安装器执行。
        """
        path = self._jar("not-an-installer.jar")

        # 普通 mod 不应被当成安装器执行
        with self.assertRaisesRegex(ValueError, "无法从安装包识别"):
            inspect_mod_loader_jar(path)

    def test_builds_official_installer_commands(self) -> None:
        """验证命令行构造：
        Forge 用 --installClient <游戏目录> 作为结尾；
        Fabric 用 -mcversion / -loader 传参。
        """
        forge = _loader_installer_command(
            "forge", "1.20.1", "47.2.0", "C:/game", "C:/installer.jar", "java.exe"
        )
        fabric = _loader_installer_command(
            "fabric", "1.20.1", "0.16.0", "C:/game", "C:/installer.jar", "java.exe"
        )

        # Forge 新版安装器的安装参数
        self.assertEqual(forge[-2:], ["--installClient", "C:/game"])
        # Fabric 安装器的参数风格与 Forge 完全不同
        self.assertIn("-mcversion", fabric)
        self.assertIn("1.20.1", fabric)
        self.assertIn("-loader", fabric)
        self.assertIn("0.16.0", fabric)

    def test_online_sources_resolve_to_official_installers(self) -> None:
        """验证各加载器的在线安装器地址来自官方 maven 仓库，
        用 subTest 让四种加载器的失败互不影响。
        """
        cases = {
            "forge": ("47.2.0", "maven.minecraftforge.net"),
            "neoforge": ("21.1.1", "maven.neoforged.net"),
            "fabric": ("0.16.0", "maven.fabricmc.net"),
            "quilt": ("0.27.0", "maven.quiltmc.org"),
        }
        for loader, (version, host) in cases.items():
            with self.subTest(loader=loader):
                # 直接调用上游库的地址解析逻辑，验证仓库指向正确
                url = mll.mod_loader.get_mod_loader(loader)._base.get_installer_url(
                    "1.20.1", version
                )
                self.assertIn(host, url)
                self.assertTrue(url.endswith(".jar"))

    def test_installs_from_cached_local_jar(self) -> None:
        """测试“用本地 jar 安装”的完整链路。

        需 mock 掉三处外部依赖：安装原版、检查 launcher_profiles、执行 java 进程，
        然后断言返回的版本 id 与传给 java 的参数（--installClient）。
        """
        path = self._jar(
            "forge-1.20.1-47.2.0-installer.jar",
            {
                "minecraft": "1.20.1",
                "version": "1.20.1-47.2.0",
                "path": "net.minecraftforge:forge:1.20.1-47.2.0",
            },
        )
        minecraft_dir = self.root / "minecraft"
        version_id = "1.20.1-forge-47.2.0"

        # 跳过真实原版下载，只造出版本 json
        def fake_install(current_version: str, directory: str, **_: object) -> None:
            target = Path(directory) / "versions" / current_version / f"{current_version}.json"
            target.parent.mkdir(parents=True, exist_ok=True)
            target.write_text("{}", encoding="utf-8")

        # 跳过真实 java 进程，直接写出安装后的版本 json
        def fake_run(*_: object, **__: object) -> mock.Mock:
            target = minecraft_dir / "versions" / version_id / f"{version_id}.json"
            target.parent.mkdir(parents=True, exist_ok=True)
            target.write_text("{}", encoding="utf-8")
            result = mock.Mock()
            result.returncode = 0
            result.stdout = ""
            result.stderr = ""
            return result

        with (
            mock.patch.object(mll.install, "install_minecraft_version", side_effect=fake_install),
            # 伪造已存在 launcher_profiles.json，避免安装器拒绝执行
            mock.patch.object(mll.vanilla_launcher, "do_vanilla_launcher_profiles_exists", return_value=True),
            mock.patch("neo.launcher.subprocess.run", side_effect=fake_run) as run,
        ):
            installed, loader_version = install_mod_loader_from_jar(
                "forge",
                "1.20.1",
                str(minecraft_dir),
                "47.2.0",
                path,
                {},
                "java.exe",
            )

        self.assertEqual(installed, version_id)
        self.assertEqual(loader_version, "47.2.0")
        # 取出实际执行的命令，校验参数结尾
        command = run.call_args.args[0]
        self.assertEqual(command[-2:], ["--installClient", str(minecraft_dir)])


if __name__ == "__main__":
    unittest.main()
