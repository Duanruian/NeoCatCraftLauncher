"""Java 运行时管理的单元测试。

覆盖点：
    1. 下载严格按 Content-Length 截断，并校验 sha256，进度条停在 DOWNLOAD_PROGRESS_END；
    2. sha256 不匹配时抛 JavaError 且不留下残缺文件；
    3. 解压 zip 时进度可见（3/3），结束时停在 EXTRACT_PROGRESS_END；
    4. install 任务在解压完成后正确收尾并把路径与版本写入结果。

网络层通过 httpx.MockTransport 注入假响应，测试不依赖外网。
"""

from __future__ import annotations

import hashlib
import os
import shutil
import time
import unittest
import uuid
import zipfile
from pathlib import Path
from unittest import mock

import httpx

from neo.config import Config
from neo.events import EventBus
from neo.java_manager import DOWNLOAD_PROGRESS_END, EXTRACT_PROGRESS_END, JavaError, JavaManager
from neo.tasks import TaskManager


class JavaManagerTests(unittest.TestCase):
    def setUp(self) -> None:
        """每个用例使用带随机后缀的独立目录（uuid），避免并发或残留目录互相干扰，
        然后组装 Config / EventBus / TaskManager / JavaManager。
        """
        self.root = (
            Path(__file__).resolve().parents[2]
            / ".test-tmp"
            / f"java-manager-{self._testMethodName}-{uuid.uuid4().hex[:8]}"
        )
        if self.root.exists():
            shutil.rmtree(self.root)
        self.root.mkdir(parents=True)
        self.previous_config = os.environ.get("NEO_CONFIG_DIR")
        os.environ["NEO_CONFIG_DIR"] = str(self.root / "config")
        self.config = Config()
        self.bus = EventBus()
        self.tasks = TaskManager(self.bus)
        self.manager = JavaManager(self.config, self.tasks, self.bus)

    def tearDown(self) -> None:
        """还原配置目录环境变量并清理临时目录。
        """
        if self.previous_config is None:
            os.environ.pop("NEO_CONFIG_DIR", None)
        else:
            os.environ["NEO_CONFIG_DIR"] = self.previous_config
        shutil.rmtree(self.root, ignore_errors=True)

    def test_download_stops_at_declared_length_and_verifies_sha256(self) -> None:
        """测试下载主流程。

        用 MockTransport 伪造一个带 Content-Length 的响应，断言：
            1. 写入字节数与声明长度一致（不会因连接不关而多读）；
            2. 文件内容与 sha256 校验通过；
            3. 任务进度终点等于 DOWNLOAD_PROGRESS_END，总量为 100。
        """
        payload = b"zulu-java-archive" * 4096
        task = self.tasks.create("java", "test java")
        target = self.root / "zulu.zip"

        def handler(request: httpx.Request) -> httpx.Response:
            return httpx.Response(
                200,
                # 以字节流作为响应体，模拟真实分块下载
                stream=httpx.ByteStream(payload),
                headers={"Content-Length": str(len(payload))},
                request=request,
            )

        real_client = httpx.Client
        with mock.patch(
            "neo.java_manager.httpx.Client",
            side_effect=lambda *_, **__: real_client(
                transport=httpx.MockTransport(handler)
            ),
        ):
            written = self.manager._download(
                {
                    "name": "zulu.zip",
                    "url": "https://example.invalid/zulu.zip",
                    "size": len(payload),
                    "sha256": hashlib.sha256(payload).hexdigest(),
                },
                target,
                task.id,
            )

        current = self.tasks.get(task.id)
        self.assertEqual(written, len(payload))
        self.assertEqual(target.read_bytes(), payload)
        self.assertIsNotNone(current)
        assert current is not None
        self.assertEqual(current.total, 100)
        # 下载进度终点应停在预设值（留出后续安装的进度区间）
        self.assertEqual(current.progress, DOWNLOAD_PROGRESS_END)

    def test_download_rejects_sha256_mismatch(self) -> None:
        """测试校验失败路径：故意传错误的 sha256，
        应抛 JavaError（信息中含 SHA-256）并删除已写入的残缺文件。
        重试次数设为 1，避免等待。
        """
        # 只重试 1 次，让测试快速失败
        self.config.set("download_retries", 1)
        payload = b"corrupt"
        task = self.tasks.create("java", "test java")

        def handler(request: httpx.Request) -> httpx.Response:
            return httpx.Response(200, stream=httpx.ByteStream(payload), request=request)

        real_client = httpx.Client
        with mock.patch(
            "neo.java_manager.httpx.Client",
            side_effect=lambda *_, **__: real_client(
                transport=httpx.MockTransport(handler)
            ),
        ):
            with self.assertRaisesRegex(JavaError, "SHA-256"):
                self.manager._download(
                    {
                        "name": "zulu.zip",
                        "url": "https://example.invalid/zulu.zip",
                        "size": len(payload),
                        # 故意给错误的校验值
                        "sha256": "0" * 64,
                    },
                    self.root / "zulu.zip",
                    task.id,
                )

        # 校验失败后必须清理残缺文件，避免下次误判为已下载
        self.assertFalse((self.root / "zulu.zip").exists())

    def test_extracts_zip_with_visible_progress(self) -> None:
        """测试解压过程：
            1. 文件被正确释放到目标目录；
            2. 进度停在 EXTRACT_PROGRESS_END；
            3. 状态文案中包含“3/3”，说明逐条更新了当前数量与总数。
        """
        archive = self.root / "zulu.zip"
        with zipfile.ZipFile(archive, "w") as bundle:
            bundle.writestr("zulu-21/bin/java.exe", b"java")
            bundle.writestr("zulu-21/release", 'JAVA_VERSION="21.0.8"\n')
            bundle.writestr("zulu-21/lib/modules", b"modules")
        task = self.tasks.create("java", "test java")

        extract_dir = self.root / "extract"
        self.manager._extract_zip(archive, extract_dir, task.id)

        current = self.tasks.get(task.id)
        self.assertTrue((extract_dir / "zulu-21" / "bin" / "java.exe").is_file())
        self.assertIsNotNone(current)
        assert current is not None
        self.assertEqual(current.progress, EXTRACT_PROGRESS_END)
        # 文案里体现解压进度，前端可直接展示
        self.assertIn("3/3", current.message)

    def test_install_task_finishes_after_extracting_runtime(self) -> None:
        """测试 install 的整体收尾。

        把 resolve_package 与 _download 替换为不联网的假实现，
        断言任务最终状态为 done，且结果中的 path 真实存在、version 正确。
        """
        archive = self.root / "zulu-21.zip"
        with zipfile.ZipFile(archive, "w") as bundle:
            bundle.writestr("zulu-21/bin/java.exe", b"java")
            bundle.writestr("zulu-21/release", 'JAVA_VERSION="21.0.8"\n')
        package = {
            "url": "https://example.invalid/zulu-21.zip",
            "name": archive.name,
            "size": archive.stat().st_size,
            "sha256": hashlib.sha256(archive.read_bytes()).hexdigest(),
            "major": 21,
            "version": "21.0.8",
        }

        # 用本地文件复制代替下载，只验证安装流程本身
        def fake_download(_: dict[str, object], target: Path, task_id: str) -> int:
            shutil.copyfile(archive, target)
            self.tasks.progress(task_id, progress=DOWNLOAD_PROGRESS_END, total=100)
            return target.stat().st_size

        with (
            # 固定软件包元信息，避免请求 Adoptium 接口
            mock.patch.object(self.manager, "resolve_package", return_value=package),
            mock.patch.object(self.manager, "_download", side_effect=fake_download),
        ):
            task = self.manager.install(21)
            current = self._wait_for_task(task["id"])

        # 安装任务应正常结束
        self.assertEqual(current.state, "done")
        self.assertTrue(Path(current.result["path"]).is_file())
        self.assertEqual(current.result["version"], "21.0.8")

    def _wait_for_task(self, task_id: str):
        """轮询等待任务结束（上限 5 秒）。
        任务进入 error 状态即让用例失败并带出错误信息。
        """
        deadline = time.time() + 5
        while time.time() < deadline:
            task = self.tasks.get(task_id)
            if task is not None and task.state != "running":
                # 异步失败时立即断言失败
                if task.state == "error":
                    self.fail(task.error or "java install failed")
                return task
            time.sleep(0.01)
        # 超时兜底，防止用例卡死
        self.fail("java install task did not finish")


if __name__ == "__main__":
    unittest.main()
