"""皮肤预览功能的单元测试。

覆盖点：
    1. 查询微软账号皮肤时会把结果写回账号缓存，且不会改动当前激活账号；
    2. Mojang 接口不可用时能回退到本地缓存的皮肤；
    3. 离线账号不允许打开皮肤预览，抛 AuthError。
"""

from __future__ import annotations

import os
import shutil
import unittest
from pathlib import Path
from unittest import mock

from neo.auth import AuthError, AuthService
from neo.config import Config
from neo.events import EventBus


class SkinPreviewTests(unittest.TestCase):
    def setUp(self) -> None:
        """准备独立临时目录与配置，构造 AuthService（事件总线用真实的 EventBus 即可）。
        """
        self.root = Path(__file__).resolve().parents[2] / ".test-tmp" / self._testMethodName
        if self.root.exists():
            shutil.rmtree(self.root)
        self.root.mkdir(parents=True)
        self.previous_config = os.environ.get("NEO_CONFIG_DIR")
        # 把配置目录重定向到临时目录，避免读写用户真实配置
        os.environ["NEO_CONFIG_DIR"] = str(self.root / "config")
        self.config = Config()
        self.service = AuthService(self.config, EventBus())

    def tearDown(self) -> None:
        """还原配置目录环境变量并清理临时目录。
        """
        if self.previous_config is None:
            os.environ.pop("NEO_CONFIG_DIR", None)
        else:
            os.environ["NEO_CONFIG_DIR"] = self.previous_config
        shutil.rmtree(self.root, ignore_errors=True)

    def _add_accounts(self) -> None:
        """辅助方法：插入两个微软账号，并把第二个设为激活账号，
        用于验证“预览皮肤不会切换激活账号”。
        """
        self.config.upsert_account(
            {
                "uuid": "player-one",
                "name": "PlayerOne",
                "type": "microsoft",
                "access_token": "token",
                "skin": None,
            }
        )
        self.config.upsert_account(
            {
                "uuid": "player-two",
                "name": "PlayerTwo",
                "type": "microsoft",
                "access_token": "token",
            }
        )

    def test_microsoft_skin_is_cached_without_switching_active_account(self) -> None:
        """核心用例：预览皮肤后，皮肤与模型应写回该账号缓存，
        但当前激活账号保持不变（仍是 PlayerTwo）。

        这是易踩的坑：查询皮肤需要 access_token，实现若顺手切换激活账号会造成用户困扰。
        """
        self._add_accounts()
        with mock.patch.object(
            self.service,
            "_fetch_textures",
            # 伪造 Mojang 纹理接口的返回，测试不联网
            return_value={
                "skin": "https://textures.minecraft.net/texture/example",
                # 皮肤模型分为 classic / slim 两种
                "skin_model": "slim",
                "cape": None,
            },
        ):
            preview = self.service.skin_preview("player-one")

        self.assertEqual(preview["skin"], "https://textures.minecraft.net/texture/example")
        self.assertEqual(preview["skin_model"], "slim")
        # 关键断言：预览不会切换激活账号
        self.assertEqual(self.config.active_account()["uuid"], "player-two")
        self.assertEqual(
            self.config.find_account("player-one")["skin_model"],
            "slim",
        )

    def test_cached_skin_is_available_when_mojang_is_unreachable(self) -> None:
        """测试离线可用性：网络请求返回 None 时，应回退到账号里已缓存的皮肤，
        并在结果中标记 cached=True。
        """
        self._add_accounts()
        self.config.update_account(
            "player-one",
            {
                "skin": "https://textures.minecraft.net/texture/cached",
                "skin_model": "classic",
            },
        )
        # 模拟 Mojang 接口不可达
        with mock.patch.object(self.service, "_fetch_textures", return_value=None):
            preview = self.service.skin_preview("player-one")

        self.assertEqual(preview["skin"], "https://textures.minecraft.net/texture/cached")
        # 标记为来自缓存，前端可提示“离线显示”
        self.assertTrue(preview["cached"])

    def test_offline_account_cannot_open_skin_preview(self) -> None:
        """测试异常路径：离线账号没有正版凭据，无法查询皮肤，
        应抛出提示“微软正版”的 AuthError。
        """
        self.config.upsert_account(
            {"uuid": "offline", "name": "Offline", "type": "offline", "skin": None}
        )
        # 离线账号应被明确拒绝
        with self.assertRaisesRegex(AuthError, "微软正版"):
            self.service.skin_preview("offline")


if __name__ == "__main__":
    unittest.main()
