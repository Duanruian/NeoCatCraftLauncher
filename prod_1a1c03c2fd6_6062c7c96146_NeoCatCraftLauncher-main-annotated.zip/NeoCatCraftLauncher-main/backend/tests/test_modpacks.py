"""整合包安装服务的单元测试。

覆盖点：
    1. sanitize_filename 不破坏 .mrpack 后缀；
    2. 在线安装必须使用下载器实际落盘的文件（而不是拼接出的文件名）；
    3. 本地 mrpack 安装会释放 overrides 与 client-overrides，并写回版本 id；
    4. CurseForge 必需文件下载失败时，错误能被正确汇总上报。

网络请求全部用 mock 替换，测试不依赖外网。
"""

from __future__ import annotations

import json
import os
import shutil
import time
import unittest
import zipfile
from pathlib import Path
from unittest import mock

from neo.config import Config
from neo.events import EventBus
from neo.instances import InstanceManager
from neo import modpacks
from neo.modpacks import ModpackError, ModpackService
from neo.mods.downloader import DownloadResult, sanitize_filename
from neo.tasks import TaskManager


def _write_zip(path: Path, files: dict[str, bytes | str]) -> None:
    """辅助函数：按 {包内路径: 内容} 生成一个 zip 包，用于构造测试用的整合包文件。
    """
    with zipfile.ZipFile(path, "w") as archive:
        for name, content in files.items():
            archive.writestr(name, content)


class ModpackInstallTests(unittest.TestCase):
    def setUp(self) -> None:
        """每个用例独立的准备：创建临时根目录、重定向配置目录，
        并组装 Config / EventBus / TaskManager / InstanceManager / ModpackService。

        JavaManager 用 mock.Mock() 顶替，因为安装流程里只需它返回一个值。
        """
        # 每个用例独立目录，按用例名隔离
        self.root = Path(__file__).resolve().parents[2] / ".test-tmp" / self._testMethodName
        if self.root.exists():
            shutil.rmtree(self.root)
        self.root.mkdir(parents=True)
        self.previous_config = os.environ.get("NEO_CONFIG_DIR")
        os.environ["NEO_CONFIG_DIR"] = str(self.root / "config")
        self.config = Config()
        self.config.set("minecraft_directory", str(self.root / "minecraft"))
        self.bus = EventBus()
        self.tasks = TaskManager(self.bus)
        self.instances = InstanceManager(self.config)
        self.service = ModpackService(self.config, self.tasks, self.bus, self.instances, mock.Mock())

    def tearDown(self) -> None:
        """还原环境变量并删除临时目录，保证用例之间互不干扰。
        """
        if self.previous_config is None:
            os.environ.pop("NEO_CONFIG_DIR", None)
        else:
            # 还原配置目录，避免污染其它用例
            os.environ["NEO_CONFIG_DIR"] = self.previous_config
        shutil.rmtree(self.root, ignore_errors=True)

    def test_mrpack_extension_is_preserved(self) -> None:
        """回归测试：文件名清洗不能把 .mrpack 当成多余后缀剥掉，
        否则下载后的文件无法被识别为整合包。
        """
        self.assertEqual(sanitize_filename("Example-1.0.mrpack"), "Example-1.0.mrpack")

    def test_online_install_uses_the_downloaded_file_path(self) -> None:
        """回归测试：安装时必须使用 download_file 实际写盘后的路径。

        file 名可能被清洗或去重，若仍用拼接的原始路径会读不到文件。
        这里通过 fake_download 写入“净化后的名字”，再由 fake_install 断言读到正确内容。
        """
        installed_path: Path | None = None
        installed_contents = b""

        def fake_download(url: str, directory: Path, filename: str, **_: object) -> DownloadResult:
            directory.mkdir(parents=True, exist_ok=True)
            # 模拟下载器对文件名做净化后的落盘结果
            target = directory / sanitize_filename(filename)
            target.write_bytes(b"mrpack")
            return DownloadResult(str(target), target.stat().st_size, False, 1)

        # 记录被安装的压缩包路径与内容，供后续断言
        def fake_install(archive: Path, *_: object, **__: object) -> dict[str, object]:
            nonlocal installed_path, installed_contents
            installed_path = archive
            installed_contents = archive.read_bytes()
            return {"id": "test-instance", "name": "Test Pack", "directory": str(self.root)}

        with (
            mock.patch.object(self.service, "_resolve_download", return_value=("https://example.invalid/pack", "Pack.mrpack")),
            mock.patch.object(self.service, "_install_archive", side_effect=fake_install),
            # 替换真实下载，避免联网
            mock.patch.object(modpacks, "download_file", side_effect=fake_download),
            # 固定临时目录位置，便于断言
            mock.patch.object(modpacks.tempfile, "mkdtemp", return_value=str(self.root / "download")),
        ):
            task = self.service.install("modrinth", "project")
            self._wait_for_task(task["id"])

        self.assertIsNotNone(installed_path)
        assert installed_path is not None
        self.assertEqual(installed_path.name, "Pack.mrpack")
        self.assertEqual(installed_contents, b"mrpack")

    def test_local_mrpack_extracts_client_overrides(self) -> None:
        """测试本地 mrpack 的完整安装：
        overrides 与 client-overrides 都要释放到实例目录，且实例版本 id 需写为加载器版本。
        """
        archive = self.root / "pack.mrpack"
        index = {
            "formatVersion": 1,
            "game": "minecraft",
            "versionId": "1.0.0",
            "name": "Offline Test Pack",
            "summary": "integration test",
            "files": [],
            "dependencies": {"minecraft": "1.20.1", "fabric-loader": "0.15.11"},
        }
        _write_zip(
            archive,
            {
                "modrinth.index.json": json.dumps(index),
                # 通用覆盖目录：客户端与服务端共用
                "overrides/config/example.txt": "shared",
                # 客户端专用覆盖目录，优先级高于 overrides
                "client-overrides/config/client-only.txt": "client",
            },
        )
        task = self.tasks.create("modpack", "test")

        with mock.patch.object(self.service, "_install_base", return_value="fabric-loader-0.15.11-1.20.1"):
            instance = self.service._install_archive(archive, task.id)

        instance_dir = self.instances.directory_of(instance)
        self.assertEqual((instance_dir / "config" / "example.txt").read_text(), "shared")
        self.assertEqual((instance_dir / "config" / "client-only.txt").read_text(), "client")
        # 安装完加载器后必须把版本 id 写回实例，启动才找得到版本
        self.assertEqual(instance["version_id"], "fabric-loader-0.15.11-1.20.1")

    def test_curseforge_required_file_failure_is_reported(self) -> None:
        """测试 CurseForge 整合包在必需文件下载失败时抛出汇总错误。

        断言错误信息中包含失败数量，方便用户判断缺了多少文件。
        """
        archive = self.root / "pack.zip"
        manifest = {
            "minecraft": {
                "version": "1.20.1",
                "modLoaders": [{"id": "forge-47.2.20", "primary": True}],
            },
            "name": "Broken Pack",
            # 构造一个必需文件，配合下面的 mock 让它下载失败
            "files": [{"projectID": 123, "fileID": 456, "required": True}],
        }
        _write_zip(archive, {"manifest.json": json.dumps(manifest)})
        task = self.tasks.create("modpack", "test")

        with (
            mock.patch.object(self.service, "_install_base", return_value="1.20.1-forge-47.2.20"),
            mock.patch.object(self.service, "_curseforge_file", side_effect=RuntimeError("download denied")),
        ):
            with self.assertRaisesRegex(ModpackError, "1 个必需文件下载失败"):
                self.service._install_archive(archive, task.id)

    def _wait_for_task(self, task_id: str) -> None:
        """轮询等待异步任务结束。

        超时 5 秒；任务进入 error 状态时直接让用例失败并带出错误信息，
        避免异步失败被误判为“未完成”。
        """
        deadline = time.time() + 5
        while time.time() < deadline:
            task = self.tasks.get(task_id)
            if task is not None and task.state != "running":
                # 异步任务失败时立刻断言失败，带出原始错误
                if task.state == "error":
                    self.fail(task.error or "modpack task failed")
                return
            time.sleep(0.01)
        # 超时兜底，防止用例卡死
        self.fail("modpack task did not finish")


if __name__ == "__main__":
    unittest.main()
