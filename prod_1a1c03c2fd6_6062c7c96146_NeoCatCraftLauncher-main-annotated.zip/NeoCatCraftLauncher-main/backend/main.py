"""后端入口与 HTTP API 层（FastAPI）。

结构：
    1. 进程级单例 —— Config / EventBus / TaskManager 以及各业务服务，
       全部在此创建并注入，作为整个后端的依赖容器；
    2. lifespan —— 启动时把事件总线绑定到事件循环，关闭时终止所有游戏进程；
    3. 路由 —— 按领域分组：基础信息、实例、版本、加载器、Java、账户、
       模组、资源包/光影/数据包、整合包、启动；
    4. 事件推送 —— /api/events 提供 SSE 长连接，把后端的安装进度、
       日志、认证变化实时推给前端。

约定：成功统一返回 JSON，失败统一 {ok:false, error:<提示>}（fail 辅助函数），
HTTP 状态码用于区分参数错误（400）、资源不存在（404）与上游故障（502）。
"""

from __future__ import annotations

import asyncio
import json
import os
import sys
import time
from contextlib import asynccontextmanager
from pathlib import Path
from typing import Any

BASE_DIR = Path(__file__).resolve().parent
# 保证以脚本方式启动时能 import 同目录下的 neo 包
if str(BASE_DIR) not in sys.path:
    sys.path.insert(0, str(BASE_DIR))

from fastapi import Body, FastAPI, HTTPException, Query
from fastapi.middleware.cors import CORSMiddleware
from fastapi.responses import HTMLResponse, JSONResponse, StreamingResponse
from fastapi.staticfiles import StaticFiles

from neo.auth import AuthError, AuthService
from neo.content import ContentService
from neo.config import APP_NAME, APP_VERSION, DEFAULT_PORT, DEFAULT_SKIN_SITES, Config
from neo.events import EventBus, make_event
from neo.instances import InstanceError, InstanceManager
from neo.java_manager import AVAILABLE_MAJORS, JAVA_LABELS, JavaError, JavaManager, java_major_for_minecraft
from neo.launcher import LauncherService
from neo.mirror import configure_download_mirror
from neo.modpacks import ModpackError, ModpackService
from neo.mods.platform import ModPlatformError, ModService
from neo.tasks import TaskManager

# 进程级单例：所有服务共享同一份配置
config = Config()
configure_download_mirror(config)
bus = EventBus()
tasks = TaskManager(bus)
instances = InstanceManager(config)
java = JavaManager(config, tasks, bus)
auth = AuthService(config, bus)
launcher = LauncherService(config, tasks, bus, instances, java, auth)
mods = ModService(config, tasks, bus, instances)
content = ContentService(config, tasks, bus, instances)
# 整合包安装需要 Java 来执行安装器
modpacks = ModpackService(config, tasks, bus, instances, java)

ROOT = Path(__file__).resolve().parent
# 前端源码与构建产物都在同级 frontend 目录
_frontend_root = ROOT.parent / "frontend"
FRONTEND = _frontend_root / "dist" if (_frontend_root / "dist").is_dir() else _frontend_root


@asynccontextmanager
async def lifespan(_: FastAPI):
    """应用生命周期钩子。

    启动时把事件总线绑定到当前事件循环（否则后台线程无法向 SSE 推送），
    关停时调用 stop_all 结束所有游戏进程，避免留下孤儿进程。
    """
    # 事件总线需要事件循环才能把后台线程的事件推给 SSE
    bus.bind_loop(asyncio.get_running_loop())
    bus.log(f"{APP_NAME} 后端已就绪（minecraft-launcher-lib {launcher.library_version()}）", source="system")
    # 应用运行期间挂起，直到关停
    yield
    launcher.stop_all()


app = FastAPI(title=APP_NAME, version=APP_VERSION, lifespan=lifespan)
# 前端与后端可能不同源（开发模式），放开跨域
app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],
    allow_methods=["*"],
    allow_headers=["*"],
)


def fail(error: Exception, status: int = 400) -> JSONResponse:
    """统一的失败响应构造器：{ok:false, error:<文案>}，默认 400。
    """
    # 前端只需判断 ok 字段即可统一处理错误
    return JSONResponse({"ok": False, "error": str(error)}, status_code=status)


def public_settings() -> dict[str, Any]:
    """把配置整理成可安全下发给前端的设置对象。

    关键点：移除 curseforge_api_key 明文，只保留“是否已配置”的布尔标记；
    路径类字段统一转成字符串，皮肤站列表给默认值。
    """
    payload = config.settings
    payload["microsoft_client_id"] = payload.get("microsoft_client_id") or ""
    payload["curseforge_api_key_set"] = bool((payload.get("curseforge_api_key") or "").strip())
    # 密文不能下发前端，只暴露是否已配置
    payload.pop("curseforge_api_key", None)
    payload["minecraft_directory"] = str(config.minecraft_directory)
    payload["javas_directory"] = str(config.javas_directory)
    payload["instances_directory"] = str(config.instances_directory)
    # 未配置时回落到内置皮肤站列表
    payload["skin_sites"] = payload.get("skin_sites") or DEFAULT_SKIN_SITES
    return payload


# ---------- 基础 ----------


@app.get("/api/health")
def health() -> dict[str, Any]:
    """健康检查：返回版本、各目录路径、端口与进程号，便于排查环境问题。
    """
    return {
        "ok": True,
        "name": APP_NAME,
        "version": APP_VERSION,
        "library": launcher.library_version(),
        "minecraft_directory": str(config.minecraft_directory),
        "mods_directory": str(config.mods_directory),
        "javas_directory": str(config.javas_directory),
        "instances_directory": str(config.instances_directory),
        "config_dir": str(config.dir),
        # 实际端口可能被环境变量覆盖，以运行时为准
        "port": int(os.environ.get("NEO_PORT", DEFAULT_PORT)),
        "pid": os.getpid(),
        "time": time.time(),
    }


@app.get("/api/app/bootstrap")
def bootstrap() -> dict[str, Any]:
    """前端首屏初始化聚合接口。

    一次性返回设置、是否首次运行、账户列表与激活账户、实例列表（含解析出的激活实例）、
    Java 可用版本与已安装列表、任务列表，减少启动时的请求数。
    """
    active = config.active_account()
    # resolve(None) 表示取当前激活实例（不存在时回落到第一个）
    resolved = instances.resolve(None)
    return {
        "ok": True,
        "name": APP_NAME,
        "version": APP_VERSION,
        "settings": public_settings(),
        "first_run_done": bool(config.get("first_run_done")),
        "disclaimer_accepted": bool(config.get("disclaimer_accepted")),
        "accounts": config.public_accounts(),
        "active_account": active.get("uuid") if active else None,
        "instances": instances.list(),
        "active_instance": resolved["id"] if resolved else None,
        "java": {
            "available_majors": [{"major": major, "label": JAVA_LABELS.get(major, f"Java {major}")} for major in AVAILABLE_MAJORS],
            "installed": java.managed(),
            "system": java.system(),
        },
        "tasks": tasks.list(),
    }


@app.post("/api/app/first-run")
def finish_first_run(payload: dict[str, Any] = Body(default={})) -> dict[str, Any]:
    """完成首次运行引导，顺带记录免责声明的接受状态。
    """
    if payload.get("disclaimer_accepted"):
        config.set("disclaimer_accepted", True)
    # 无论是否接受声明都算走完引导，避免反复弹窗
    config.set("first_run_done", True)
    bus.publish(make_event("settings.changed"))
    return {"first_run_done": True, "disclaimer_accepted": bool(config.get("disclaimer_accepted"))}


@app.post("/api/app/disclaimer")
def accept_disclaimer() -> dict[str, Any]:
    """单独记录用户已接受免责声明。
    """
    config.set("disclaimer_accepted", True)
    return {"disclaimer_accepted": True}


@app.get("/api/settings")
def get_settings() -> dict[str, Any]:
    """读取设置（已脱敏）。
    """
    return public_settings()


@app.put("/api/settings")
def put_settings(patch: dict[str, Any] = Body(...)) -> dict[str, Any]:
    """局部更新设置。

    更新后立即重配下载镜像源；若改动的是 Minecraft 目录，
    额外广播版本/实例变更事件，让前端重新拉取列表。
    """
    config.update_settings(patch)
    configure_download_mirror(config)
    bus.publish(make_event("settings.changed"))
    # 换目录后已有版本与实例信息都可能失效，需前端重拉
    if "minecraft_directory" in patch:
        bus.publish(make_event("versions.changed"))
        bus.publish(make_event("instances.changed"))
    return public_settings()


@app.get("/api/tasks")
def list_tasks() -> list[dict[str, Any]]:
    """列出所有后台任务及其进度。
    """
    return tasks.list()


@app.get("/api/events")
async def events() -> StreamingResponse:
    """SSE 事件流：向前端持续推送后端事件。

    每个连接独享一个队列；首帧先发 hello（附带当前账户与任务快照）便于前端同步状态；
    等待超时则发注释行作为心跳，防止中间层断开空闲连接；
    客户端断开后务必退订，避免队列泄漏。
    """
    # 每个 SSE 连接一个独立队列
    queue = bus.subscribe()

    async def stream():
        try:
            # 首帧同步当前状态，前端无需额外请求
            yield f"data: {json.dumps(make_event('hello', account=None, tasks=tasks.list()), ensure_ascii=False)}\n\n"
            while True:
                try:
                    event = await asyncio.wait_for(queue.get(), timeout=15)
                    # SSE 要求每条消息以 data: 开头、空行结尾
                    yield f"data: {json.dumps(event, ensure_ascii=False)}\n\n"
                except asyncio.TimeoutError:
                    # 以注释行作心跳，保持长连接不被中间层掐断
                    yield ": ping\n\n"
        finally:
            # 断开时退订，防止队列堆积导致内存泄漏
            bus.unsubscribe(queue)

    return StreamingResponse(
        stream(),
        media_type="text/event-stream",
        # 禁用缓存与代理缓冲，保证事件实时到达
        headers={"Cache-Control": "no-cache", "X-Accel-Buffering": "no"},
    )


# ---------- 实例 ----------


@app.get("/api/instances")
def list_instances() -> dict[str, Any]:
    """列出实例与当前激活实例。
    """
    active = instances.resolve(None)
    return {"instances": instances.list(), "active": active["id"] if active else None}


@app.post("/api/instances")
def create_instance(payload: dict[str, Any] = Body(...)) -> JSONResponse:
    """创建实例并在后台安装对应版本。

    立即返回实例快照与任务 id，安装进度由任务与事件推送。
    """
    try:
        result = launcher.provision_instance(payload)
        return JSONResponse(result)
    except InstanceError as error:
        return fail(error)


@app.get("/api/instances/{instance_id}")
def get_instance(instance_id: str) -> JSONResponse:
    """读取单个实例的完整信息，附带可用 Java 解析结果与该版本要求的 Java 主版本。
    """
    instance = instances.get(instance_id)
    if instance is None:
        return fail(InstanceError(f"实例不存在: {instance_id}"), 404)
    payload = instances.snapshot(instance)
    payload["java"] = java.resolve(instance)
    # 顺带告知前端该版本需要哪个 Java 主版本
    payload["required_java"] = java_major_for_minecraft(instance.get("mc_version") or "")
    return JSONResponse(payload)


@app.patch("/api/instances/{instance_id}")
def update_instance(instance_id: str, patch: dict[str, Any] = Body(...)) -> JSONResponse:
    """局部更新实例字段（名称、内存、JVM 参数、分辨率等）。
    """
    try:
        updated = instances.update(instance_id, patch)
        bus.publish(make_event("instances.changed"))
        return JSONResponse(updated)
    except InstanceError as error:
        return fail(error, 404)


@app.delete("/api/instances/{instance_id}")
def delete_instance(instance_id: str, delete_files: bool = False) -> JSONResponse:
    """删除实例；delete_files=True 时连同实例目录一并删除。
    """
    try:
        result = instances.delete(instance_id, delete_files)
        bus.publish(make_event("instances.changed"))
        return JSONResponse(result)
    except InstanceError as error:
        return fail(error, 404)


@app.post("/api/instances/{instance_id}/duplicate")
def duplicate_instance(instance_id: str, payload: dict[str, Any] = Body(default={})) -> JSONResponse:
    """复制实例（可指定新名称）。
    """
    try:
        created = instances.duplicate(instance_id, payload.get("name") or None)
        bus.publish(make_event("instances.changed"))
        return JSONResponse(created)
    except InstanceError as error:
        return fail(error, 404)


@app.post("/api/instances/{instance_id}/repair")
def repair_instance(instance_id: str) -> JSONResponse:
    """修复实例：重新安装版本与加载器。
    """
    try:
        return JSONResponse(launcher.repair_instance(instance_id))
    except InstanceError as error:
        return fail(error, 404)


@app.post("/api/instances/{instance_id}/select")
def select_instance(instance_id: str) -> JSONResponse:
    """切换当前激活实例。
    """
    if instances.get(instance_id) is None:
        return fail(InstanceError("实例不存在"), 404)
    config.set("active_instance", instance_id)
    bus.publish(make_event("instances.changed"))
    return JSONResponse({"active": instance_id})


# 允许快捷打开的标准子目录白名单
INSTANCE_SUBDIRS = ("mods", "saves", "logs", "screenshots", "resourcepacks", "shaderpacks", "datapacks", "config")


@app.post("/api/instances/{instance_id}/open")
def open_instance_folder(instance_id: str, sub: str = "") -> JSONResponse:
    """在文件管理器中打开实例目录，或其中的 mods/saves/logs 等子目录。

    仅 Windows 下真正打开资源管理器，其它平台只返回路径。
    """
    instance = instances.get(instance_id)
    if instance is None:
        return fail(InstanceError("实例不存在"), 404)
    folder = instances.directory_of(instance)
    if sub in INSTANCE_SUBDIRS:
        folder = folder / sub
        folder.mkdir(parents=True, exist_ok=True)
    if os.name == "nt":
        os.startfile(str(folder))
    return JSONResponse({"directory": str(folder)})


def _safe_child(root: Path, name: str) -> Path | None:
    """把用户传入的文件名安全地拼到 root 下。

    用 resolve + relative_to 校验最终路径没有跳出 root，
    借此阻断 ../ 之类的路径穿越；校验失败返回 None。
    """
    try:
        candidate = (root / name).resolve()
        # 越过 root 会抛异常，从而阻断路径穿越
        candidate.relative_to(root.resolve())
    except Exception:
        return None
    return candidate


@app.get("/api/instances/{instance_id}/saves")
def list_saves(instance_id: str) -> JSONResponse:
    """列出存档。

    体积用 region 目录下文件大小之和近似（完整统计过慢），
    按修改时间倒序，便于前端展示“最近游玩”。
    """
    instance = instances.get(instance_id)
    if instance is None:
        return fail(InstanceError("实例不存在"), 404)
    root = instances.directory_of(instance) / "saves"
    root.mkdir(parents=True, exist_ok=True)
    items: list[dict[str, Any]] = []
    for child in sorted(root.iterdir(), key=lambda item: item.name.lower()):
        if not child.is_dir():
            continue
        size = 0
        region = child / "region"
        try:
            for entry in (region.iterdir() if region.is_dir() else []):
                # region 文件占据存档绝大部分体积，用它近似总量足够
                size += entry.stat().st_size
        except Exception:
            pass
        items.append(
            {
                "name": child.name,
                "directory": str(child),
                "size": size,
                "modified": child.stat().st_mtime,
            }
        )
    items.sort(key=lambda item: -float(item["modified"]))
    return JSONResponse({"directory": str(root), "count": len(items), "saves": items})


@app.get("/api/instances/{instance_id}/logs")
def list_logs(instance_id: str) -> JSONResponse:
    """列出日志与崩溃报告（logs 与 crash-reports 两个目录）。
    """
    instance = instances.get(instance_id)
    if instance is None:
        return fail(InstanceError("实例不存在"), 404)
    root = instances.directory_of(instance)
    items: list[dict[str, Any]] = []
    # 日志与崩溃报告分属两个目录，统一展示
    for kind, folder in (("log", root / "logs"), ("crash", root / "crash-reports")):
        if not folder.is_dir():
            continue
        for child in folder.iterdir():
            if child.is_file() and child.suffix.lower() in {".log", ".txt"}:
                try:
                    stat = child.stat()
                except Exception:
                    continue
                items.append(
                    {
                        "name": child.name,
                        "kind": kind,
                        "size": stat.st_size,
                        "modified": stat.st_mtime,
                    }
                )
    items.sort(key=lambda item: -float(item["modified"]))
    return JSONResponse({"directory": str(root), "logs": items})


@app.get("/api/instances/{instance_id}/logs/{name}")
def read_log(instance_id: str, name: str, lines: int = 300) -> JSONResponse:
    """读取日志尾部若干行（默认 300，限制 20~2000 行）。

    文件名必须经过 _safe_child 校验，防止读取任意文件；
    内容以 UTF-8 容错解码，避免旧日志编码问题导致 500。
    """
    instance = instances.get(instance_id)
    if instance is None:
        return fail(InstanceError("实例不存在"), 404)
    root = instances.directory_of(instance)
    target = None
    for folder in (root / "logs", root / "crash-reports"):
        child = _safe_child(folder, name)
        if child and child.is_file():
            target = child
            break
    if target is None:
        return fail(InstanceError("日志文件不存在"), 404)
    try:
        content = target.read_text(encoding="utf-8", errors="replace").splitlines()
    except Exception as error:
        return fail(RuntimeError(f"读取日志失败: {error}"), 500)
    # 限制单次读取行数，防止超大日志拖慢前端
    limit = max(20, min(int(lines or 300), 2000))
    tail = content[-limit:]
    # 告知前端内容被截断，可提示用户查看完整文件
    return JSONResponse({"name": target.name, "content": "\n".join(tail), "truncated": len(content) > len(tail)})


# ---------- 版本 ----------


@app.get("/api/versions")
def versions(force: bool = False) -> dict[str, Any]:
    """获取可安装版本与已安装版本；上游接口异常时返回 502。
    """
    try:
        return {"available": launcher.available_versions(force), "installed": launcher.installed_versions()}
    except Exception as error:
        # 502 表示上游（Mojang 接口）不可用
        raise HTTPException(status_code=502, detail=f"获取版本列表失败: {error}")


@app.post("/api/versions/install")
def install_version(payload: dict[str, Any] = Body(...)) -> dict[str, Any]:
    """触发原版版本安装（后台任务）。
    """
    version_id = (payload.get("version") or "").strip()
    if not version_id:
        raise HTTPException(status_code=400, detail="缺少 version")
    return launcher.install_version(version_id, payload.get("instance_id") or None)


# ---------- 加载器 ----------


@app.get("/api/loaders")
def loaders() -> list[dict[str, str]]:
    """列出支持的模组加载器。
    """
    return launcher.loader_list()


@app.get("/api/loaders/{loader}/minecraft-versions")
def loader_minecraft_versions(loader: str, stable_only: bool = True) -> dict[str, Any]:
    """列出某加载器支持的所有 Minecraft 版本。
    """
    try:
        return {"loader": loader, "versions": launcher.loader_minecraft_versions(loader, stable_only)}
    except Exception as error:
        raise HTTPException(status_code=400, detail=str(error))


@app.get("/api/loaders/{loader}/versions")
def loader_versions(loader: str, minecraft_version: str = Query(...)) -> dict[str, Any]:
    """列出某加载器在指定 Minecraft 版本下的可用加载器版本。
    """
    try:
        return launcher.loader_versions(loader, minecraft_version)
    except Exception as error:
        raise HTTPException(status_code=400, detail=str(error))


@app.post("/api/loaders/inspect-jar")
def inspect_loader_jar(payload: dict[str, Any] = Body(...)) -> JSONResponse:
    """校验并解析用户选择的本地加载器安装包。
    """
    installer_path = str(payload.get("path") or "").strip()
    if not installer_path:
        return fail(ValueError("缺少安装包路径"))
    try:
        return JSONResponse(launcher.inspect_loader_jar(installer_path))
    except Exception as error:
        return fail(error, 400)


@app.post("/api/loaders/install")
def install_loader(payload: dict[str, Any] = Body(...)) -> dict[str, Any]:
    """安装模组加载器，可指定本地安装包或由后端自动下载。
    """
    loader = (payload.get("loader") or "").strip()
    minecraft_version = (payload.get("minecraft_version") or "").strip()
    if not loader or not minecraft_version:
        raise HTTPException(status_code=400, detail="缺少 loader 或 minecraft_version")
    try:
        return launcher.install_loader(
            loader,
            minecraft_version,
            payload.get("loader_version") or None,
            payload.get("instance_id") or None,
            payload.get("installer_path") or None,
        )
    except Exception as error:
        raise HTTPException(status_code=400, detail=str(error))


# ---------- Java ----------


@app.get("/api/java")
def java_info(force: bool = False) -> dict[str, Any]:
    """Java 运行时总览：托管安装、系统检测、全部可用以及可下载的主版本列表。
    """
    return {
        "managed": java.managed(),
        "system": java.system(force),
        "all": java.all_java(force),
        "available": [{"major": major, "label": JAVA_LABELS.get(major, f"Java {major}")} for major in AVAILABLE_MAJORS],
        "directory": str(config.javas_directory),
    }


@app.get("/api/java/resolve")
def java_resolve(mc_version: str = "", instance_id: str = "") -> JSONResponse:
    """解析某个实例（或某个 Minecraft 版本）应当使用哪个 Java。
    """
    instance = instances.get(instance_id) if instance_id else None
    if instance is None and mc_version:
        # 只给了游戏版本时伪造一个最小对象供解析使用
        instance = {"mc_version": mc_version}
    resolved = java.resolve(instance)
    return JSONResponse(
        {
            "resolved": resolved,
            "required": java_major_for_minecraft(mc_version or (instance or {}).get("mc_version") or ""),
        }
    )


@app.post("/api/java/install")
def java_install(payload: dict[str, Any] = Body(...)) -> JSONResponse:
    """下载并安装指定主版本的 Java 运行时。
    """
    try:
        major = int(payload.get("major") or 0)
    except Exception:
        return fail(JavaError("无效的 Java 版本"))
    if major <= 0:
        return fail(JavaError("无效的 Java 版本"))
    return JSONResponse(java.install(major))


@app.post("/api/java/ensure")
def java_ensure(payload: dict[str, Any] = Body(...)) -> JSONResponse:
    """确保存在可用的 Java：缺失时自动安装并返回解析结果。
    """
    mc_version = str(payload.get("mc_version") or "").strip()
    instance = instances.get(str(payload.get("instance_id") or "")) if payload.get("instance_id") else None
    if not mc_version and instance:
        mc_version = instance.get("mc_version") or ""
    if not mc_version:
        return fail(JavaError("缺少 mc_version"))
    try:
        return JSONResponse({"resolved": java.ensure(mc_version, instance)})
    except Exception as error:
        return fail(error, 502)


@app.post("/api/java/open-folder")
def open_java_folder() -> JSONResponse:
    """打开 Java 安装目录。
    """
    folder = config.javas_directory
    folder.mkdir(parents=True, exist_ok=True)
    if os.name == "nt":
        os.startfile(str(folder))
    return JSONResponse({"directory": str(folder)})


# ---------- 账户 ----------


@app.get("/api/auth/accounts")
def accounts() -> dict[str, Any]:
    """列出已保存账户与当前激活账户的 UUID。
    """
    active = config.active_account()
    return {"accounts": config.public_accounts(), "active_uuid": active.get("uuid") if active else None}


@app.get("/api/auth/accounts/{uuid_value}/skin")
def account_skin_preview(uuid_value: str) -> JSONResponse:
    """获取正版账户的皮肤预览数据（含皮肤/披风地址与模型类型）。
    """
    try:
        return JSONResponse(auth.skin_preview(uuid_value))
    except AuthError as error:
        return fail(error, 404)
    except Exception as error:
        return fail(RuntimeError(f"获取正版皮肤失败: {error}"), 502)


@app.get("/api/auth/servers")
def auth_servers() -> dict[str, Any]:
    """返回可选的皮肤站列表、统一通行证网关与服务器 ID。
    """
    return {
        "skin_sites": config.get("skin_sites") or DEFAULT_SKIN_SITES,
        "unified_base": config.get("unified_auth_base"),
        "unified_server_id": config.get("unified_server_id"),
    }


@app.post("/api/auth/servers/inspect")
def inspect_server(payload: dict[str, Any] = Body(...)) -> JSONResponse:
    """探测用户填写的皮肤站地址是否可用，并返回站点元信息。
    """
    url = str(payload.get("url") or "").strip()
    if not url:
        return fail(AuthError("缺少皮肤站地址"))
    try:
        return JSONResponse(auth.inspect_server(url))
    except Exception as error:
        return fail(RuntimeError(f"无法连接该皮肤站: {error}"), 502)


@app.post("/api/auth/microsoft/start")
def microsoft_start() -> dict[str, Any]:
    """发起微软登录（兼容旧接口）。
    """
    try:
        return auth.start_microsoft_login()
    except AuthError as error:
        raise HTTPException(status_code=400, detail=str(error))


@app.post("/api/auth/microsoft/device/start")
def microsoft_device_start() -> JSONResponse:
    """发起微软设备代码登录，返回一次性代码与验证地址。
    """
    try:
        return JSONResponse(auth.start_microsoft_device_login())
    except AuthError as error:
        return fail(error, 400)
    except Exception as error:
        return fail(RuntimeError(f"启动 Microsoft 设备代码登录失败: {error}"), 502)


@app.post("/api/auth/microsoft/device/poll")
def microsoft_device_poll() -> JSONResponse:
    """轮询设备代码登录状态。
    """
    try:
        return JSONResponse(auth.poll_microsoft_device_login())
    except AuthError as error:
        return fail(error, 400)
    except Exception as error:
        return fail(RuntimeError(f"Microsoft 登录状态检查失败: {error}"), 502)


@app.post("/api/auth/microsoft/complete")
def microsoft_complete(payload: dict[str, Any] = Body(...)) -> dict[str, Any]:
    """兼容旧接口：直接完成登录。
    """
    try:
        return auth.complete_microsoft_login(payload.get("code") or payload.get("url") or "")
    except Exception as error:
        raise HTTPException(status_code=400, detail=f"登录失败: {error}")


# 登录回调静态页模板，%s 依次填充标题与说明文字
CALLBACK_PAGE = """<!doctype html><html lang="zh-CN"><head><meta charset="utf-8">
<title>NeoCatCraftLauncher 登录</title>
<style>
body{margin:0;height:100vh;display:grid;place-items:center;background:#0d1117;color:#e6edf3;
font-family:"Segoe UI","Microsoft YaHei",sans-serif}
.card{padding:32px 40px;border-radius:16px;background:#161b22;border:1px solid #30363d;text-align:center}
h1{font-size:18px;margin:0 0 8px;font-weight:600}
p{margin:0;color:#8b949e;font-size:14px}
</style></head><body><div class="card"><h1>%s</h1><p>%s</p></div></body></html>"""


@app.get("/api/auth/microsoft/callback", response_class=HTMLResponse)
def microsoft_callback(code: str = "", error: str = "", error_description: str = "") -> HTMLResponse:
    """OAuth 回调页。

    用户完成授权后浏览器会跳到这里，服务端用 code 换令牌，
    并返回一个纯静态页面告知用户结果，无需前端参与。
    """
    # 用户在授权页点拒绝时，微软会带回 error 参数
    if error:
        return HTMLResponse(CALLBACK_PAGE % ("登录失败", error_description or error), status_code=400)
    # 没有 code 说明流程被中断，需要重新发起
    if not code:
        return HTMLResponse(CALLBACK_PAGE % ("缺少授权码", "请回到启动器重新发起登录"), status_code=400)
    try:
        account = auth.complete_microsoft_login(code)
        return HTMLResponse(CALLBACK_PAGE % ("登录成功", f"欢迎回来，{account.get('name')}。可以关闭此页面了。"))
    except Exception as exc:
        return HTMLResponse(CALLBACK_PAGE % ("登录失败", str(exc)), status_code=400)


@app.post("/api/auth/offline")
def offline_login(payload: dict[str, Any] = Body(...)) -> JSONResponse:
    """离线登录，按用户名生成固定 UUID。
    """
    try:
        account = auth.offline_login(payload.get("username") or "")
        bus.publish(make_event("auth.changed", account=None))
        return JSONResponse(account)
    except AuthError as error:
        return fail(error)


@app.post("/api/auth/authlib")
def authlib_login(payload: dict[str, Any] = Body(...)) -> JSONResponse:
    """第三方皮肤站账号密码登录。
    """
    try:
        account = auth.authlib_login(
            str(payload.get("server") or ""),
            str(payload.get("username") or ""),
            str(payload.get("password") or ""),
            str(payload.get("server_name") or ""),
        )
        bus.publish(make_event("auth.changed", account=None))
        return JSONResponse(account)
    except Exception as error:
        return fail(error)


@app.post("/api/auth/unified")
def unified_login(payload: dict[str, Any] = Body(...)) -> JSONResponse:
    """统一通行证登录。
    """
    try:
        account = auth.unified_login(
            str(payload.get("server_id") or ""),
            str(payload.get("username") or ""),
            str(payload.get("password") or ""),
        )
        bus.publish(make_event("auth.changed", account=None))
        return JSONResponse(account)
    except Exception as error:
        return fail(error)


@app.post("/api/auth/select")
def select_account(payload: dict[str, Any] = Body(...)) -> dict[str, Any]:
    """切换当前激活账户（uuid 为空时取消激活）。
    """
    uuid_value = payload.get("uuid")
    if uuid_value is not None:
        config.set_active_account(str(uuid_value))
    bus.publish(make_event("auth.changed", account=None))
    return {"accounts": config.public_accounts()}


@app.delete("/api/auth/accounts/{uuid_value}")
def delete_account(uuid_value: str) -> dict[str, Any]:
    """删除指定账户（内部即为登出）。
    """
    auth.logout(uuid_value)
    return {"accounts": config.public_accounts()}


# ---------- 模组 ----------


@app.get("/api/mods")
def scan_mods(instance_id: str = "") -> dict[str, Any]:
    """扫描实例的 mods 目录，返回已装模组清单。

    未指定实例时使用当前激活实例；并把加载器与目标游戏版本带上，
    供前端判断模组是否匹配。
    """
    instance = instances.get(instance_id) if instance_id else instances.resolve(None)
    report = mods.scan(instance["id"] if instance else None)
    # 没有激活实例时退回上一次使用的加载器
    report["loader"] = (instance or {}).get("loader") or config.get("last_loader")
    report["mc_version"] = (instance or {}).get("mc_version")
    report["instance_id"] = instance["id"] if instance else None
    return report


@app.get("/api/mods/platforms")
def mod_platforms() -> list[dict[str, Any]]:
    """返回模组平台（Modrinth / CurseForge）的可用状态与配置情况。
    """
    return mods.platform_status()


@app.get("/api/mods/search")
def search_mods(
    platform: str = "modrinth",
    query: str = "",
    minecraft_version: str = "",
    loader: str = "",
    limit: int = 20,
    offset: int = 0,
) -> JSONResponse:
    """跨平台搜索模组（分页）。
    """
    try:
        payload = mods.search(platform, query, minecraft_version or None, loader or None, limit, offset)
        return JSONResponse(payload)
    except ModPlatformError as error:
        return fail(error)
    except Exception as error:
        return fail(RuntimeError(f"搜索失败: {error}"), 502)


@app.get("/api/mods/versions")
def mod_versions(
    platform: str = "modrinth",
    project_id: str = Query(...),
    minecraft_version: str = "",
    loader: str = "",
) -> JSONResponse:
    """查询某模组可用的文件版本（按游戏版本与加载器过滤）。
    """
    try:
        return JSONResponse(mods.versions(platform, project_id, minecraft_version or None, loader or None))
    except ModPlatformError as error:
        return fail(error)
    except Exception as error:
        return fail(RuntimeError(f"获取版本失败: {error}"), 502)


@app.get("/api/mods/dependencies")
def mod_dependencies(
    platform: str = "modrinth",
    project_id: str = Query(...),
    version_id: str = "",
    minecraft_version: str = "",
    loader: str = "",
    instance_id: str = "",
) -> JSONResponse:
    """查询某模组文件的前置依赖，并结合实例已装模组判断是否已满足。
    """
    try:
        return JSONResponse(
            mods.inspect_dependencies(
                platform,
                project_id,
                version_id or None,
                minecraft_version or None,
                loader or None,
                instance_id or None,
            )
        )
    except ModPlatformError as error:
        return fail(error)
    except Exception as error:
        return fail(RuntimeError(f"获取前置信息失败: {error}"), 502)


@app.post("/api/mods/install")
def install_mod(payload: dict[str, Any] = Body(...)) -> JSONResponse:
    """安装模组，可选择连带安装前置依赖。

    会过滤掉空的依赖 project_id，避免下载到无效条目。
    """
    platform = payload.get("platform") or "modrinth"
    project_id = str(payload.get("project_id") or "").strip()
    if not project_id:
        return fail(ValueError("缺少 project_id"))
    try:
        result = mods.install(
            platform,
            project_id,
            str(payload["version_id"]) if payload.get("version_id") else None,
            payload.get("minecraft_version") or None,
            payload.get("loader") or None,
            bool(payload.get("with_dependencies", False)),
            bool(payload.get("enabled", True)),
            payload.get("instance_id") or None,
            [
                str(item)
                for item in (payload.get("dependency_project_ids") or [])
                if str(item).strip()
            ],
        )
        return JSONResponse(result)
    except ModPlatformError as error:
        return fail(error)
    except Exception as error:
        return fail(RuntimeError(f"安装失败: {error}"), 502)


@app.post("/api/mods/toggle")
def toggle_mod(payload: dict[str, Any] = Body(...)) -> JSONResponse:
    """启用/禁用模组（改扩展名），不删除文件。
    """
    try:
        return JSONResponse(mods.toggle(str(payload.get("file") or ""), payload.get("instance_id") or None))
    except ModPlatformError as error:
        return fail(error)


@app.delete("/api/mods/file")
def delete_mod(file: str = Query(...), instance_id: str = "") -> JSONResponse:
    """删除模组文件。
    """
    try:
        return JSONResponse(mods.delete(file, instance_id or None))
    except ModPlatformError as error:
        return fail(error)


@app.post("/api/mods/open-folder")
def open_mods_folder(instance_id: str = "") -> JSONResponse:
    """打开模组目录（实例级或全局）。
    """
    instance = instances.get(instance_id) if instance_id else instances.resolve(None)
    # 实例级目录优先，否则用全局 mods 目录
    folder = instances.mods_directory_of(instance) if instance else config.mods_directory
    if os.name == "nt":
        os.startfile(str(folder))
    return JSONResponse({"directory": str(folder)})


# ---------- 资源包 / 光影 / 数据包 ----------


@app.get("/api/content/search")
def search_content(
    kind: str = "resourcepack",
    platform: str = "all",
    query: str = "",
    minecraft_version: str = "",
    limit: int = 20,
    offset: int = 0,
) -> JSONResponse:
    """搜索资源包 / 光影 / 数据包。
    """
    try:
        return JSONResponse(
            content.search(
                kind,
                platform,
                query,
                minecraft_version or None,
                limit,
                offset,
            )
        )
    except ModPlatformError as error:
        return fail(error)
    except Exception as error:
        return fail(RuntimeError(f"搜索失败: {error}"), 502)


@app.get("/api/content/versions")
def content_versions(
    kind: str = Query(...),
    platform: str = Query(...),
    project_id: str = Query(...),
    minecraft_version: str = "",
) -> JSONResponse:
    """查询某资源的可用版本。
    """
    try:
        return JSONResponse(
            content.versions(kind, platform, project_id, minecraft_version or None)
        )
    except ModPlatformError as error:
        return fail(error)
    except Exception as error:
        return fail(RuntimeError(f"获取版本失败: {error}"), 502)


@app.get("/api/content/local")
def list_local_content(
    kind: str = "resourcepack",
    instance_id: str = "",
    world: str = "",
) -> JSONResponse:
    """列出本地已安装的资源包、光影或某个存档的数据包。
    """
    try:
        return JSONResponse(content.scan(kind, instance_id or None, world or None))
    except ModPlatformError as error:
        return fail(error)


@app.post("/api/content/install")
def install_content(payload: dict[str, Any] = Body(...)) -> JSONResponse:
    """安装资源包 / 光影 / 数据包，可按实例或存档定位。
    """
    try:
        return JSONResponse(
            content.install(
                str(payload.get("kind") or ""),
                str(payload.get("platform") or ""),
                str(payload.get("project_id") or ""),
                str(payload.get("version_id")) if payload.get("version_id") else None,
                payload.get("minecraft_version") or None,
                payload.get("instance_id") or None,
                payload.get("world") or None,
            )
        )
    except ModPlatformError as error:
        return fail(error)
    except Exception as error:
        return fail(RuntimeError(f"安装失败: {error}"), 502)


@app.post("/api/content/toggle")
def toggle_content(payload: dict[str, Any] = Body(...)) -> JSONResponse:
    """启用/禁用资源包、光影或数据包。
    """
    try:
        return JSONResponse(
            content.toggle(
                str(payload.get("kind") or ""),
                str(payload.get("file") or ""),
                payload.get("instance_id") or None,
                payload.get("world") or None,
            )
        )
    except ModPlatformError as error:
        return fail(error)


@app.delete("/api/content/file")
def delete_content(
    kind: str = Query(...),
    file: str = Query(...),
    instance_id: str = "",
    world: str = "",
) -> JSONResponse:
    """删除资源包 / 光影 / 数据包文件。
    """
    try:
        return JSONResponse(
            content.delete(kind, file, instance_id or None, world or None)
        )
    except ModPlatformError as error:
        return fail(error)


@app.post("/api/content/open-folder")
def open_content_folder(payload: dict[str, Any] = Body(default={})) -> JSONResponse:
    """打开资源包 / 光影 / 数据包的目录。
    """
    try:
        folder = content.directory(
            str(payload.get("kind") or "resourcepack"),
            payload.get("instance_id") or None,
            payload.get("world") or None,
        )
        if os.name == "nt":
            os.startfile(str(folder))
        return JSONResponse({"directory": str(folder)})
    except ModPlatformError as error:
        return fail(error)


# ---------- 整合包 ----------


@app.get("/api/modpacks/search")
def search_modpacks(
    platform: str = "modrinth",
    query: str = "",
    minecraft_version: str = "",
    limit: int = 20,
    offset: int = 0,
) -> JSONResponse:
    """搜索整合包。
    """
    try:
        return JSONResponse(modpacks.search(platform, query, minecraft_version or None, limit, offset))
    except ModPlatformError as error:
        return fail(error)
    except Exception as error:
        return fail(RuntimeError(f"搜索整合包失败: {error}"), 502)


@app.get("/api/modpacks/versions")
def modpack_versions(platform: str = "modrinth", project_id: str = Query(...), minecraft_version: str = "") -> JSONResponse:
    """查询整合包可用版本。
    """
    try:
        return JSONResponse(modpacks.versions(platform, project_id, minecraft_version or None))
    except ModPlatformError as error:
        return fail(error)
    except Exception as error:
        return fail(RuntimeError(f"获取整合包版本失败: {error}"), 502)


@app.post("/api/modpacks/install")
def install_modpack(payload: dict[str, Any] = Body(...)) -> JSONResponse:
    """从平台安装整合包（后台任务）。
    """
    try:
        return JSONResponse(
            modpacks.install(
                str(payload.get("platform") or "modrinth"),
                str(payload.get("project_id") or ""),
                str(payload.get("version_id")) if payload.get("version_id") else None,
                payload.get("name") or None,
            )
        )
    except ModpackError as error:
        return fail(error)


@app.post("/api/modpacks/import")
def import_modpack(payload: dict[str, Any] = Body(...)) -> JSONResponse:
    """导入本地整合包文件（zip / mrpack）。
    """
    try:
        return JSONResponse(modpacks.import_file(str(payload.get("path") or ""), payload.get("name") or None))
    except ModpackError as error:
        return fail(error)


# ---------- 启动 ----------


@app.post("/api/launch")
def launch(payload: dict[str, Any] = Body(...)) -> JSONResponse:
    """启动游戏。

    流程：确定实例 → 确认已登录 → 校验/刷新令牌 →
    记录激活实例与上次版本 → 组装命令并拉起进程。
    任一步失败都给出可直接操作的提示，而不是笼统的 500。
    """
    instance = instances.resolve(payload.get("instance_id") or None)
    if instance is None:
        return fail(InstanceError("请先创建或选择一个实例"))
    account = config.active_account()
    if not account:
        return fail(ValueError("请先登录账户"))
    try:
        # 启动前刷新/校验令牌，避免进游戏被踢
        account = auth.ensure_valid_account(account)
        config.set("active_instance", instance["id"])
        # 记录最近启动版本，用于首页推荐
        config.update_settings({"last_version": instance.get("version_id") or instance.get("mc_version") or ""})
        return JSONResponse(launcher.launch(instance["id"], account))
    except Exception as error:
        return fail(error)


@app.post("/api/launch/stop")
def stop_games() -> dict[str, Any]:
    """停止所有已启动的游戏进程。
    """
    launcher.stop_all()
    return {"ok": True}


@app.get("/api/launch/status")
def launch_status() -> dict[str, Any]:
    """查询当前是否有游戏在运行。
    """
    return {"running": launcher.running_games()}


# 打包运行时由后端直接托管前端静态文件
if os.environ.get("NEO_SERVE_FRONTEND") and FRONTEND.is_dir():
    app.mount("/", StaticFiles(directory=str(FRONTEND), html=True), name="frontend")


def run() -> None:
    """启动 uvicorn 服务。

    默认只监听 127.0.0.1（本地启动器，不应暴露到局域网）；
    端口与日志级别可通过环境变量覆盖。
    """
    import uvicorn

    port = int(os.environ.get("NEO_PORT", DEFAULT_PORT))
    # 只监听本机回环地址，不对外暴露服务
    uvicorn.run(app, host="127.0.0.1", port=port, log_level=os.environ.get("NEO_LOG_LEVEL", "warning"))


if __name__ == "__main__":
    run()
